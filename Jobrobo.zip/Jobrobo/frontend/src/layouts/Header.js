import React, { useEffect, useState, useMemo, useRef } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Outlet, Link, useLocation, useNavigate } from "react-router-dom";
import Select, { components } from "react-select";
import { useCookies } from 'react-cookie';
import { USER_START_ROUTE_PATH, ADMIN_START_ROUTE_PATH, COOKIE_NAME } from '../utils/GlobalConstants.js';
import { getAllOptions, getProductAll, setAllProductCategories, setAllProducts } from '../slices/globalSlice.js';


const InputOption = ({
    getStyles,
    Icon,
    isDisabled,
    isFocused,
    isSelected,
    children,
    innerProps,
    ...rest
  }) => {
    const [isActive, setIsActive] = useState(false);
    const onMouseDown = () => setIsActive(true);
    const onMouseUp = () => setIsActive(false);
    const onMouseLeave = () => setIsActive(false);
  
    // styles
    let bg = "transparent";
    if (isFocused) bg = "#eee";
    if (isActive) bg = "#B2D4FF";
  
    const style = {
      alignItems: "center",
      backgroundColor: bg,
      color: "inherit",
      display: "flex "
    };
  
    // prop assignment
    const props = {
      ...innerProps,
      onMouseDown,
      onMouseUp,
      onMouseLeave,
      style
    };
  
    return (
      <components.Option
        {...rest}
        isDisabled={isDisabled}
        isFocused={isFocused}
        isSelected={isSelected}
        getStyles={getStyles}
        innerProps={props}
      >
        <input type="checkbox" defaultChecked={isSelected} checked={isSelected} />
        {children}
      </components.Option>
    );
  };

function Header(props) {

    const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

    const dispatch          =   useDispatch();
    const navigate          =   useNavigate();
    const globalState       =   useSelector(app => app.global);
    const location          =   useLocation();

    const [cookies, setCookie, removeCookie]    =   useCookies([COOKIE_NAME]);
    const [activeNav, setActiveNav]             =   useState(USER_START_ROUTE_PATH);

    const searchRef                             =   useRef();

    const [selectedOptions, setSelectedOptions] =   useState([]);
    const [searchProduct, setSearchProduct]     =   useState("");

    useEffect(() => {

        if(searchRef.current) {
            clearTimeout(searchRef.current);
        }

        searchRef.current   =   setTimeout(() => {
            getAllProducts({"product_category": selectedOptions});
        }, 500);
        
    }, [selectedOptions, searchProduct]);

    useEffect(() => {
        setActiveNav(location.pathname);
    },[location, activeNav]);

    useEffect(() => {
        if(!location.pathname.startsWith(ADMIN_START_ROUTE_PATH)) {
            getAllProductOptions();
        }
    }, []);

    const getAllProductOptions     =   () => {

        dispatch(getAllOptions({  }))
            .unwrap()
            .then(response => {

                if(response?.status != "success") {
                    return false;
                }

                if(Array.isArray(response.data) && response.data.length > 0) {
                    response.data.forEach((val) => {
                        if(val._id === 'product_category_options') {
                            dispatch(setAllProductCategories(val.options));
                        }
                    });
                }
                
            })
            .catch(e => {
                console.log('Login error find', e.message);
            });
    }

    const getAllProducts    =   (filter) => {
        dispatch(getProductAll({ ...filter, search_product: searchProduct}))
            .unwrap()
            .then(response => {

                if(response?.status != "success") {
                    return false;
                }

                dispatch(setAllProducts(response.data))

                //console.log("Products", response.data);
                
            })
            .catch(e => {
                console.log('Login error find', e.message);
            });
    }


    const logout = async(event) => {
        event.preventDefault();
        navigate('/logout');
    }

    const headerMenuClass   =   (menuPath) => {
        if(location.pathname.endsWith(menuPath)) {
            return 'nav-link active pointer';
        } else {
            return 'nav-link pointer';
        }
    }

    const headerNavMenuClass   =   (menuPath) => {
        if(location.pathname.endsWith(menuPath)) {
            return 'nav-item active pointer';
        } else {
            return 'nav-item pointer';
        }
    }

    const customStyles = {
        control: (defaultStyles) => ({
          ...defaultStyles,
        }),
        singleValue: (defaultStyles) => ({ ...defaultStyles, color: "#fff" }),
    };

    return (
        <nav className="navbar navbar-expand-sm navbar-dark bg-info">
            <div className="container-fluid">
                <a className="navbar-brand" href="/login">
                    Big Basket
                </a>
                {
                    location.pathname == '/'
                    &&
                    !location.pathname.startsWith(ADMIN_START_ROUTE_PATH)
                    &&
                    <>
                        <div style={{ width: 600 }}>
                            <Select
                                defaultValue={[]}
                                isMulti
                                closeMenuOnSelect={false}
                                hideSelectedOptions={false}
                                onChange={(options) => {
                                    if(Array.isArray(options)) {
                                        setSelectedOptions(options.map((opt) => opt.value));
                                    }
                                }}
                                options={globalState["all_product_categories"]}
                                components={{
                                    Option: InputOption
                                }}
                                styles={customStyles}
                                className="react-select-container"
                                classNamePrefix="react-select"
                            />
                        </div>
                        <div className="input-group ml-3">
                            <input type="text" className="form-control" placeholder="Search" value={searchProduct} onChange={e => setSearchProduct(e.target.value)} />
                            <button className="btn btn-success" type="submit"><i className="fa fa-search"></i></button>
                        </div>
                    </>
                }
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="mynavbar">
                <ul className="navbar-nav ml-auto">
                    {
                        (
                            !globalState.is_user_authenticated
                            &&
                            !location.pathname.startsWith(ADMIN_START_ROUTE_PATH)
                        )
                        &&
                        <li className={headerNavMenuClass("/login")} style={{ backgroundColor: "#1e7e34", paddingInline: 10 }}>
                            <a className={headerMenuClass("/login")} href={"/login"} style={{ color: "#FFF", fontWeight: "bold" }}>Login</a>
                        </li>
                    }
                    {/* {
                        (
                            !globalState.is_user_authenticated
                            &&
                            location.pathname.startsWith(ADMIN_START_ROUTE_PATH)
                        )
                        &&
                        <li className={headerNavMenuClass("/admin/create-admin")}>
                            <a className={headerMenuClass("/admin/create-admin")} href="/admin/create-admin">Create Admin</a>
                        </li>
                    } */}
                    {
                        (
                            globalState.is_user_authenticated
                            &&
                            location.pathname.startsWith(ADMIN_START_ROUTE_PATH)
                        )
                        &&
                        <>
                            <li className={headerNavMenuClass("/admin/manage-product-variants")}>
                                <a className={headerMenuClass("/admin/manage-product-variants")} href="/admin/manage-product-variants">Create Product Variants</a>
                            </li>
                            <li className={headerNavMenuClass("/admin/manage-product")}>
                                <a className={headerMenuClass("/admin/manage-product")} href="/admin/manage-product">Create Product</a>
                            </li>
                            <li className={headerNavMenuClass("/admin/manage-product-category")}>
                                <a className={headerMenuClass("/admin/manage-product-category")} href="/admin/manage-product-category">Create Category</a>
                            </li>
                            <li className={headerNavMenuClass("/admin/manage-attribute")}>
                                <a className={headerMenuClass("/admin/manage-attribute")} href="/admin/manage-attribute">Create Attribute</a>
                            </li>
                            <li className={headerNavMenuClass("/admin/manage-discount")}>
                                <a className={headerMenuClass("/admin/manage-discount")} href="/admin/manage-discount">Create Discount</a>
                            </li>
                        </>
                    }

                    {
                        !location.pathname.startsWith(ADMIN_START_ROUTE_PATH)
                        &&
                        <li className="nav-item active pointer">
                            <a className="nav-link active pointer " style={{ marginLeft: 10, color: "#FFF", fontWeight: "bold" }}>
                                {
                                    "Items - "+globalState["card_items"]
                                }
                            </a>
                        </li>
                    }

                    {
                        (
                            globalState.is_user_authenticated
                            &&
                            (
                                (globalState.user_detail.name !== undefined)
                                &&
                                (globalState.user_detail.name !== null)
                                &&
                                (globalState.user_detail.name !== '')
                            )
                        )
                        &&
                        <>
                            <li className={headerNavMenuClass("/manager/manager-profile")} style={{ marginLeft: 10, color: "#FFF", fontWeight: "bold" }}>
                                <a className={"nav-link active pointer bg-danger"} href="#" style={{ fontSize: 16, fontWeight: "bold", color: "#FFF" }}>{
                                    globalState.user_detail.name
                                }</a>
                            </li>
                        </>
                    }
                    
                </ul>
                <form className="d-flex ml-2">
                    {
                        globalState.is_user_authenticated
                        &&
                        <a className="btn btn-primary" href={globalState.root_path+'logout'}>Logout</a>
                    }
                </form>
                </div>
            </div>
        </nav>
    )

    
}

export default Header;