import i18next from 'i18next';


export const CURRENT_DAY        =   new Date();

CURRENT_DAY.setHours(23, 59, 59);

export const CURRENT_MONTH      =   new Date().getMonth();
export const CURRENT_YEAR       =   new Date().getFullYear();
export const PREVIOUS_YEAR      =   new Date().getFullYear() - 1;
export const LAST_NINETY_DATE   =   new Date();
const LAST_TEN_YEARS            =   new Date();

LAST_TEN_YEARS.setFullYear(LAST_TEN_YEARS.getFullYear() - 10);
LAST_TEN_YEARS.setHours(23, 59, 59);

LAST_NINETY_DATE.setDate(LAST_NINETY_DATE.getDate() - 90);
LAST_NINETY_DATE.setHours(23, 59, 59);

export const LAST_NINETY_DAYS     =   [new Date(LAST_NINETY_DATE), new Date(CURRENT_DAY)];
export const PREVIOUS_YEARS_ARR =   [new Date(PREVIOUS_YEAR, 0, 1), new Date(PREVIOUS_YEAR, 11, 31, 0, 23, 59, 59)];


let curDay  =   new Date();
let curWeek =   []

for(let i = 1; i <= 7; i++) {
  const first   =   curDay.getDate() - curDay.getDay() + i;
  const day     =   new Date(curDay.setDate(first)).setHours(0, 23, 59, 59);
  console.log('first', day);
  curWeek.push(day)
}

export const WEEK_DAYS      =   ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
//export const WEEK_DAYS      =   ["Su","Mo","Tu","We","Th","Fr","Sa"];
export const MONTH_NAMES    =   ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
//export const MONTH_NAMES    =   ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export const ALL_MONTH_NAMES    =   ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

export const WEEK_DAYS_FULL_NAME    =   {
  [WEEK_DAYS[0]]    :   i18next.t("sunday"),
  [WEEK_DAYS[1]]    :   i18next.t("monday"),
  [WEEK_DAYS[2]]    :   i18next.t("tuesday"),
  [WEEK_DAYS[3]]    :   i18next.t("wednesday"),
  [WEEK_DAYS[4]]    :   i18next.t("thursday"),
  [WEEK_DAYS[5]]    :   i18next.t("friday"),
  [WEEK_DAYS[6]]    :   i18next.t("saturday")
};
export const MONTH_FULL_NAMES       =   {
  [MONTH_NAMES[0]]  :   i18next.t("january"),
  [MONTH_NAMES[1]]  :   i18next.t("February"),
  [MONTH_NAMES[2]]  :   i18next.t("march"),
  [MONTH_NAMES[3]]  :   i18next.t("april"),
  [MONTH_NAMES[4]]  :   i18next.t("may"),
  [MONTH_NAMES[5]]  :   i18next.t("june"),
  [MONTH_NAMES[6]]  :   i18next.t("july"),
  [MONTH_NAMES[7]]  :   i18next.t("august"),
  [MONTH_NAMES[8]]  :   i18next.t("september"),
  [MONTH_NAMES[9]]  :   i18next.t("october"),
  [MONTH_NAMES[10]] :   i18next.t("november"),
  [MONTH_NAMES[11]] :   i18next.t("december")
};

export const THIS_MONTH     =   [new Date(CURRENT_YEAR, CURRENT_MONTH, 1), new Date(CURRENT_YEAR, CURRENT_MONTH + 1, 0, 23, 59, 59)];
export const THIS_YEAR      =   [new Date(CURRENT_YEAR, 0, 1), new Date(CURRENT_YEAR, 11, 31, 0, 23, 59, 59)];
export const THIS_WEEK      =   [new Date(curWeek[0]), new Date(curWeek[curWeek.length - 1])];


console.log('Week', THIS_MONTH, THIS_YEAR, THIS_WEEK);

export const CURRENT_DATES    =   {
    'thisWeek'  :   THIS_WEEK,
    'thisMonth' :   THIS_MONTH,
    'thisYear'  :   THIS_YEAR
};


export const WEEK_TYPE_GRAPH  = {
  [WEEK_DAYS[0]]    :   0.00,
  [WEEK_DAYS[1]]    :   0.00 ,
  [WEEK_DAYS[2]]    :   0.00 ,
  [WEEK_DAYS[3]]    :   0.00,
  [WEEK_DAYS[4]]    :   0.00,
  [WEEK_DAYS[5]]    :   0.00 ,
  [WEEK_DAYS[6]]    :   0.00
};


export const MONTH_TYPE_GRAPH  = {
  [MONTH_NAMES[0]]  :   0.00,
  [MONTH_NAMES[1]]  :   0.00,
  [MONTH_NAMES[2]]  :   0.00,
  [MONTH_NAMES[3]]  :   0.00,
  [MONTH_NAMES[4]]  :   0.00,
  [MONTH_NAMES[5]]  :   0.00,
  [MONTH_NAMES[6]]  :   0.00,
  [MONTH_NAMES[7]]  :   0.00,
  [MONTH_NAMES[8]]  :   0.00,
  [MONTH_NAMES[9]]  :   0.00,
  [MONTH_NAMES[10]] :   0.00,
  [MONTH_NAMES[11]] :   0.00
};

let COUNT = 1;

export const YEAR_TYPE_GRAPH  = {
  [CURRENT_YEAR]                      :   0.00,
  [parseInt(CURRENT_YEAR) - COUNT++]  :   0.00,
  [parseInt(CURRENT_YEAR) - COUNT++]  :   0.00,
  [parseInt(CURRENT_YEAR) - COUNT++]  :   0.00,
  [parseInt(CURRENT_YEAR) - COUNT++]  :   0.00,
  [parseInt(CURRENT_YEAR) - COUNT++]  :   0.00,
  [parseInt(CURRENT_YEAR) - COUNT++]  :   0.00,
  [parseInt(CURRENT_YEAR) - COUNT++]  :   0.00,
  [parseInt(CURRENT_YEAR) - COUNT++]  :   0.00,
  [parseInt(CURRENT_YEAR) - COUNT++]  :   0.00
};

export const ALL_DATES  =   {
    'CURRENT_DAY'           :   CURRENT_DAY,
    'CURRENT_MONTH'         :   CURRENT_MONTH,
    'CURRENT_YEAR'          :   CURRENT_YEAR,
    'PREVIOUS_YEAR'         :   PREVIOUS_YEAR,
    'LAST_NINETY_DATE'      :   LAST_NINETY_DATE,
    'LAST_NINETY_DAYS'      :   LAST_NINETY_DAYS,
    'PREVIOUS_YEARS_ARR'    :   PREVIOUS_YEARS_ARR,
    'WEEK_DAYS'             :   WEEK_DAYS,
    'MONTH_NAMES'           :   MONTH_NAMES,
    'THIS_MONTH'            :   THIS_MONTH,
    'THIS_YEAR'             :   THIS_YEAR,
    'THIS_WEEK'             :   THIS_WEEK,
    'YEAR_TYPE_GRAPH'       :   YEAR_TYPE_GRAPH,
    'MONTH_TYPE_GRAPH'      :   MONTH_TYPE_GRAPH,
    'WEEK_TYPE_GRAPH'       :   WEEK_TYPE_GRAPH,
    'WEEK_DAYS_FULL_NAME'   :   WEEK_DAYS_FULL_NAME,
    'MONTH_FULL_NAMES'      :   MONTH_FULL_NAMES,
    'ALL_MONTH_NAMES'       :   ALL_MONTH_NAMES,
    'LAST_TEN_YEARS'        :   LAST_TEN_YEARS

};