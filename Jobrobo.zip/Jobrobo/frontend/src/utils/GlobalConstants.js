export const ENBALE_UPGRADE_BTN         =   2;

export const MAXIMUM_FILE_SIZE          =   9000000;
export const DEFAULT_PER_PAGE           =   20;

export const ADMIN_START_ROUTE_PATH     =   '/admin/';
export const USER_START_ROUTE_PATH      =   '/';

export const USER_PROFILE               =   'http://localhost:3001/public/profiles/';
export const DOCUMENT_PATH              =   'http://localhost:3001/public/documents/';

//console.log(window.location);

export const COOKIE_NAME    =   "EMP";

const IMAGE_TYPES                   =   [ "image/jpeg", "image/jpg", "image/svg", "image/png" ];
export const VALID_IMAGE_TYPES      =   IMAGE_TYPES.join(",");
export const ALL_VALID_IMAGE_TYPES  =   { 'image/*': ['.jpeg', '.jpg', '.png', '.heic'] };

export const APP_VERSION = '1.9.0';
export const PAGINATION_DEFAULT_OBJECT = { pageRange: 5, total: 0, allFetchedData: [], filteredData: [] };
export const PAGINATION_VALUES  =   { limit: 2, offset: 0 };

export const GENDER_TYPES       =   [
    {
        "value":    "male",
        "label":    "Male"
    },
    {
        "value":    "female",
        "label":    "Female"
    },
    {
        "value":    "transgender",
        "label":    "Transgender"
    }
];