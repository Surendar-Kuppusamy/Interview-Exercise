export const HOST = 'http://localhost:3001/';
export const ADMIN_LOGIN = HOST+'api/admin/login';
export const USER_LOGIN =  HOST+'api/user/login';

export const GET_USER =  HOST+'api/user/get-info';
export const MANAGER_USER   =   HOST+'api/user/manage';

export const GET_SOURCE_API                 =   HOST+'api/admin/get/all-source';

export const GET_PRODUCTS_API               =   HOST+'api/admin/get/all-products';

export const GET_PRODUCT_CATEGORY_API       =   HOST+'api/admin/get/product/category';

export const MANAGE_PRODUCT_CATEGORY_API    =   HOST+'api/admin/manage/product/category';
export const MANAGE_PRODUCT_API             =   HOST+'api/admin/manage/product';
export const MANAGE_DISCOUNT_API            =   HOST+'api/admin/manage/discount';
export const MANAGE_ATTRIBUTE_API           =   HOST+'api/admin/manage/attribute';
export const MANAGE_PRODUCT_VARIANTS_API    =   HOST+'api/admin/manage/product/variants';

export const ALL_API = {
    GET_USER: GET_USER,
    MANAGER_USER: MANAGER_USER,
    ADMIN_LOGIN: ADMIN_LOGIN,
    USER_LOGIN: USER_LOGIN,
    MANAGE_PRODUCT_CATEGORY_API: MANAGE_PRODUCT_CATEGORY_API,
    MANAGE_PRODUCT_API: MANAGE_PRODUCT_API,
    MANAGE_DISCOUNT_API: MANAGE_DISCOUNT_API,
    MANAGE_ATTRIBUTE_API: MANAGE_ATTRIBUTE_API,
    MANAGE_PRODUCT_VARIANTS_API: MANAGE_PRODUCT_VARIANTS_API,

    GET_PRODUCT_CATEGORY_API: GET_PRODUCT_CATEGORY_API,
    GET_SOURCE_API: GET_SOURCE_API,
    GET_PRODUCTS_API: GET_PRODUCTS_API
}
