import axios from 'axios';
import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { isEmpty, findIndex } from 'lodash';
import { ADMIN_START_ROUTE_PATH, USER_START_ROUTE_PATH } from "../utils/GlobalConstants";
import { ADMIN_LOGIN, USER_LOGIN, ALL_API } from '../utils/Apiconstants';

axios.interceptors.request.use(function (config) {
    config.headers['Authorization'] = `Bearer ${(localStorage.getItem("token")? localStorage.getItem("token") : '')}`;
    config.headers['Content-Type'] = 'application/json';
    return config;
}, null, { synchronous: true });

function stringToBoolean(value){
    return (String(value).toLowerCase() === 'true');
}

function getRootPath() {
    const isRootPathExists  =   localStorage.getItem('root_path');
    //console.log(window.location.pathname, 'window.location.pathname');
    const pathName          =   window.location.pathname;
    if(pathName.startsWith(ADMIN_START_ROUTE_PATH)) {
        return ADMIN_START_ROUTE_PATH;
    } else if(isRootPathExists) {
        return localStorage.getItem('root_path');
    } else {
        return USER_START_ROUTE_PATH;
    }
}

function clearLocalStorage() {
    localStorage.removeItem('is_user_authenticated');
    localStorage.removeItem('is_customer_authenticated');
    localStorage.removeItem('is_admin_authenticated');
    localStorage.removeItem('user_detail');
    localStorage.removeItem('root_path');
    localStorage.removeItem('token');
    localStorage.removeItem('all_products');
    localStorage.removeItem('all_product_categories');
    
}

const resetValues     =   {
    'root_path'                     :   '',
    'token'                         :   '',
    'site_loader'                   :   false,
    'page_loader'                   :   false,
    'first_load'                    :   true,
    'manual_site_loader'            :   false,
    'is_logout'                     :   false,
    'is_user_authenticated'         :   false,
    'is_customer_authenticated'     :   false,
    'is_admin_authenticated'        :   false,
    'pending_actions'               :   [],
    'user_detail'                   :   {},
    'all_product_categories'        :   [],
    'all_products'                  :   [],
    'card_items'                    :   0
}


const initialState = {
    'site_loader'                   :   false,
    'page_loader'                   :   false,
    'first_load'                    :   true,
    'manual_site_loader'            :   false,
    'is_logout'                     :   false,
    'pending_actions'               :   [],
    'root_path'                     :   getRootPath(),
    'token'                         :   localStorage.getItem('token')
                                            ? localStorage.getItem('token')
                                            : '',
    'user_detail'                   :   localStorage.getItem('user_detail')
                                            ? JSON.parse(localStorage.getItem('user_detail'))
                                            : {},
    'is_user_authenticated'         :   localStorage.getItem('is_user_authenticated')
                                            ? stringToBoolean(localStorage.getItem('is_user_authenticated'))
                                            : false,
    'is_customer_authenticated'     :   localStorage.getItem('is_customer_authenticated')
                                            ? stringToBoolean(localStorage.getItem('is_customer_authenticated'))
                                            : false,
    'is_admin_authenticated'        :   localStorage.getItem('is_admin_authenticated')
                                            ? stringToBoolean(localStorage.getItem('is_admin_authenticated'))
                                            : false,
    'all_product_categories'        :   localStorage.getItem('all_product_categories')
                                            ? JSON.parse(localStorage.getItem('all_product_categories'))
                                            : [],
    'all_products'                  :   localStorage.getItem('all_products')
                                            ? JSON.parse(localStorage.getItem('all_products'))
                                            : [],
    'card_items'                    :   localStorage.getItem('card_items')
                                            ? localStorage.getItem('card_items')
                                            : 0,
}

export const loginUser = createAsyncThunk(
    "user/login",
    async (loginData, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {

            let USER_LOGIN_API  =   USER_LOGIN;

            const { data } = await axios.post(
                USER_LOGIN_API,
                loginData
            );

            console.log("data", data);
            resolve({ api: data, type: loginData.type });

        });        
    }
);

export const getUserInfo = createAsyncThunk(
    "user/add/edit/api",
    async (filter, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {

            const { data } = await axios.post(
                ALL_API["GET_USER"],
                filter
            );

            console.log("data", data);
            resolve(data);

        });
    }
);

export const userAddEditApi = createAsyncThunk(
    "user/add/edit/api",
    async (userData, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {

            let USER_API  =   ALL_API["MANAGER_USER"];

            let day = new Date(userData["dob"]).getDate();
            let month = new Date(userData["dob"]).getMonth();
            let year = new Date(userData["dob"]).getFullYear();

            month   =   month + 1;
            month   =   (month > 9) ? month : '0'+month;
            day     =   (day > 9) ? day : '0'+day;
            userData["dob"] =   year+'-'+month+'-'+day;

            console.log(userData["dob"], " ---Tet");

            var formData = new FormData();
            for (const [key, value] of Object.entries(userData)) {
                
                if(key == "profile_image_file" && value != null && value.length > 0) {
                    formData.append("profile_image_file", value[0], value[0]["name"]);
                } else if(key == "id" && value != null && value != '') {
                    formData.append(key, value);
                } else if(key != "profile_image_file" && key != "id") {
                    formData.append(key, value);
                }
            }
            
            const { data } = await axios.post(USER_API, formData, {
                headers: {
                    'Content-Type': `multipart/form-data; boundary=${formData._boundary}`,
                }
            });

            console.log("data", data);

            resolve(data);
        });        
    }
);

export const getProductCategoryAPI = createAsyncThunk(
    "get/product/category/api",
    async (formData, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {

            let API_URL  =   ALL_API["GET_PRODUCT_CATEGORY_API"];

            const { data } = await axios.post(
                API_URL,
                formData
            );

            console.log("data", data);
            resolve(data);

        });        
    }
);

export const getAllOptions = createAsyncThunk(
    "get/all/options",
    async (formData, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {

            let API_URL  =   ALL_API["GET_SOURCE_API"];

            const { data } = await axios.get(
                API_URL
            );

            console.log("data", data);
            resolve(data);

        });        
    }
);

export const getProductAll = createAsyncThunk(
    "get/product/all",
    async (formData, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {

            let API_URL  =   ALL_API["GET_PRODUCTS_API"];

            const { data } = await axios.post(
                API_URL,
                formData
            );

            console.log("data", data);
            resolve(data);

        });        
    }
);


export const manageProductCategoryAPI = createAsyncThunk(
    "manage/product/category/api",
    async (formData, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {

            let API_URL  =   ALL_API["MANAGE_PRODUCT_CATEGORY_API"];

            const { data } = await axios.post(
                API_URL,
                formData
            );

            console.log("data", data);
            resolve(data);

        });        
    }
);

export const manageProductVariantsAPI = createAsyncThunk(
    "manage/product/variants/api",
    async (formValues, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {

            let API_URL  =   ALL_API["MANAGE_PRODUCT_VARIANTS_API"];

            var formData = new FormData();

            for (const [key, value] of Object.entries(formValues)) {
                
                if(key == "image" && value != null && value.length > 0) {
                    formData.append("image", value[0], value[0]["name"]);
                } else if(key == "id" && value != null && value != '') {
                    formData.append(key, value);
                } else if(key == "discount_id" && value != null && value != '') {
                    formData.append(key, value);
                } else if(key != "image" && key != "id" && key != "discount_id") {
                    formData.append(key, value);
                }
            }


            const { data } = await axios.post(
                API_URL,
                formData
            );

            console.log("data", data);
            resolve(data);

        });        
    }
);

export const manageProductAPI = createAsyncThunk(
    "manage/product/api",
    async (formValues, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {

            let API_URL  =   ALL_API["MANAGE_PRODUCT_API"];

            var formData = new FormData();

            for (const [key, value] of Object.entries(formValues)) {
                
                if(key == "image" && value != null && value.length > 0) {
                    formData.append("image", value[0], value[0]["name"]);
                } else if(key == "id" && value != null && value != '') {
                    formData.append(key, value);
                } else if(key == "discount_id" && value != null && value != '') {
                    formData.append(key, value);
                } else if(key != "image" && key != "id" && key != "discount_id") {
                    formData.append(key, value);
                }
            }

            const { data } = await axios.post(
                API_URL,
                formData
            );

            console.log("data", data);
            resolve(data);

        });        
    }
);

export const manageAttributeAPI = createAsyncThunk(
    "manage/attribute/api",
    async (formData, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {

            let API_URL  =   ALL_API["MANAGE_ATTRIBUTE_API"];

            const { data } = await axios.post(
                API_URL,
                formData
            );

            console.log("data", data);
            resolve(data);

        });        
    }
);


export const manageDiscountAPI = createAsyncThunk(
    "manage/discount/api",
    async (formData, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {

            let API_URL  =   ALL_API["MANAGE_DISCOUNT_API"];

            const { data } = await axios.post(
                API_URL,
                formData
            );

            console.log("data", data);
            resolve(data);

        });        
    }
);



export const logoutUser = createAsyncThunk(
    "user/logout",
    async(data, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {
            resolve(data);
        });
    }
);



const globalSlice = createSlice({
    name: "global",
    initialState,
    reducers: {
        siteLoader: (state, action) => {
            state['site_loader'] = action.payload;
        },
        setUserDetails: (state, action) => {
            state["user_detail"]    =   action.payload;
        },
        resetState: (state, action) => {

            clearLocalStorage();

            state['user_detail']                   =   {};
            state['is_user_authenticated']         =   false;
            state['is_customer_authenticated']     =   false;
            state['is_admin_authenticated']        =   false;
        },
        setRootPath: (state, action) => {
            state['root_path'] = action.payload;
            localStorage.setItem('root_path', action.payload);
        },
        pageLoader: (state, action) => {
            state['page_loader'] = action.payload;
        },
        setFirstTimeLoad: (state, action) => {
            state['first_load'] = action.payload;
        },
        setUserAuthenticated: (state, action) => {
            state['is_user_authenticated'] = true;
            state['site_loader'] = true;
        },
        setManualSiteLoader: (state, action) => {
            state['manual_site_loader'] =   action.payload;
        },
        setAllProductCategories: (state, action) => {
            state['all_product_categories'] =   action.payload;
        },
        setAllProducts: (state, action) => {
            state['all_products'] =   action.payload;
        },
        setCardItem: (state, action) => {
            if(action.payload == "plus") {
                state['card_items'] =   parseInt(state['card_items'] + 1);
            } else if(action.payload == "minus") {

                if((state['card_items'] - 1) <= 0) {
                    state['card_items'] =   0;
                } else {
                    state['card_items'] =   parseInt(state['card_items'] - 1);
                }
            }
            
        }
    },
    extraReducers: (builder) => {
        builder
            .addCase(loginUser.fulfilled, (state, action) => {

                console.log('User signup response', action.payload);

                if(action.payload.api.status === 'success') {

                    state['token']  =   action.payload.api.token;
                    localStorage.setItem('token', action.payload.api.token);

                    state['user_detail']    =   action.payload.api.user[0];
                    localStorage.setItem('user_detail', JSON.stringify(action.payload.api.user[0]));

                    state['is_user_authenticated']  =   true;
                    localStorage.setItem('is_user_authenticated', true);

                    if(action.payload.type == 1) {
                        state['is_admin_authenticated']  =   true;
                        localStorage.setItem('is_admin_authenticated', true);
                    } else {
                        state['is_customer_authenticated']  =   true;
                        localStorage.setItem('is_customer_authenticated', true);
                    }
                    
                }
                
            })
            .addCase(logoutUser.fulfilled, (state, action) => {

                console.log("logut Global slice");

                clearLocalStorage();

                state['user_detail']                    =   {};
                state['is_user_authenticated']          =   false; 
                state['is_customer_authenticated']      =   false;
                state['is_admin_authenticated']         =   false;
                state['all_product_categories']         =   [];
                state['all_products']                   =   [];
        
            })
            .addMatcher(
                (action) => action.type.endsWith('/pending'),
                (state, action) => {

                    state['pending_actions'].push(action.type)

                    if(!state['site_loader']) {
                        state['site_loader'] = true;
                    }
                }
            )
            .addMatcher(
                (action) => action.type.endsWith('/rejected'),
                (state, action) => {
                    var actionType  =   action.type;
                    actionType = actionType.replace("rejected", "pending")

                    var index = state['pending_actions'].indexOf(actionType);
                    if(index !== -1) {
                        state['pending_actions'].splice(index, 1);

                        if(state['site_loader'] && state['pending_actions'].length === 0) {
                            state['site_loader']    =   false;
                        }
                    } else {
                        if(state['site_loader'] && state['pending_actions'].length === 0) {
                            state['site_loader'] = false;
                        }
                    }

                }
            )
            .addMatcher(
                (action) => action.type.endsWith('/fulfilled'),
                (state, action) => {
                    var actionType  =   action.type;
                    actionType = actionType.replace("fulfilled", "pending");

                    var index = state['pending_actions'].indexOf(actionType);
                    if(index !== -1) {
                        state['pending_actions'].splice(index, 1);

                        if(state['site_loader'] && state['pending_actions'].length === 0) {
                            state['site_loader']    =   false;
                        }
                    } else {
                        if(state['site_loader'] && state['pending_actions'].length === 0) {
                            state['site_loader'] = false;
                        }
                    }

                    if(actionType   ===  'user/auto/logout/pending') {
                        const tempActions   =   state['pending_actions'];
                        for(var i = 0; i < tempActions.length; i++) {
                            if(state['pending_actions'][i] === 'user/auto/logout/pending') {
                                state['pending_actions'].splice(i, 1);
                            }
                        }
                    }
                }
            )
    }
});


// Action creators are generated for each case reducer function
export const { siteLoader,  resetState, setUserDetails, pageLoader, setRootPath, setManualSiteLoader, setManagerAuthenticated, setEmployeeAuthenticated, setUserAuthenticated, signOut, setAllProductCategories, setAllProducts, setCardItem, signIn } = globalSlice.actions;

const { reducer } = globalSlice;
export default reducer;