import React, { Suspense, lazy, useEffect, useCallback, useMemo } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { BrowserRouter as Router, Navigate, useLocation, useNavigate, Routes, Route, useRoutes } from "react-router-dom";
import ConfiguredRoutes from './ConfiguredRoutes';


function stringToBoolean(value){
    return (String(value).toLowerCase() === 'true');
}

const Container                 =   React.lazy(() => import('../components/Container'));

function AllRoutes(props) {
    const dispatch              =   useDispatch();
    const navigate              =   useNavigate();
    const location              =   useLocation();
    const globalState           =   props.globalState;
    

    /* const isCpaAuthenticated        =   globalState.is_cpa_authenticated;
    const isBusinessAuthenticated   =   globalState.is_business_authenticated; */

    const isCustomerAuthenticated   =   localStorage.getItem('is_customer_authenticated')
                                                ? stringToBoolean(localStorage.getItem('is_customer_authenticated'))
                                                : false;

    const isAdminAuthenticated      =   localStorage.getItem('is_admin_authenticated')
                                                ? stringToBoolean(localStorage.getItem('is_admin_authenticated'))
                                                : false;

    const rootPath                  =   globalState["root_path"];

    const allRouting = useRoutes(ConfiguredRoutes(rootPath, globalState, isCustomerAuthenticated, isAdminAuthenticated));

    return (
        <Container>
            {allRouting}
        </Container>
    );
}


export default AllRoutes;
