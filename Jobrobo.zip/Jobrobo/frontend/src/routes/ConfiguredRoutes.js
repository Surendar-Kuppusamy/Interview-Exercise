import React, { Suspense, lazy, useEffect, useCallback, useMemo } from 'react';
import { Navigate } from "react-router-dom";
import { ADMIN_START_ROUTE_PATH, USER_START_ROUTE_PATH } from '../utils/GlobalConstants';


//Ladning Pages
const Container                 =   React.lazy(() => import('../components/Container'));

//const Signup                    =   React.lazy(() => import('../pages/auth/Signup'));
const Login                     =   React.lazy(() => import('../pages/auth/Login'));
const LogoutUser                =   React.lazy(() => import('../pages/auth/LogoutUser'));


//const Modals                    =   React.lazy(() => import('../components/Modals'));
//const Profile                   =   React.lazy(() => import('../pages/user/Profile'));
const ProductList               =   React.lazy(() => import('../pages/user/ProductList'));

const ManageProductCategory     =   React.lazy(() => import('../pages/admin/ManageProductCategory'));
const ManageDiscount            =   React.lazy(() => import('../pages/admin/ManageDiscount'));
const ManageAttribute           =   React.lazy(() => import('../pages/admin/ManageAttribute'));
const ManageProduct             =   React.lazy(() => import('../pages/admin/ManageProduct'));

const ManageProductVariants     =   React.lazy(() => import('../pages/admin/ManageProductVariants'));




const AddUpdateUser             =   React.lazy(() => import('../pages/user/AddUpdateUser'));




function stringToBoolean(value){
    return (String(value).toLowerCase() === 'true');
}


const ConfiguredRoutes = (rootPath, globalState, isCustomerAuthenticated, isAdminAuthenticated) => {


    let authNavigatePath            =   '';
    let unAuthNavigatePath          =   '';

    if(isAdminAuthenticated === true) {
        rootPath    =   ADMIN_START_ROUTE_PATH;
    }/*  else {
        rootPath    =   USER_START_ROUTE_PATH;
    } */

    switch (rootPath) {
        case USER_START_ROUTE_PATH:

            if(!isCustomerAuthenticated) {
                authNavigatePath    =   rootPath;
            } else {
                unAuthNavigatePath  =   rootPath;
            }

            return [
                {
                    path: rootPath+'logout',
                    element: <LogoutUser />
                },
                {
                    path: '/logout',
                    element: <LogoutUser />
                },
                {
                    path: rootPath+'signup',
                    element: (unAuthNavigatePath === '') ? <AddUpdateUser /> : <Navigate to={unAuthNavigatePath} />
                },
                {
                    path: rootPath+'login',
                    element: (unAuthNavigatePath === '') ? <Login /> : <Navigate to={unAuthNavigatePath} />
                },
                {
                    path: '/',
                    element: <ProductList />
                },
                {
                    path: '*',
                    element: <Navigate to={'/'} />
                }
            ]
        break;
        case ADMIN_START_ROUTE_PATH:
            rootPath    =   ADMIN_START_ROUTE_PATH;

            if(!isAdminAuthenticated) {
                authNavigatePath    =   rootPath+'login';
            } else {
                unAuthNavigatePath  =   rootPath+'manage-product-category';
            }

            return [
                {
                    path: rootPath+'logout',
                    element: <LogoutUser />
                },
                {
                    path: '/logout',
                    element: <LogoutUser />
                },
                {
                    path: rootPath+'create-admin',
                    element: <AddUpdateUser />
                },
                {
                    path: rootPath+'login',
                    element: (unAuthNavigatePath === '') ? <Login /> : <Navigate to={unAuthNavigatePath} />
                },
                {
                    path: rootPath+'update-admin',
                    element: (authNavigatePath === '') ? <AddUpdateUser /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'manage-product-category',
                    element: (authNavigatePath === '') ? <ManageProductCategory /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'manage-discount',
                    element: (authNavigatePath === '') ? <ManageDiscount /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'manage-product-variants',
                    element: (authNavigatePath === '') ? <ManageProductVariants /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'manage-attribute',
                    element: (authNavigatePath === '') ? <ManageAttribute /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'manage-product',
                    element: (authNavigatePath === '') ? <ManageProduct /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: rootPath+'manage-product-category/:id',
                    element: (authNavigatePath === '') ? <ManageProductCategory /> : <Navigate to={authNavigatePath} />
                },
                {
                    path: '*',
                    element: <Navigate to={rootPath+'login'} />
                }
            ]
        break;
        default:
            rootPath    =   USER_START_ROUTE_PATH;
            return [
                {
                    path: '*',
                    element: <Navigate to={rootPath+'login'} />
                }
            ]
    }
};

export default ConfiguredRoutes;