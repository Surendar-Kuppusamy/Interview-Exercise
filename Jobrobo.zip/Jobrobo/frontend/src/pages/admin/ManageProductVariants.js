import React, { Suspense, useEffect, useState, useRef } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { useForm, Controller } from "react-hook-form";
import Select from "react-select";
import { toast } from 'react-toastify';
import { yupResolver } from "@hookform/resolvers/yup";
import Loader from '../../components/Loader';
import PageLoader from '../../components/PageLoader';
import { ProductCategorySchema, ProductSchema, ProductVariantSchema } from '../../utils/ValidationSchemas';
import { getProductCategoryAPI, getAllOptions, manageProductCategoryAPI, manageProductAPI, manageProductVariantsAPI, getProductAll } from '../../slices/globalSlice';
import { ADMIN_START_ROUTE_PATH, COOKIE_NAME } from '../../utils/GlobalConstants.js';

const AvatarUpload   =   React.lazy(() => import('../../components/AvatarUpload'));


function ManageProductVariants(props) {

    const dispatch      =   useDispatch();
    const navigate      =   useNavigate();
    const location      =   useLocation();
    const globalState   =   useSelector(state => state.global);
    const { id }        =   useParams();

    const imageRef                                  =   useRef();
    const productRef                                =   useRef();
    const attributeRef                              =   useRef();
    const discountRef                               =   useRef();

    const [allOptions, setAllOptions]               =   useState([]);
    const [products, setProducts]                   =   useState([]);
    const [productCategories, setProductCategories] =   useState([]);
    const [discounts, setDiscounts]                 =   useState([]);
    const [attributes, setAttributes]               =   useState([]);

    var type = 2;

    if(location.pathname.startsWith(ADMIN_START_ROUTE_PATH)) {
        type    =   1;
    }

    const [uploadImage, setUploadImage] =   useState(null);

    useEffect(() => {
        if(uploadImage != null && uploadImage.length > 0) {
            setValue("image", uploadImage);
        } else {
            setValue("image", []);
        }
        
    }, [uploadImage])

    const defaultValues = {
        id: (id !== undefined && id !== null && id !== '') ? id : "",
        product_id: "",
        image:"",
        attribute_id: "",
        attribute_value: "",
        discount_id: "",
        price: "",
        status: "1"
    };

    useEffect(() => {

        if(id !== undefined && id !== null && id !=='') {

            /* dispatch(getProductCategoryAPI({ id: id }))
                .unwrap()
                .then(response => {

                    if(response?.status != "success") {
                        toast.error(response?.message, {theme: "colored"});
                        return false;
                    }

                    const { description, name, status }   =   response.data;

                    setValue("description", description);
                    setValue("name", description);
                    setValue("status", parseInt(status));
                    
                })
                .catch(e => {
                    console.log('Login error find', e.message);
                    toast.error(e.message, {theme: "colored"});
                }); */
            
        }

        dispatch(getAllOptions({  }))
                .unwrap()
                .then(response => {

                    if(response?.status != "success") {
                        toast.error(response?.message, {theme: "colored"});
                        return false;
                    }

                    if(Array.isArray(response.data) && response.data.length > 0) {
                        response.data.forEach((val) => {
                            if(val._id === 'product_category_options') {
                                setProductCategories(val.options);
                            } else if(val._id === 'attribute_options') {
                                setAttributes(val.options);
                            } else if(val._id === 'discount_options') {
                                setDiscounts(val.options);
                            } else if(val._id === 'product_options') {
                                setProducts(val.options);
                            }
                        });
                    }
                    
                })
                .catch(e => {
                    console.log('Login error find', e.message);
                    toast.error(e.message, {theme: "colored"});
                });

                dispatch(getProductAll({  }))
                    .unwrap()
                    .then(response => {

                        if(response?.status != "success") {
                            toast.error(response?.message, {theme: "colored"});
                            return false;
                        }

                        console.log("Products", response.data);
                        
                    })
                    .catch(e => {
                        console.log('Login error find', e.message);
                        toast.error(e.message, {theme: "colored"});
                    });

                

        

    }, [id]);

    const { register, handleSubmit, setValue, control, watch, reset, formState: { errors } } = useForm({ defaultValues: defaultValues, resolver: yupResolver(ProductVariantSchema) });

    const onSubmit = (formData) => {
        console.log(formData);

        if(uploadImage == null) {
            toast.error("Upload product image.", {theme: "colored"});
            return false;
        }

        dispatch(manageProductVariantsAPI(formData))
            .unwrap()
            .then(response => {

                console.log("response", response);

                if(response?.status != "success") {
                    toast.error(response?.message, {theme: "colored"});
                    return false;
                }

                toast.success(response.message, {theme: "colored"});
                reset(defaultValues);
                productRef.current.setValue('');
                attributeRef.current.setValue('');
                discountRef.current.setValue('');
                imageRef.current.removeAllFromParent();
            })
            .catch(e => {
                console.log('Login error find', e.message);
                toast.error(e.message, {theme: "colored"});
            });
    };

    return (
        <Suspense fallback={<Loader />}>
            <section id="product" className="login mx-auto" style={{ width: 400, marginTop: 50 }}>
                <h1>
                    Add Product Variants
                </h1>
                <form onSubmit={handleSubmit(onSubmit)} className="was-validated">

                    <AvatarUpload
                        ref={imageRef}
                        fileState={uploadImage}
                        setValue={setUploadImage}
                        isDragable={false}
                        isMultipleFileUpload={false}
                        maxFileSize={5 * 1024 * 1024}
                        maxFiles={1}
                        fileTypes={{
                            'image/jpg': [],
                            'image/jpeg': [],
                            'image/png': []
                        }}
                    />

                    <div className="mt-2 mb-2">
                        <div>
                            Select Product
                        </div>
                        <Controller
                            control={control}
                            rules={{
                            required: true,
                            }}
                            render={({ field: { onChange, onBlur, value } }) => (
                                <Select 
                                    onBlur={onBlur}
                                    onChangeText={onChange}
                                    onChange={(val) =>  onChange(val.value) }
                                    value={products.find(c => c.value === value)}
                                    options={products} 
                                    ref={productRef}
                                />
                            )}
                            name="product_id"
                        />

                        <div className="text-danger">{errors?.product_id?.message}</div>
                    </div>

                    <div className="mt-2 mb-2">
                        <div>
                            Select Attribute
                        </div>
                        <Controller
                            control={control}
                            rules={{
                            required: true,
                            }}
                            render={({ field: { onChange, onBlur, value } }) => (
                                <Select 
                                    onBlur={onBlur}
                                    onChangeText={onChange}
                                    onChange={(val) =>  onChange(val.value) }
                                    value={attributes.find(c => c.value === value)}
                                    options={attributes} 
                                    ref={attributeRef}
                                />
                            )}
                            name="attribute_id"
                        />

                        <div className="text-danger">{errors?.attribute_id?.message}</div>
                    </div>
                        
                    <div className="mb-3 mt-3">
                        <label htmlFor="name" className="form-label">Attribute Value</label>
                        <input className="form-control" type="text" name="attribute_value" id="attribute_value" placeholder="Enter Name" {...register("attribute_value")} />
                        <div className="text-danger">{errors?.attribute_value?.message}</div>
                    </div>

                    <div className="mb-3 mt-3">
                        <label htmlFor="price" className="form-label">Price</label>
                        <input className="form-control" type="text" name="price" id="price" placeholder="Enter price" {...register("price")} />
                        <div className="text-danger">{errors?.price?.message}</div>
                    </div>


                    <div className="mt-2 mb-2">
                        <div>
                            Select Discount(Optional)
                        </div>
                        <Controller
                            control={control}
                            rules={{
                            required: true,
                            }}
                            render={({ field: { onChange, onBlur, value } }) => (
                                <Select 
                                    onBlur={onBlur}
                                    onChangeText={onChange}
                                    onChange={(val) =>  onChange(val.value) }
                                    value={discounts.find(c => c.value === value)}
                                    options={discounts} 
                                    ref={discountRef}
                                />
                            )}
                            name="discount_id"
                        />

                        <div className="text-danger">{errors?.discount_id?.message}</div>
                    </div>
                    


                    <div className="form-check">
                        <label className="form-check-label" htmlFor="active">
                            <input className="form-check-input" name="status" id="active" {...register("status")} type="radio" value="1" />
                            Active
                        </label>
                    </div>
                    <div className="form-check">
                        <label className="form-check-label" htmlFor="inactive">
                            <input className="form-check-input" name="status" id="inactive" {...register("status")} type="radio" value="2" />
                            Inactive
                        </label>
                    </div>
                    <div className="text-danger">{errors.status?.message}</div>

                    <div className="text-center">
                        <button type="submit" className="btn btn-info" id="submit" name="submit">
                            {
                                (id !== undefined && id !== null && id !== '')
                                ? 'Update'
                                : 'Add'
                            }
                        </button>
                    </div>
                </form>
            </section>
        </Suspense>
    );
}

export default ManageProductVariants;