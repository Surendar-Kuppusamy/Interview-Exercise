import React, { Suspense, useEffect, useState } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { useForm } from "react-hook-form";
import { toast } from 'react-toastify';
import { yupResolver } from "@hookform/resolvers/yup";
import Loader from '../../components/Loader';
import PageLoader from '../../components/PageLoader';
import { ProductCategorySchema } from '../../utils/ValidationSchemas';
import { getProductCategoryAPI, manageProductCategoryAPI } from '../../slices/globalSlice';
import { ADMIN_START_ROUTE_PATH, COOKIE_NAME } from '../../utils/GlobalConstants.js';


function ManageProductCategory(props) {

    const dispatch      =   useDispatch();
    const navigate      =   useNavigate();
    const location      =   useLocation();
    const globalState   =   useSelector(state => state.global);
    const { id }        =   useParams();

    var type = 2;

    if(location.pathname.startsWith(ADMIN_START_ROUTE_PATH)) {
        type    =   1;
    }

    const defaultValues = {
        id: (id !== undefined && id !== null && id !== '') ? id : "",
        name: "",
        description: "",
        status: "1"
    };

    useEffect(() => {

        if(id !== undefined && id !== null && id !=='') {

            dispatch(getProductCategoryAPI({ id: id }))
                .unwrap()
                .then(response => {

                    if(response?.status != "success") {
                        toast.error(response?.message, {theme: "colored"});
                        return false;
                    }

                    const { description, name, status }   =   response.data;

                    setValue("description", description);
                    setValue("name", description);
                    setValue("status", parseInt(status));
                    
                })
                .catch(e => {
                    console.log('Login error find', e.message);
                    toast.error(e.message, {theme: "colored"});
                });
            
        }

    }, [id]);

    const { register, handleSubmit, setValue, watch, reset, formState: { errors } } = useForm({ defaultValues: defaultValues, resolver: yupResolver(ProductCategorySchema) });

    const onSubmit = (formData) => {
        console.log(formData);
        dispatch(manageProductCategoryAPI(formData))
            .unwrap()
            .then(response => {

                console.log("response", response);

                if(response?.status != "success") {
                    toast.error(response?.message, {theme: "colored"});
                    return false;
                }

                toast.success("Product category updated.", {theme: "colored"});
                reset(defaultValues);
            })
            .catch(e => {
                console.log('Login error find', e.message);
                toast.error(e.message, {theme: "colored"});
            });
    };

    return (
        <Suspense fallback={<Loader />}>
            <section id="product_category" className="login mx-auto" style={{ width: 400, marginTop: 50 }}>
                <h1>
                    Product Category
                </h1>
                <form onSubmit={handleSubmit(onSubmit)} className="was-validated">

                    <div className="mb-3 mt-3">
                        <label htmlFor="name" className="form-label">Name</label>
                        <input className="form-control" type="text" name="name" id="name" placeholder="Enter Name" {...register("name")} />
                        <div className="text-danger">{errors?.name?.message}</div>
                    </div>

                    <div className="mb-3 mt-3">
                        <label htmlFor="description">Description</label>
                        <textarea className="form-control" name="description" id="description" {...register("description")}></textarea>
                        <div className="text-danger">{errors?.description?.message}</div>
                    </div>

                    <div className="form-check">
                        <label className="form-check-label" htmlFor="active">
                            <input className="form-check-input" name="status" id="active" {...register("status")} type="radio" value="1" />
                            Active
                        </label>
                    </div>
                    <div className="form-check">
                        <label className="form-check-label" htmlFor="inactive">
                            <input className="form-check-input" name="status" id="inactive" {...register("status")} type="radio" value="2" />
                            Inactive
                        </label>
                    </div>
                    <div className="text-danger">{errors.status?.message}</div>

                    <div className="text-center">
                        <button type="submit" className="btn btn-info" id="submit" name="submit">
                            {
                                (id !== undefined && id !== null && id !== '')
                                ? 'Update'
                                : 'Add'
                            }
                        </button>
                    </div>
                </form>
            </section>
        </Suspense>
    );
}

export default ManageProductCategory;