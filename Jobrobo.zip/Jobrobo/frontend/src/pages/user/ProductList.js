import React, { Suspense, useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useForm } from "react-hook-form";
import Loader from '../../components/Loader';
import PageLoader from '../../components/PageLoader';
import {  } from '../../slices/globalSlice';
import { useLocation, useParams } from 'react-router-dom';
import { DEFAULT_PER_PAGE, USER_PROFILE, DOCUMENT_PATH, ADMIN_START_ROUTE_PATH } from '../../utils/GlobalConstants';
import { keys } from 'lodash';
import { toast } from 'react-toastify';

const Product   =   React.lazy(() => import('../../components/Product'));

function ProductList(props) {

    const dispatch      =   useDispatch();
    const location      =   useLocation();
    const { id }        =   useParams();
    const globalState   =   useSelector(state => state.global);

    var temp_type = 2;
    
    if(location.pathname.startsWith(ADMIN_START_ROUTE_PATH)) {
        temp_type = 1;
    }

    const [type, setType] =   useState(temp_type);
    

    return (
        <Suspense fallback={<Loader />}>
            <section id="productlist" className="productlist">
                <div className="container">

                    {
                        (
                            globalState["all_products"] !== undefined
                            &&
                            globalState["all_products"] !== null
                            &&
                            Array.isArray(globalState["all_products"])
                            &&
                            globalState["all_products"].length > 0
                        )
                        &&
                        <>
                            <div className="row">
                                {
                                    (
                                        globalState["all_products"] != undefined
                                        &&
                                        Array.isArray(globalState["all_products"])
                                        &&
                                        globalState["all_products"].length > 0
                                    )
                                    &&
                                    globalState["all_products"].map((product, i) => {
                                        return (
                                            <React.Fragment key={i}>
                                                
                                                {
                                                    <div className="col-md-4" style={{padding:"15px"}} key={i}>

                                                        <h4 className="mt-3 mb-2">
                                                            {
                                                                (
                                                                    globalState["all_products"][i]["category"] !== undefined
                                                                    &&
                                                                    Array.isArray(globalState["all_products"][i]["category"])
                                                                    &&
                                                                    globalState["all_products"][i]["category"].length > 0
                                                                    &&
                                                                    (
                                                                        (
                                                                            (i - 1) >= 0
                                                                            &&
                                                                            Array.isArray(globalState["all_products"][i - 1]["category"])
                                                                            &&
                                                                            globalState["all_products"][i - 1]["category"].length > 0
                                                                            &&
                                                                            globalState["all_products"][i - 1]["category"][0] != globalState["all_products"][i]["category"][0]
                                                                        )
                                                                        ||
                                                                        (
                                                                            i == 0
                                                                        )
                                                                    )
                                                                )
                                                                &&
                                                                globalState["all_products"][i]["category"][0]
                                                            }
                                                        </h4>

                                                        <Product product={product.product} id={product._id} />
                                                    </div>
                                                }
                                                {/* {
                                                    (
                                                        product.product !== undefined
                                                        &&
                                                        product.product !== null
                                                        &&
                                                        Array.isArray(product.product)
                                                        &&
                                                        product.product.length > 0
                                                    )
                                                    &&
                                                    <>
                                                        {
                                                            product.product.map((prod, i) => {
                                                                return(
                                                                    <div className="col-md-4" style={{padding:"15px"}} key={i}>
                                                                        <Product product={prod} />
                                                                    </div>
                                                                )
                                                            })
                                                        }
                                                    </>
                                                } */}
                                                
                                            </React.Fragment>
                                        )
                                    })
                                }
                            </div>
                        </>
                    }

                    {
                        !(
                            globalState["all_products"] !== undefined
                            &&
                            globalState["all_products"] !== null
                            &&
                            Array.isArray(globalState["all_products"])
                            &&
                            globalState["all_products"].length > 0
                        )
                        &&
                        <div className="row text-center">
                            <div className="col-md-4 text-center" style={{padding:"15px"}}>
                                <h1 className="text-center">
                                    No Product Found
                                </h1>
                                
                            </div>
                        </div>
                    }
                </div>
            </section>
        </Suspense>
    );
}

export default ProductList;