import { configureStore, createListenerMiddleware } from '@reduxjs/toolkit';
import globalReducer from '../slices/globalSlice';


const reducer = {
	global		:	globalReducer
};

const store = configureStore({
	reducer: reducer,
	middleware: (getDefaultMiddleware) => getDefaultMiddleware({ serializableCheck: false }),
	devTools: (process.env.REACT_APP_ENV === 'dev'),
});

export default store;