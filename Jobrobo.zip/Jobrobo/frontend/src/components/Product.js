import React, { Suspense, useEffect, useState, memo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useForm } from "react-hook-form";
import Loader from '../components/Loader';
import { setCardItem } from '../slices/globalSlice';
import { useLocation, useParams } from 'react-router-dom';
import { DEFAULT_PER_PAGE, USER_PROFILE, DOCUMENT_PATH, ADMIN_START_ROUTE_PATH } from '../utils/GlobalConstants';
import Select from "react-select";
import { keys } from 'lodash';
import { toast } from 'react-toastify';


function Product({ product }) {

    const dispatch      =   useDispatch();
    const location      =   useLocation();
    const { id }        =   useParams();
    const globalState   =   useSelector(state => state.global);

    const [variantSelected, setVariantSelected] =   useState("");
    const [variantOption, setVariantOption]     =   useState([]);

    const [actualPrice, setActualPrice] =   useState(0);

    const [price, setPrice]         =   useState(0);
    const [discount, setDiscount]   =   useState(0);
    const [image, setImage]         =   useState("");
    const [attribute, setAttribute] =   useState("");
    const [productCartItem, setProductCartItem] =   useState(0);
    const [showCartbtn, setShowCartbtn]         =   useState(false);

    //console.log("Product Component Product Component", product);

    useEffect(() => {
        getVariantOptions(product);
        getProductPrice(product);
        getImage(product);
        getAttribute(product);
    }, [product]);

    const getVariantOptions     =   async() => {
        var tempArr =   await product.variants.map((va, i) => {
            return {
                ...va,
                value: va._id,
                label: va.attribute_value+' - '+product.attributes[0]["label"]
            }
        });
        setVariantOption(tempArr);
    }

    const getProductPrice  =   (prod, isVarinat=false) => {

        var discountArr =   [];

        if(!isVarinat) {
            discountArr =   prod["product_discount"];
        } else {
            discountArr =   prod["discount"];
        }

        if(discountArr.length > 0) {
            setActualPrice(prod["price"]);
            let discount_price  =   Math.abs((prod["price"]*discountArr[0]["percentage"])/100);
            let temp_price      =   Math.abs(prod["price"] - discount_price);
            temp_price          =   parseFloat(temp_price).toFixed(2);
            setPrice(temp_price);
            setDiscount(discountArr[0]["percentage"]);
        } else {
            setActualPrice(prod["price"]);
            setPrice(prod["price"]);
            setDiscount(0);
        }
    }

    const getImage  =   (prod) => {
        setImage((prod["path"]+prod["_id"]+'/'+prod["image"]));
    }

    const getAttribute  =   (prod) => {
        //console.log("prod", prod)
        if(prod["product_attributes"].length > 0) {
            setAttribute(prod["product_attribute_value"]+' - '+prod["product_attributes"][0]["label"]);
        } else {
            setAttribute("");
        }
    }

    const changeVariantProduct  =   (variant) => {
        setVariantSelected(variant.value);
        getProductPrice({ ...product, price: variant.price }, true);
        getImage({ ...product, image: variant.image });
        getAttribute({ ...product, product_attributes: product["attributes"], product_attribute_value: variant.attribute_value  });
    }

    const incrementCardItem = (e) => {
        dispatch(setCardItem("plus"));
        setProductCartItem(productCartItem + 1);
    };

    const decrementCardItem = (e) => {
        dispatch(setCardItem("minus"));
        if((productCartItem - 1) <= 0) {
            setProductCartItem(0);
            setShowCartbtn(false);
        } else {
            setProductCartItem(productCartItem - 1);
        }
    };
    

    return (
        <Suspense fallback={<Loader />}>
            <div className="card w-100 my-2 shadow-2-strong">
                <img src={image} className="card-img-top" style={{aspectRatio: "1 / 1"}} />
                <div className="card-body d-flex flex-column">
                    <h5 className="card-title">
                        <span className="mr-2">Name: </span>
                        {
                            product["name"]
                        }
                    </h5>
                    <h5>
                        <span className="mr-2">Variant: </span>
                        {
                            attribute
                        }
                    </h5>
                    <h5>
                        <span className="mr-2">Description:</span>
                        {
                            product["description"]
                        }
                    </h5>
                    <h5>
                        <span className="mr-2">Price:</span>
                        {
                            parseFloat(discount) > 0
                            &&
                            <strike>
                                Rs.
                                {
                                    actualPrice
                                }
                            </strike>
                        }
                        <span className="ml-2">
                            {
                                "Rs. "+price
                            }
                        </span>
                    </h5>
                    {
                        parseFloat(discount) > 0
                        &&
                        <h5 className="text-success">
                            <span className="mr-2">Discount:</span>
                            {
                                discount+"%"
                            }
                        </h5>
                    }
                    {
                        (
                            !showCartbtn
                            &&
                            Array.isArray(variantOption)
                            &&
                            variantOption.length > 0
                        )
                        &&
                        <Select
                            onChange={(val) =>  changeVariantProduct(val) }
                            value={variantOption.find(c => c.value === variantSelected)}
                            options={variantOption}
                        />
                    }
                    <div className="card-footer d-flex align-items-end pt-3 px-0 pb-0 mt-auto">
                        {
                            !showCartbtn
                            &&
                            <div className="justify-content-center mx-auto">
                                <button type="button" onClick={(e) => setShowCartbtn(true)} className="btn btn-primary"><i className="fa fa-shopping-cart"></i> Add</button>
                            </div>
                        }
                        {
                            showCartbtn
                            &&
                            <div className="input-group w-auto justify-content-end align-items-center">
                                <input type="button" value="-" className="button-minus border rounded-circle icon-shape icon-sm mx-1 lh-0 bg-danger " style={{ color: "#FFF" }} data-field="quantity" onClick={decrementCardItem} disabled={productCartItem == 0} />
                                <input type="number" step="1" max="10" name="quantity" className="quantity-field border-0 text-center  w-25" onChange={(e) => console.log(productCartItem)} value={productCartItem} />
                                <input type="button" value="+" className="button-plus border rounded-circle icon-shape icon-sm lh-0 bg-success" style={{ color: "#FFF" }} data-field="quantity" onClick={incrementCardItem} />
                            </div>
                        }
                    </div>
                </div>
            </div>
            
        </Suspense>
    );
}

export default memo(Product);