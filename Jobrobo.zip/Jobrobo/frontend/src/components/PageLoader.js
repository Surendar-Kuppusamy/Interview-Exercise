import React from 'react';

function PageLoader() {
    return (
        <div className="spinner-border"></div>
    );
}

export default PageLoader;