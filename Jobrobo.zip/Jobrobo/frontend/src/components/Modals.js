import React, { useState } from 'react';
import { Transition } from "react-transition-group";
import { Scrollbars } from 'react-custom-scrollbars-2';
import styled from "styled-components";
import Modal from "react-overlays/Modal";


const Backdrop = styled("div")`
	position: fixed;
	z-index: 1040;
	top: 0;
	bottom: 0;
	left: 0;
	right: 0;
	background-color: #000;
	opacity: 0.5;
`;

// we use some pseudo random coords so nested modals
// don't sit right on top of each other.
const RandomlyPositionedModal = styled(Modal)`
	position: fixed;
	max-width: 570px;
	width: 100%;
	z-index: 1040;
	left: 50%;
	top: 50%;
	transform: translate(-50%, -50%);
	padding: 20px;
	outline:none !important;
`;

/* border: 1px solid #e5e5e5;
background-color: white;
box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5); */

function Modals(props) {

	const renderBackdrop = (props) => <Backdrop {...props} />;

	const scrollbarRight	=	 (props?.scrollbarRight) ? props?.scrollbarRight : '-17px';

	if(props?.autoScroll) {
		return (
			<div className="modal-example">
				<RandomlyPositionedModal
					show={props?.show}
					onHide={() => props?.callback(false)}
					renderBackdrop={renderBackdrop}
					aria-labelledby="modal-label"
					onBackdropClick={(e) => props?.backDropFunc(e)}
				>
					<Scrollbars
						autoHeight
						autoHeightMax={props?.scrollHeight}
						style={{ maxWidth: props?.maxWidth }}
						/* renderTrackHorizontal={props => <div {...props} className="track-horizontal"/>}
						renderTrackVertical={props => <div {...props} className="track-vertical"/>}
						renderThumbHorizontal={props => <div {...props} className="thumb-horizontal"/>}
						renderThumbVertical={props => <div {...props} className="thumb-vertical"/>} */
						renderView={({ style, ...props }) => <div {...props} style={{ ...style, marginRight: scrollbarRight }} />
        }
					>
						{props.children}
					</Scrollbars>
				</RandomlyPositionedModal>
			</div>
		);
	} else {
		return (
			<div className="modal-example">
				<RandomlyPositionedModal
					show={props?.show}
					onHide={() => props?.callback(false)}
					renderBackdrop={renderBackdrop}
					aria-labelledby="modal-label"
					onBackdropClick={(e) => props?.backDropFunc(e)}
				>
					{props.children}
				</RandomlyPositionedModal>
			</div>
		);
	}	
}

export default Modals;