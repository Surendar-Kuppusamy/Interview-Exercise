import React,  { useEffect }  from 'react';
import { useTable, usePagination, useSortBy, useGlobalFilter  } from 'react-table';
import ReactPaginate from 'react-paginate';

import { Scrollbars } from 'react-custom-scrollbars-2';

function PaginatedListTemplate({columns, data, hiddenColumns=[], parentTableClass, tableClass, rowClass, rowClickEvent, noDataMsg, noDataColSpan, activeRowID, callBackFunc, customFunction, customValues, detailValue, searchText,  tableHeight, perPage, ...rest }) {

    const {
            setHiddenColumns,
            visibleColumns,
            preGlobalFilteredRows,
            fetchData,
            getTableProps,
            getTableBodyProps,
            headerGroups,
            prepareRow,
            setGlobalFilter,
            rows,
            page,
            canPreviousPage,
            canNextPage,
            pageOptions,
            pageCount,
            gotoPage,
            nextPage,
            previousPage,
            setPageSize,
            autoResetPage,
            paginateExpandedRows,
            state: { pageIndex, pageSize, globalFilter },
        }   =   useTable(
                    {
                        columns,
                        data,
                        initialState: { pageIndex: 0, hiddenColumns: hiddenColumns },
                        /* pageCount: rest?.pageCount, */
                        autoResetPage: false,
                        /* page: rest.pageCount+1, */
                        customFunction,
                        customValues,
                        detailValue
                    },
                    useGlobalFilter, // useGlobalFilter!
                    useSortBy,
                    usePagination,
                    
                );

        useEffect(() => {
            if(callBackFunc !== undefined) {
                callBackFunc();
            }
            if(rest?.customCallback !== undefined) {
                rest?.customCallback(globalFilter, pageIndex, pageSize);
            }

            if(rest?.pageSize !== undefined) {
                setPageSize(rest?.pageSize);
            }

            console.log('pageCount ==>', pageIndex, pageSize, pageCount);
        }, [globalFilter, pageIndex, pageSize]);

        useEffect(() => {
            console.log('pageCount', rest?.pageCount);
            setTimeout(() => {
                const customPageIndex   =   ((parseInt(rest?.pageCount) - 1) < 0) ? 0 : (parseInt(rest?.pageCount) - 1);
                gotoPage(customPageIndex);
            }, 200);
        }, [rest?.pageCount]);

        const getNextPage = (nextToken) => {
            if(rest?.fetchData !== undefined) {
                rest?.fetchData(rest?.nextToken);
            }
        }
        
        useEffect(() => {
            setGlobalFilter(searchText)
        }, [searchText]);
    

    return (
        <>
        
            {
                rows.length !== 0
                &&
                <div className={'table-list table-responsive '+((parentTableClass !== undefined) ? parentTableClass : '') + ''}>
                    {/* <Scrollbars  autoHeight autoHeightMin={`calc(100vh - 120px)`}> */}
                    <Scrollbars  autoHeight autoHeightMax={tableHeight} >
                        <table {...getTableProps()} className={" "+(tableClass !== undefined ? tableClass: '')+" "}>
                            <thead>
                                {
                                    headerGroups.map(headerGroup => (
                                        <tr {...headerGroup.getHeaderGroupProps()}>
                                            {
                                                headerGroup.headers.map(column => 
                                                    {
                                                        //console.log(column, 'column');
                                                        return (
                                                            <th
                                                                className={(column?.thClassNames !== undefined ? column?.thClassNames : '' )}
                                                                {...column.getHeaderProps(column.getSortByToggleProps())}
                                                            >
                                                                {
                                                                    column.render('Header')
                                                                }
                                                                <span>
                                                                    {
                                                                        column.isSorted
                                                                            ? column.isSortedDesc
                                                                                ? ' 🔽'
                                                                                : ' 🔼'
                                                                            : ''
                                                                    }
                                                                </span>
                                                            </th>
                                                        )
                                                    }
                                                )
                                            }
                                        </tr>
                                    ))
                                }
                            </thead>
                            <tbody {...getTableBodyProps()}>
                                {
                                    page.map((row, i) => {
                                        prepareRow(row);
                                        //console.log('Check value', row);
                                        return (
                                            <tr 
                                                className = {" "+ ((activeRowID !== undefined && row?.original?.id !== undefined && row?.original?.id === activeRowID) ? ' active ' : ' ' ) + (rowClass !== undefined ? rowClass: '') + (i%2 === 0 ? " even-row ": " odd-row  ") + " pointer " }
                                                {...row.getRowProps()}
                                                onClick={(e) => { if(rowClickEvent !== undefined) rowClickEvent(e, row?.original);}}
                                                id={(row?.original?.id !== undefined) ? row?.original?.id : Math.random()}
                                            >
                                                {
                                                    row.cells.map((cell, j) => {
                                                        //console.log('cell', cell);
                                                        return (
                                                            <td
                                                                className = {" "+ ((cell?.column?.tdClassNames !== undefined) ? cell?.column?.tdClassNames : '' ) +" "}
                                                                {...cell.getCellProps()}
                                                            >
                                                                {
                                                                    cell.render('Cell')
                                                                }
                                                            </td>
                                                        );
                                                    })
                                                }
                                            </tr>
                                        );
                                    })
                                }

                                {
                                    rows.length === 0 && (
                                        <tr className={(rowClass !== undefined ? rowClass : '')}>
                                            <td className="text-center" colSpan={(noDataColSpan !== undefined ? noDataColSpan: '')}>
                                                <div className="no-data">
                                                    {
                                                        (noDataMsg !== undefined ? noDataMsg: '')
                                                    }
                                                </div>
                                            </td>
                                        </tr>
                                    )
                                }
                            </tbody>
                        </table>
                    </Scrollbars>
                </div>
            }

            {
                rows.length === 0
                &&
                <div className="container-fluid no-data-sec px-4">
                    <div className="no-data">
                        <div className="content">
                            <div className="icon">
                                <img src={`${process.env.PUBLIC_URL}/images/no-data.svg`} />
                            </div>
                            {
                                noDataMsg !== undefined
                                &&
                                noDataMsg !== ''
                                &&
                                noDataMsg
                            }
                        </div>
                    </div>
                </div>
            }

            <div className="react-table-pagination row"> 
                <div className="col-md-9">
                    <div className="pagination justify-content-start my-4">
                        {/* {
                            pageIndex > 0
                            &&
                            pageCount > 1
                            &&
                            <>
                                <li className=' page-item '>
                                    <button className={'page-link'} onClick={() => gotoPage(pageIndex - 1) } >
                                        {'Previous Page'}
                                    </button>
                                </li>
                            </>
                        } */}
                        {
                            pageCount > 0
                            &&
                            !(
                                pageCount === 1
                                &&
                                rest?.nextToken === null
                            )
                            &&
                            <ReactPaginate
                                renderOnZeroPageCount={null}
                                previousLabel={'previous'}
                                nextLabel={'next'}
                                breakLabel={'...'}
                                breakClassName={'break-me'}
                                pageCount={pageCount}
                                marginPagesDisplayed={2}
                                pageRangeDisplayed={pageSize}
                                onPageChange={(data) => gotoPage(parseInt(data.selected))}
                                forcePage={pageIndex}
                                initialPage={pageIndex}
                                containerClassName={'pagination justify-content-start mb-0'}
                                activeClassName={'active'}
                                pageClassName={'page-item'}
                                pageLinkClassName={'page-link'}
                                previousClassName={' d-none page-item'}
                                nextClassName={'page-item'}
                                previousLinkClassName={' d-none page-link'}
                                nextLinkClassName={' d-none page-link'}
                            />
                        }
                        {
                            pageCount > 0
                            &&
                            <>                                
                            <li className=' page-item '>
                                <button className= { rest?.nextToken === null ? 'd-none' : 'page-link'}  >
                                    {'...'}
                                </button>
                            </li>
                            <li className=' page-item '>
                                <button className={ rest?.nextToken === null ? 'd-none' : 'page-link'} onClick={() => getNextPage(rest?.nextToken) } >
                                    {'Load More'}
                                </button>
                            </li>
                            </>
                        }
                    </div>
                </div>
            </div>
        </>
    );
}


export default PaginatedListTemplate;