import validator from 'express-validator';
import Users from '../models/UserModel.js';
import mongoose from 'mongoose';
import ProductCategories from '../models/ProductCategoryModel.js';
import Discounts from '../models/DiscountModel.js';
import Attributes from '../models/AttributeModel.js';
import Products from '../models/ProductModel.js';

const { validationResult, checkSchema } = validator;

export const customValidationResult = validationResult.withDefaults({
    formatter: error => {
        return {
            status: 'error',
            message: error.msg,
            params:error.param
        };
    },
});

export const userValidationSchema = {
    name: {
        trim: true,
        notEmpty: {
            errorMessage: "Name is required."
        },
        /* isAlphanumeric: {
            errorMessage: "Name should be alpha numeric."
        }, */
        isLength: {
            options: {
                min: 3,
                max: 600
            },
            errorMessage: "Name characters must be greater then 2 and less then 50"
        }
    },
    type: {
        custom: {
            options: (value, { req, location, path }) => {
                if(value != 1 && value != 2) {
                    return Promise.reject('Invalid type value.');
                } else {
                    return Promise.resolve(true);
                }
            }
        }
    },
    gender: {
        trim: true,
        notEmpty: {
            errorMessage: "Gender is required."
        },
        custom: {
            options: (value, { req, location, path }) => {
                if(value.toLowerCase() != "male" && value.toLowerCase() != "female" && value.toLowerCase() != "transgender") {
                    return Promise.reject('Invalid gender value.');
                }
                return Promise.resolve(true);
            }
        }
    },
    email: {
        trim: true,
        notEmpty: {
            errorMessage: "Email is required."
        },
        isEmail: {
            errorMessage: "Invalid email address."
        },
        custom: {
            options: (value, { req, location, path }) => {

                return Users.find({
                    email: value,
                    type: req.body.type
                }).then(user => {
                    if (user.length > 0) {
                        return Promise.reject('Email address already taken')
                    } else {
                        return Promise.resolve(true);
                    }
                });

            }
        }
    },
    password: {
        trim: true,
        notEmpty: {
            errorMessage: "Password is required."
        },
        isLength: {
            options: {
                min: 6,
                max: 50
            },
            errorMessage: "Password characters must be greater then 6 and less then 50"
        }
    },
    dob: {
        trim: true,
        /* isDate: {
            options: {
                format: 'YYYY-MM-DD',
                delimiters: ['/', '-']
            },
            errorMessage: "DOB date is invalid."
        },
        isBefore: {
            date: new Date(),
            errorMessage: "DOB date should not be current or future dates."
        } */
    },
    mobile_number: {
        trim: true,
        //toInt: true,
        /* customSanitizer: {
            options: (value, { req, location, path }) => {
                let sanitizedValue;
                sanitizedValue = parseInt(value);
                return sanitizedValue;
            }
        }, */
        /* isNumeric: {
            errorMessage: "Mobile number should be numeric."
        }, */
        /* isLength: {
            options: {
                min: 10
            },
            errorMessage: "Mobile number should be 10 digits."
        },
        isLength: {
            options: {
                max: 10
            },
            errorMessage: "Mobile number should be 10 digits."
        } */
    },
    address: {
        trim: true,
        notEmpty: {
            errorMessage: "Address is required."
        },
        isLength: {
            options: { min: 0, max: 50000 },
            errorMessage: 'Address should be at least 30 characters.'
        }
    }
}

export const userupdateValidationSchema = {
    ...userValidationSchema,
    id: {
        notEmpty: {
            errorMessage: "ID required."
        },
        custom: {
            options: (value, { req, location, path }) => {

                return Users.findById(value).then(user => {
                    if(user._id != undefined && user._id != null && user._id != '') {
                        return Promise.resolve(true);
                    } else {
                        return Promise.reject('Invalid user ID.');
                    }
                });
                
            }
        }
    },
    email: {
        trim: true,
        notEmpty: {
            errorMessage: "Email is required."
        },
        isEmail: {
            errorMessage: "Invalid email address."
        },
        custom: {
            options: (value, { req, location, path }) => {

                return Users.find({
                    email: value,
                    type: req.body.type,
                    _id: { $ne: req.body.id }
                }).then(user => {
                    if (user.length > 0) {
                        return Promise.reject('Email address already taken')
                    } else {
                        return Promise.resolve(true);
                    }
                });

            }
        }
    }
}


export const loginValidationSchema = {
    type: {
        custom: {
            options: (value, { req, location, path }) => {
                if(value != 1 && value != 2) {
                    return Promise.reject('Invalid type value.');
                } else {
                    return Promise.resolve(true);
                }
            }
        }
    },
    email: {
        trim: true,
        notEmpty: {
            errorMessage: "Email is required."
        },
        isEmail: {
            errorMessage: "Invalid email address."
        },
        custom: {
            options: async(value, { req, location, path }) => {

                const user = await Users.find({
                    email: value,
                    password: req.body.password,
                    type: req.body.type
                });
                if(user.length > 0) {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Invalid credential.');
                }
            }
        }
    },
    password: {
        trim: true,
        notEmpty: {
            errorMessage: "Password is required."
        },
        isLength: {
            options: {
                min: 6,
                max: 50
            },
            errorMessage: "Password characters must be greater then 6 and less then 50"
        }
    }
}

export const getProductCategorySchema = {
    id: {
        notEmpty: {
            errorMessage: "ID required."
        },
        custom: {
            options: (value, { req, location, path }) => {
                return ProductCategories.findById(value).then(pc => {
                    if(pc._id != undefined && pc._id != null && pc._id != '') {
                        return Promise.resolve(true);
                    } else {
                        return Promise.reject('Invalid user ID.');
                    }
                });
            }
                
        }
    },
}

export const productCategorySchema = {
    id: {
        /* notEmpty: {
            errorMessage: "ID required."
        }, */
        custom: {
            options: (value, { req, location, path }) => {
                if(req.body.id !== undefined && req.body.id !== null && req.body.id !== '') {
                    var id = mongoose.Types.ObjectId(value);
                    return ProductCategories.findById(id).then(pc => {
                        if(pc._id != undefined && pc._id != null && pc._id != '') {
                            return Promise.resolve(true);
                        } else {
                            return Promise.reject('Invalid user ID.');
                        }
                    });
                } else {
                    return Promise.resolve(true);
                }
                
            }
        }
    },
    name: {
        trim: true,
        notEmpty: {
            errorMessage: "Name is required."
        },
        /* isAlphanumeric: {
            errorMessage: "Name should be alpha numeric."
        }, */
        isLength: {
            options: {
                min: 1,
                max: 600
            },
            errorMessage: "Name characters must be greater then 1 and less then 600"
        },
        custom: {
            options: (value, { req, location, path }) => {

                //var filter = { name: value };
                var filter =    { name:{ $regex: new RegExp("^" + value.toLowerCase(), "i") } };

                if(req.body.id !== undefined && req.body.id !== null && req.body.id !== '') {
                    filter["_id"]   =   { $ne: req.body.id }
                }

                return ProductCategories.find(filter).then(pc => {
                    if(pc.length > 0) {
                        return Promise.reject('Product category name already exists.');
                    } else {
                        return Promise.resolve(true);
                    }
                });
                
            }
        }
    },
    status: {
        custom: {
            options: async(value, { req, location, path }) => {
                if(parseInt(value) != 1 && parseInt(value) != 2) {
                    return Promise.reject('Invalid status.');
                } else {
                    return Promise.resolve(true);
                }
            }
        }       
    }
}


export const discountSchema = {
    id: {
        /* notEmpty: {
            errorMessage: "ID required."
        }, */
        custom: {
            options: (value, { req, location, path }) => {
                if(req.body.id !== undefined && req.body.id !== null && req.body.id !== '') {
                    var id = mongoose.Types.ObjectId(value);
                    return Discounts.findById(id).then(pc => {
                        if(pc._id != undefined && pc._id != null && pc._id != '') {
                            return Promise.resolve(true);
                        } else {
                            return Promise.reject('Invalid user ID.');
                        }
                    });
                } else {
                    return Promise.resolve(true);
                }
                
            }
        }
    },
    name: {
        trim: true,
        notEmpty: {
            errorMessage: "Name is required."
        },
        /* isAlphanumeric: {
            errorMessage: "Name should be alpha numeric."
        }, */
        isLength: {
            options: {
                min: 1,
                max: 600
            },
            errorMessage: "Name characters must be greater then 1 and less then 600"
        },
        custom: {
            options: (value, { req, location, path }) => {

                //var filter = { name: value };
                var filter =    { name:{ $regex: new RegExp("^" + value.toLowerCase(), "i") } };

                if(req.body.id !== undefined && req.body.id !== null && req.body.id !== '') {
                    filter["_id"]   =   { $ne: req.body.id }
                }

                return Discounts.find(filter).then(ds => {
                    if(ds.length > 0) {
                        return Promise.reject('Discount name already exists.');
                    } else {
                        return Promise.resolve(true);
                    }
                });
                
            }
        }
    },
    status: {
        custom: {
            options: async(value, { req, location, path }) => {
                if(parseInt(value) != 1 && parseInt(value) != 2) {
                    return Promise.reject('Invalid status.');
                } else {
                    return Promise.resolve(true);
                }
            }
        }       
    }
}

export const attributeSchema = {
    id: {
        /* notEmpty: {
            errorMessage: "ID required."
        }, */
        custom: {
            options: (value, { req, location, path }) => {
                if(req.body.id !== undefined && req.body.id !== null && req.body.id !== '') {
                    var id = mongoose.Types.ObjectId(value);
                    return Attributes.findById(id).then(pc => {
                        if(pc._id != undefined && pc._id != null && pc._id != '') {
                            return Promise.resolve(true);
                        } else {
                            return Promise.reject('Invalid user ID.');
                        }
                    });
                } else {
                    return Promise.resolve(true);
                }
                
            }
        }
    },
    name: {
        trim: true,
        notEmpty: {
            errorMessage: "Name is required."
        },
        /* isAlphanumeric: {
            errorMessage: "Name should be alpha numeric."
        }, */
        isLength: {
            options: {
                min: 1,
                max: 600
            },
            errorMessage: "Name characters must be greater then 1 and less then 600"
        },
        custom: {
            options: (value, { req, location, path }) => {

                //var filter = { name: value };
                var filter =    { name:{ $regex: new RegExp("^" + value.toLowerCase(), "i") } };

                if(req.body.id !== undefined && req.body.id !== null && req.body.id !== '') {
                    filter["_id"]   =   { $ne: req.body.id }
                }

                return Attributes.find(filter).then(ds => {
                    if(ds.length > 0) {
                        return Promise.reject('Attribute name already exists.');
                    } else {
                        return Promise.resolve(true);
                    }
                });
                
            }
        }
    },
    label: {
        trim: true,
        notEmpty: {
            errorMessage: "Label is required."
        },
        /* isAlphanumeric: {
            errorMessage: "Name should be alpha numeric."
        }, */
        isLength: {
            options: {
                min: 1,
                max: 600
            },
            errorMessage: "Label characters must be greater then 1 and less then 600"
        }
    },
    status: {
        custom: {
            options: async(value, { req, location, path }) => {
                if(parseInt(value) != 1 && parseInt(value) != 2) {
                    return Promise.reject('Invalid status.');
                } else {
                    return Promise.resolve(true);
                }
            }
        }       
    }
}


export const productSchema = {
    id: {
        /* notEmpty: {
            errorMessage: "ID required."
        }, */
        custom: {
            options: (value, { req, location, path }) => {
                if(req.body.id !== undefined && req.body.id !== null && req.body.id !== '') {
                    var id = mongoose.Types.ObjectId(value);
                    return Products.findById(id).then(pc => {
                        if(pc._id != undefined && pc._id != null && pc._id != '') {
                            return Promise.resolve(true);
                        } else {
                            return Promise.reject('Invalid user ID.');
                        }
                    });
                } else {
                    return Promise.resolve(true);
                }
                
            }
        }
    },
    name: {
        trim: true,
        notEmpty: {
            errorMessage: "Name is required."
        },
        /* isAlphanumeric: {
            errorMessage: "Name should be alpha numeric."
        }, */
        isLength: {
            options: {
                min: 1,
                max: 600
            },
            errorMessage: "Name characters must be greater then 1 and less then 600"
        },
        custom: {
            options: (value, { req, location, path }) => {

                //var filter = { name: value };
                var filter =    { name:{ $regex: new RegExp("^" + value.toLowerCase(), "i") } };

                if(req.body.id !== undefined && req.body.id !== null && req.body.id !== '') {
                    filter["_id"]   =   { $ne: req.body.id }
                }

                return Products.find(filter).then(pc => {
                    if(pc.length > 0) {
                        return Promise.reject('Product name already exists.');
                    } else {
                        return Promise.resolve(true);
                    }
                });
                
            }
        }
    },
    product_category: {
        trim: true,
        notEmpty: {
            errorMessage: "Product Category is required."
        },
        custom: {
            options: (value, { req, location, path }) => {

                //var filter = { name: value };
                var filter =    { _id: value, status: 1 };

                return ProductCategories.find(filter).then(pc => {
                    if(pc.length > 0) {
                        return Promise.resolve(true);
                    } else {
                        return Promise.reject('Product category does not exists.');
                    }
                });
                
            }
        }
    },
    discount_id: {
        trim: true,
        custom: {
            options: (value, { req, location, path }) => {

                if(value !== undefined && value !== null && value !== '') {

                    //var filter = { name: value };
                    var filter =    { _id: value, status: 1 };

                    return Discounts.find(filter).then(pc => {
                        if(pc.length > 0) {
                            return Promise.resolve(true);
                        } else {
                            return Promise.reject('Discount does not exists.');
                        }
                    });

                } else {
                    return Promise.resolve(true);
                }
                
            }
        }
    },
    status: {
        custom: {
            options: async(value, { req, location, path }) => {
                if(parseInt(value) != 1 && parseInt(value) != 2) {
                    return Promise.reject('Invalid status.');
                } else {
                    return Promise.resolve(true);
                }
            }
        }
    }
}


export const productVariantSchema = {
    id: {
        /* notEmpty: {
            errorMessage: "ID required."
        }, */
        custom: {
            options: (value, { req, location, path }) => {
                if(req.body.id !== undefined && req.body.id !== null && req.body.id !== '') {
                    var id = mongoose.Types.ObjectId(value);
                    return Products.findById(id).then(pc => {
                        if(pc._id != undefined && pc._id != null && pc._id != '') {
                            return Promise.resolve(true);
                        } else {
                            return Promise.reject('Invalid user ID.');
                        }
                    });
                } else {
                    return Promise.resolve(true);
                }
                
            }
        }
    },
    product_id: {
        trim: true,
        notEmpty: {
            errorMessage: "Product is required."
        },
        custom: {
            options: (value, { req, location, path }) => {

                //var filter = { name: value };
                var filter =    { _id: value, status: 1 };

                return Products.find(filter).then(pc => {
                    if(pc.length > 0) {
                        return Promise.resolve(true);
                    } else {
                        return Promise.reject('Product does not exists.');
                    }
                });
                
            }
        }
    },
    attribute_id: {
        trim: true,
        notEmpty: {
            errorMessage: "Attribute is required."
        },
        custom: {
            options: (value, { req, location, path }) => {

                //var filter = { name: value };
                var filter =    { _id: value, status: 1 };

                return Attributes.find(filter).then(pc => {
                    if(pc.length > 0) {
                        return Promise.resolve(true);
                    } else {
                        return Promise.reject('Attribute does not exists.');
                    }
                });
                
            }
        }
    },
    discount_id: {
        trim: true,
        custom: {
            options: (value, { req, location, path }) => {

                if(value !== undefined && value !== null && value !== '') {

                    //var filter = { name: value };
                    var filter =    { _id: value, status: 1 };

                    return Discounts.find(filter).then(pc => {
                        if(pc.length > 0) {
                            return Promise.resolve(true);
                        } else {
                            return Promise.reject('Discount does not exists.');
                        }
                    });

                } else {
                    return Promise.resolve(true);
                }
                
            }
        }
    },

    status: {
        custom: {
            options: async(value, { req, location, path }) => {
                if(parseInt(value) != 1 && parseInt(value) != 2) {
                    return Promise.reject('Invalid status.');
                } else {
                    return Promise.resolve(true);
                }
            }
        }
    }
}