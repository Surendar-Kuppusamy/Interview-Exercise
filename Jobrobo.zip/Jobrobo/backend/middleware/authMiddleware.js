import jwt from 'jsonwebtoken';
import asyncHandler from 'express-async-handler'
import Users from '../models/UserModel.js';
import { customValidationResult } from '../middleware/validationSchemas.js';

export const checkValidation = asyncHandler(async(req, res, next) => {
    const validationResultError = customValidationResult(req).array();
	if(validationResultError.length > 0) {
        console.log('Validation-Error===>'+JSON.stringify(validationResultError));
		res.status(200).json(validationResultError[0]);
    } else {
        next();
    }
});

export const verifyToken = asyncHandler(async(req, res, next) => {
    let token;
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
        try {
            token = req.headers.authorization.split(' ')[1];
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            req.user = await Users.findById(decoded.user_id).select('-password');
            next();
        } catch (error) {
            res.status(401)
            throw new Error('Token expired.');
        }
    }
    
    if (!token) {
        res.status(401);
        throw new Error('Not authorized, no token');
    }
});

export const generateToken = (user_id) => {
    return jwt.sign({ user_id:  user_id}, process.env.JWT_SECRET, { expiresIn: '8h' });
};

export const getUserId = async(req) => {
    let token;
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
        try {
            token = req.headers.authorization.split(' ')[1];
            const decoded = await jwt.verify(token, process.env.JWT_SECRET);
            return decoded.user_id;
        } catch (error) {
            return false;
        }
    }
    if (!token) {
        return false;
    }
}