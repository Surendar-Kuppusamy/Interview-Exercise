import expressAsyncHandler from 'express-async-handler';
import fs from 'fs';
import path from 'path';
import multer from 'multer';

export const createDirectoryLocal = expressAsyncHandler(async(createDirectory, next) => {
    return new Promise(async(resolve, reject) => {
        try {
            let isDirectoryExists = await fs.existsSync(createDirectory);
            if(!isDirectoryExists) {
                await fs.mkdirSync(createDirectory, { recursive: true });   //Create path, if directory not exists
            }
            resolve(true);
        } catch(e) {
            reject(false);
            console.log('Catch error in common function', e);
            throw new Error(e.message);
        }
    });
});

export const deleteFileLocal = expressAsyncHandler(async(file, next) => {
    return new Promise(async(resolve, reject) => {
        try {
            fs.unlinkSync(file);
            console.log("Delete File Path", file);
            resolve(true);
        } catch(e) {
            reject(false);
            console.log('Catch error in common function', e);
            throw new Error(e.message);
        }
    });
});

export const copyFileLocal = expressAsyncHandler(async(sourceFile, destination, next) => {
    return new Promise(async(resolve, reject) => {
        try {
            await fs.copyFile(sourceFile, destination, (err) => {
                if(err) {
                    resolve(false);
                } else {
                    resolve(true);
                }
            });
        } catch(e) {
            reject(false);
            console.log('Catch error in common function', e);
            throw new Error(e.message);
            //let error = new Error(e.message);
            //next(error);
        }
    });
});

export const generalFileUpload = expressAsyncHandler(async(file, filePath, fileName, next) => {
    return new Promise(async function(resolve, reject) {
        try {
            const createPath    =   await createDirectoryLocal(filePath);
            fs.writeFileSync(filePath+fileName, file.buffer);
            resolve(true);
            console.log("Success");
        } catch(e) {
            console.log('Catch error in common function generalFileUpload()', e);
            resolve(false);
        }
    });
});

export const getFileName = expressAsyncHandler(async(next) => {
    return new Promise(async(resolve, reject) => {
        let mediaName = Date.now();
        let randomNumber = Math.floor(Math.random() * 899999 + 100000);
        randomNumber = randomNumber.toString().substring(0, 2);
        randomNumber =  parseInt(randomNumber);
        mediaName = randomNumber+'_'+mediaName;
        resolve(mediaName);
    });
});


export const jsonResponse = expressAsyncHandler(async(res, statusCode, status, message, data) => {
    try {
        if(data) {
            res.status(statusCode).json({
                status: status,
                message: message,
                data: data
            });
        } else {
            res.status(statusCode).json({
                status: status,
                message: message
            });
        }
    } catch(e) {
        console.log('Catch error in common function jsonResponse()', e);
        throw new Error(e.message);
    }
});

export const checkFileError = (err) => {
    return new Promise((resolve, reject) => {
        if(err instanceof multer.MulterError) {
            if(err.code == "LIMIT_UNEXPECTED_FILE") {
                return resolve({ status: true, message: 'Invalid field name.' });
            } else if(err.code == "LIMIT_FILE_COUNT") {
                return resolve({ status: true, message: 'Too many files uploaded.' });
            } else {
                return resolve({ status: true, message: err.message });
            }
        } else if (err) {
            return resolve({ status: true, message: err.message });
        } else {
            return resolve({ status: false, message: '' });
        }
    });
};