import express from "express";
import validator from 'express-validator';
import multer from 'multer';
import { userValidationSchema, productCategorySchema, getProductCategorySchema, discountSchema, attributeSchema, productSchema, productVariantSchema } from '../middleware/validationSchemas.js';
import { checkValidation, verifyToken } from '../middleware/authMiddleware.js';
import { getAllSource, getProductCategory, getProducts, manageAttribute, manageDiscount, manageProduct, manageProductCategory, manageProductVariants,  } from "../controllers/adminController.js";

const { checkSchema } = validator;

const router = express.Router()

//router.route('/get').post(verifyToken, checkSchema(userValidationSchema, ['body']), checkValidation, getProduct);

router.route('/get/product/category').post(verifyToken, checkSchema(getProductCategorySchema, ['body']), checkValidation, getProductCategory);

router.route('/manage/product/category').post(verifyToken, checkSchema(productCategorySchema, ['body']), checkValidation, manageProductCategory);
//router.route('/manage/product/variants').post(verifyToken, manageProductV);
router.route('/manage/discount').post(verifyToken, checkSchema(discountSchema, ['body']), checkValidation, manageDiscount);
router.route('/manage/attribute').post(verifyToken, checkSchema(attributeSchema, ['body']), checkValidation, manageAttribute);



const productUpload	=	multer({ dest: "public/products" });

const uploadProduct = multer({
	storage: multer.memoryStorage(),
	limits: {
        fileSize: 1024 * 1024 * 5
    },
	fileFilter: function (req, file, cb) {
		if (file.mimetype == "image/png" || file.mimetype == "image/jpg" || file.mimetype == "image/jpeg") {
            cb(null, true);
        } else {
            return cb(new Error('File not supported.'));
        }
	}
}).fields([
	{ name: 'image', maxCount: 1 }
]);


//router.route('/manage/product').post(verifyToken, checkSchema(productSchema, ['body']), checkValidation, manageProduct);
//router.route('/manage/product/variants').post(verifyToken, checkSchema(productVariantSchema, ['body']), checkValidation, manageProductVariants);

router.route('/manage/product').post(function(req, res, next) {
	uploadProduct(req, res, function (err) { return manageProduct(req, res, err, next); });
});

router.route('/manage/product/variants').post(function(req, res, next) {
	uploadProduct(req, res, function (err) { return manageProductVariants(req, res, err, next); });
});


router.route('/get/all-source').get(getAllSource);
router.route('/get/all-products').post(getProducts);


export default router;