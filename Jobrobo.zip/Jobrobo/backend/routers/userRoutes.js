import express from "express";
import validator from 'express-validator';
import multer from 'multer';
import { login, getUser, signup, getUserInfo, manageUser } from '../controllers/userController.js';
import { loginValidationSchema, userValidationSchema } from '../middleware/validationSchemas.js';
import { checkValidation, verifyToken } from '../middleware/authMiddleware.js';

const { checkSchema } = validator;

const router = express.Router();

const profileUpload	=	multer({ dest: "public/profiles" });

const uploadProfile = multer({
	storage: multer.memoryStorage(),
	limits: {
        fileSize: 1024 * 1024 * 5
    },
	fileFilter: function (req, file, cb) {
		if (file.mimetype == "image/png" || file.mimetype == "image/jpg" || file.mimetype == "image/jpeg") {
            cb(null, true);
        } else {
            return cb(new Error('File not supported.'));
        }
	}
}).fields([
	{ name: 'profile_image_file', maxCount: 1 }
]);

router.route('/signup').post(checkSchema(userValidationSchema, ['body', 'query']), checkValidation, signup);
router.route('/get').post(verifyToken, getUser);
router.route('/get-info').post(verifyToken, getUserInfo);
router.route('/login').post(checkSchema(loginValidationSchema, ['body', 'query']), checkValidation, login);
router.route('/manage').post(function(req, res, next) {
	uploadProfile(req, res, function (err) { return manageUser(req, res, err, next); });
});

export default router;