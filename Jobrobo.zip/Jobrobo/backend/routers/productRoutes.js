import express from "express";
import validator from 'express-validator';
import { getProduct } from '../controllers/productController.js';
import { loginValidationSchema, userValidationSchema } from '../middleware/validationSchemas.js';
import { checkValidation, verifyToken } from '../middleware/authMiddleware.js';

const { checkSchema } = validator;

const router = express.Router()

router.route('/get').post(verifyToken, getProduct);


export default router;