import asyncHandler from 'express-async-handler';
import validator from 'express-validator';
import mongoose from 'mongoose';
import path from 'path';
import { generateToken, getUserId } from '../middleware/authMiddleware.js';
import { checkFileError, generalFileUpload, getFileName, jsonResponse } from '../utils/CommonFunction.js';
import ProductCategories from '../models/ProductCategoryModel.js';
import Products from '../models/ProductModel.js';
import Attributes from '../models/AttributeModel.js';
import Discounts from '../models/DiscountModel.js';
import ProductVariants from '../models/ProductVariantsModel.js';
import { customValidationResult, productSchema, productVariantSchema } from '../middleware/validationSchemas.js';


export const getProduct = asyncHandler(async(req, res, next) => {
	const product = [];

	res.status(201).json({
		status: 'success',
		message: 'Product List successfully.',
		product: product
	});
});

export const getProductCategory = asyncHandler(async(req, res, next) => {
	const user_id =	await getUserId(req);
	const pc = await ProductCategories.find({
		_id: req.body.id
	}).exec();

	res.status(201).json({
		status: 'success',
		message: 'User get successfully.',
		data: pc
	});
});


export const manageProductCategory = asyncHandler(async(req, res, next) => {

	const product_category = req.body;
	var update_data 	=	{ ...product_category };
	delete update_data["id"];

	if(product_category["id"] !== undefined && product_category["id"] !== null && product_category["id"] !== '') {
		const pc = await ProductCategories.findOneAndUpdate({_id: product_category["id"]}, update_data);
		res.status(201).json({
			status: 'success',
			message: 'Product category updated.'
		});
	} else {
		const pc = await ProductCategories.create(update_data);
		res.status(201).json({
			status: 'success',
			message: 'Product category added.'
		});
	}
});

export const manageProduct = asyncHandler(async(req, res, err, next) => {

	const { checkSchema } 	=	validator;

	const resFiles	=	(req.files != undefined && req.files != null && Object.keys(req.files).length != 0
	) ? req.files : { "image": [] };

	const errorStatus   =   await checkFileError(err);

    if(errorStatus['status']) {
        return jsonResponse(res, 200, 'error', errorStatus['message']);
    }

	const product 		=	{ ...req.body };

	var update_data 	=	{ ...product };
	delete update_data["id"];

	/* if(update_data["discount_id"] === undefined || update_data["discount_id"] === null || update_data["discount_id"] === '') {
		delete update_data["discount_id"];
	} */

	console.log("product", product);

	const result = await checkSchema(productSchema, ["body"]).run({ "body": product});

	const validationResultError = customValidationResult({ "body": product}).array();
	if(validationResultError.length > 0) {
        console.log('Validation-Error===>'+JSON.stringify(validationResultError));
		return res.status(200).json(validationResultError[0]);
    }

	if(product["id"] !== undefined && product["id"] !== null && product["id"] !== '') {
		const user = await Products.findOneAndUpdate({_id: product["id"]}, update_data);
		return res.status(201).json({
			status: 'success',
			message: 'Product updated.'
		});
	} else {
		const pv = await Products.create(update_data);

		var product_image 		=	"";
		var statusOfFileUpload 	= 	true;
		
		//console.log("resFiles", resFiles);

		for await (const  file of resFiles['image']) {

			if(pv._id != undefined && pv._id != null && pv._id != '') {
			
				const filePath	=	'public/products/'+pv._id+'/';
				const getName 	=	await getFileName(next);
				const fileName	=	`${getName}${path.extname(file.originalname)}`;
				const fileUploadStatus =   await generalFileUpload(file, filePath, fileName, next);

				console.log("File Status", fileUploadStatus);
	
				if(!fileUploadStatus) {
					statusOfFileUpload = false;
					break;
				}
	
				product_image	=	fileName;
			}			

			if(product_image != "") {
				const user = await Products.findOneAndUpdate({_id: pv._id}, { image: product_image });
			}

			if(!statusOfFileUpload) {
				return res.status(201).json({
					status: 'error',
					message: 'File upload failed.',
					data: pv
				});
			}
			
		}

		res.status(201).json({
			status: 'success',
			message: 'Product added.'
		});
	}
});

export const manageProductVariants = asyncHandler(async(req, res, err, next) => {

	const resFiles	=	(req.files != undefined && req.files != null && Object.keys(req.files).length != 0
	) ? req.files : { "image": [] };

	const errorStatus   =   await checkFileError(err);

    if(errorStatus['status']) {
        return jsonResponse(res, 200, 'error', errorStatus['message']);
    }

	const product 		=	{ ...req.body };
	var update_data 	=	{ ...product };

	const { checkSchema } 	=	validator;
	let date 				= 	new Date();

	const result = await checkSchema(productVariantSchema, ["body"]).run({ "body": product});

	const validationResultError = customValidationResult({ "body": product}).array();
	if(validationResultError.length > 0) {
        console.log('Validation-Error===>'+JSON.stringify(validationResultError));
		return res.status(200).json(validationResultError[0]);
    }

	delete update_data["id"];

	var val_filter 	=	{
		product_id: update_data["product_id"],
		attribute_id: update_data["attribute_id"],
		attribute_value: update_data["attribute_value"]
	}

	if(product["id"] !== undefined && product["id"] !== null && product["id"] !== '') {
		val_filter["_id"]	=	{ $ne:  product["id"]};
	}

	/* if(product["discount_id"] === undefined || product["discount_id"] === null || product["discount_id"] === '') {
		delete update_data["discount_id"];
	} */

	const productVariantsAll 	=	await ProductVariants.find(val_filter);

	if(Array.isArray(productVariantsAll) && productVariantsAll.length > 0) {
		return res.status(201).json({
			status: 'error',
			message: 'Product variant is already available. Please attribute value.'
		});
	}


	if(product["id"] !== undefined && product["id"] !== null && product["id"] !== '') {
		const user = await ProductVariants.findOneAndUpdate({_id: product["id"]}, update_data);
		return res.status(201).json({
			status: 'success',
			message: 'Product updated.'
		});
	} else {
		const pv = await ProductVariants.create(update_data);

		var product_image 		=	"";
		var statusOfFileUpload 	= 	true;
		
		console.log("resFiles", resFiles);

		for await (const  file of resFiles['image']) {

			if(pv._id != undefined && pv._id != null && pv._id != '') {
			
				const filePath	=	'public/products/'+pv.product_id+'/';
				const getName 	=	await getFileName(next);
				const fileName	=	`${getName}${path.extname(file.originalname)}`;
				const fileUploadStatus =   await generalFileUpload(file, filePath, fileName, next);

				console.log("File Status", fileUploadStatus);
	
				if(!fileUploadStatus) {
					statusOfFileUpload = false;
					break;
				}
	
				product_image	=	fileName;
			}			

			if(product_image != "") {
				const user = await ProductVariants.findOneAndUpdate({_id: pv._id}, { image: product_image });
			}

			if(!statusOfFileUpload) {
				return res.status(201).json({
					status: 'error',
					message: 'File upload failed.',
					data: pv
				});
			}
			
		}

		res.status(201).json({
			status: 'success',
			message: 'Product added.',
			data: pv
		});
	}
});

export const manageAttribute = asyncHandler(async(req, res, next) => {
	const attribute = req.body;

	var update_data 	=	{ ...attribute };
	delete update_data["id"];

	if(attribute["id"] !== undefined && attribute["id"] !== null && attribute["id"] !== '') {
		const user = await Attributes.findOneAndUpdate({_id: attribute["id"]}, update_data);
		res.status(201).json({
			status: 'success',
			message: 'Attribute updated.'
		});
	} else {
		const user = await Attributes.create(update_data);
		res.status(201).json({
			status: 'success',
			message: 'Attribute added.'
		});
	}
});

export const manageDiscount = asyncHandler(async(req, res, next) => {
	const discount = req.body;
	var update_data 	=	{ ...discount };
	delete update_data["id"];

	if(discount["id"] !== undefined && discount["id"] !== null && discount["id"] !== '') {
		const user = await Discounts.findOneAndUpdate({_id: discount["id"]}, update_data);
		res.status(201).json({
			status: 'success',
			message: 'Discount updated.'
		});
	} else {
		const user = await Discounts.create(update_data);
		res.status(201).json({
			status: 'success',
			message: 'Discount added.'
		});
	}
});

export const getAllSource = asyncHandler(async(req, res, next) => {

	const options = await ProductCategories.aggregate([
		{ 
			$match: {
			status: 1
			}
		},
		{
			
			$project: {
				value:"$_id",
				label:"$name",
				option_type: "product_category_options"
			}
		},
		{
			$unionWith: {
				coll: "discounts",
				pipeline: [
					{
						$match: {
							status: 1
						}
					},
					{
						$project: {
							value: "$_id",
							label: "$name",
							option_type: "discount_options"
						}
					}
				]
			}
		},
		{
			$unionWith: {
				coll: "attributes",
				pipeline: [
					{
						$match: {
							status: 1
						}
					},
					{
						$project: {
							value: "$_id",
							label: "$label",
							option_type: "attribute_options"
						}
					}
					
				]
			}
		},
		{
			$unionWith: {
				coll: "products",
				pipeline: [
					{
						$match: {
							status: 1
						}
					},
					{
						$project: {
							value: "$_id",
							label: "$name",
							option_type: "product_options"
						}
					}
					
				]
			}
		},
		{
			$group: {
				_id: "$option_type",
				options: {
					$push: {
						value: "$value",
						label: "$label"
					}
				}
			}
		}
	]);

	res.status(200).json({
		status: 'success',
		message: 'Options',
		data: options
	});

});

export const getProducts = asyncHandler(async(req, res, next) => {

	var tempFilter = {
		"$or": []
	};
	var tempSearchFilter = {};

	var category_filter 	=	false;

	if(req.body.product_category !== undefined && req.body.product_category !== null && Array.isArray(req.body.product_category) && req.body.product_category.length > 0) {
		req.body.product_category.forEach((pci, i) => {
			tempFilter["$or"].push({ "_id": new mongoose.Types.ObjectId(pci) });
		});

		category_filter	=	true;
	}

	if(req.body.search_product !== undefined && req.body.search_product !== null && req.body.search_product !== '') {
		tempSearchFilter["$match"]	=	{ "product.name": new RegExp(req.body.search_product, 'i') }
	}

	var queryFilter 	=	[
		{
			$lookup: {
				from: "productvariants",
				localField: "_id",
				foreignField: "product_id",
				as: "variants"
			}
		},
		{
			$lookup: {
				from: "productcategories",
				localField: "product_category",
				foreignField: "_id",
				as: "category"
			}
		},
		{
			$lookup: {
				from: "discounts",
				localField: "variants.discount_id",
				foreignField: "_id",
				as: "discount"
			}
		},
		{
			$lookup: {
				from: "attributes",
				localField: "variants.attribute_id",
				foreignField: "_id",
				as: "attributes"
			}
		},
		{
			$lookup: {
				from: "attributes",
				localField: "attribute_id",
				foreignField: "_id",
				as: "product_attributes"
			}
		},
		{
			$lookup: {
				from: "discounts",
				localField: "discount_id",
				foreignField: "_id",
				as: "product_discount"
			}
		},
		{
			$unwind: { path: "$category" }
		},
		{
			$group: {
				
				"_id": "$product_category",
				product: {
					$push: {
						"_id": "$_id",
						"category": "$category",
						"description": "$description",
						"name": "$name",
						"price": "$price",
						"product_category": "$product_category",
						"status": "$status",
						"variants": "$variants",
						"discount_id": "$variants.discount_id",
						"discount": "$discount",
						"product_discount": "$product_discount",
						"product_attributes": "$product_attributes",
						"product_attribute_value": "$attribute_value",
						"attributes": "$attributes",
						"image": "$image",
						"path": req.protocol+"://"+req.get('host')+"/public/products/"
					}
				}
			}
			
		},
		/* {
			$project: {
				product: {
					$slice: ['$product', 0, 2]
				}
			}
		}, */
		{
			"$project": {
				"_id": "$_id",
				"product": (category_filter) ? "$product" : { "$slice": ["$product", 0, 3] }
			}
		},
		{
			"$project": {
				"_id": "$_id",
				"product": "$product",
				"category": "$product.category.name",
			}
		},
		{
			"$unwind": "$product"
		},
		{
			$sort: {
				'name': 1
			}
		}
	];

	if(Object.keys(tempSearchFilter).length > 0) {
		queryFilter.push(tempSearchFilter);
	}
	

	if(req.body.product_category !== undefined && req.body.product_category !== null && Array.isArray(req.body.product_category) && req.body.product_category.length > 0) {
		
		queryFilter.push({
			$match: tempFilter
		});
		
	} else {

		/* queryFilter.push({
			$project: {
				product: {
					$slice: ['$product', 0, 3]
				}
			}
		}); */
	}

	console.log(queryFilter);

	const products 	=	await Products.aggregate(queryFilter);

	res.status(200).json({
		status: 'success',
		message: 'Options',
		data: products
	});

});