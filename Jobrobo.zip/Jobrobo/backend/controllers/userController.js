import asyncHandler from 'express-async-handler';
import validator from 'express-validator';
import Users from '../models/UserModel.js';
import { generateToken, getUserId, checkValidation, verifyToken } from '../middleware/authMiddleware.js';
import { customValidationResult, userValidationSchema } from '../middleware/validationSchemas.js';
import { jsonResponse, checkFileError } from '../utils/CommonFunction.js';

export const login = asyncHandler(async(req, res, next) => {
	const user = await Users.find({
		email: req.body.email,
		password: req.body.password
	}).exec();

	res.status(201).json({
		status: 'success',
		message: 'User logined successfully.',
		user: user,
		token: generateToken(user[0]._id)
	});
});

export const getUser = asyncHandler(async(req, res, next) => {
	const user_id =	await getUserId(req);
	const user = await Users.find({
		_id: user_id
	}).exec();

	res.status(201).json({
		status: 'success',
		message: 'User get successfully.',
		user: user
	});
});

export const getUserInfo = asyncHandler(async(req, res, next) => {
	const user_id =	await getUserId(req);
	const user = await Users.find({
		_id: req.body.id
	}).exec();

	res.status(201).json({
		status: 'success',
		message: 'User get successfully.',
		user: user
	});
});

export const signup = asyncHandler(async(req, res, next) => {
	let userDetails = req.body;
	let date = new Date();


	let filter = { email: userDetails["email"] };
	if(userDetails["id"] != undefined && userDetails["id"] != null && userDetails["id"] != '') {
		filter["_id"]	=	{ $ne: userDetails["id"] }
	}
	const checkEmail = await Users.find(filter);

	if(checkEmail.length > 0) {
		return jsonResponse(res, 200, 'error', "Email address already taken.");;
	}

	let userData = {
		type: userDetails.type,
		name: userDetails.name,
		dob: userDetails.dob,
		email: userDetails.email,
		password: userDetails.password,
		mobile_number: userDetails.mobile_number,
		address: userDetails.address,
		gender: userDetails.gender,
		profile_image: '',
		status: 1,
		created_on: date,
		modified_on: ''
	}

	const user = await Users.create(userData);
	if(user) {
		res.status(201).json({
			status: 'success',
			message: 'User created.',
			user: user
		});
	} else {
		res.status(404);
		throw new Error('Something went wrong');
	}
});


export const manageUser = asyncHandler(async function (req, res, err, next) {

	const { checkSchema } 	=	validator;
	let userDetails 		=	{ ...req.body };
	let date 				= 	new Date();

	const result = await checkSchema(userValidationSchema, ["body"]).run(req);

	const validationResultError = customValidationResult(req).array();
	if(validationResultError.length > 0) {
        console.log('Validation-Error===>'+JSON.stringify(validationResultError));
		res.status(200).json(validationResultError[0]);
    }

	const resFiles	=	(req.files != undefined && req.files != null && Object.keys(req.files).length != 0
	) ? req.files : { "profile_image_file": [] };

    const errorStatus   =   await checkFileError(err);

    if(errorStatus['status']) {
        return jsonResponse(res, 200, 'error', errorStatus['message']);
    }

	let filter = { email: userDetails["email"], type: userDetails["type"] };
	if(userDetails["id"] != undefined && userDetails["id"] != null && userDetails["id"] != '') {
		filter["_id"]	=	{ $ne: userDetails["id"] }
	}

	const checkEmail = await Users.find(filter);

	if(checkEmail.length > 0) {
		return jsonResponse(res, 200, 'error', "Email address already taken.");;
	}

	var statusOfFileUpload	=	true;
	var profileImage 		=	"";

	for await (const  file of resFiles['profile_image_file']) {
		if(userDetails.id != undefined && userDetails.id != null && userDetails.id != '') {
			const filePath	=	'public/profiles/'+userDetails.id+'/';
			const getName 	=	await getFileName(next);
			const fileName	=	`${getName}${path.extname(file.originalname)}`;
			const fileUploadStatus =   await generalFileUpload(file, filePath, fileName, next);

			if(!fileUploadStatus) {
				statusOfFileUpload = false;
				break;
			}

			profileImage	=	fileName;
		}
	}

	if(!statusOfFileUpload) {
        return jsonResponse(res, 200, 'success', 'Photo upload failed.');
    }

	var userData = {
		type: userDetails.type,
		name: userDetails.name,
		dob: new Date(userDetails.dob),
		email: userDetails.email,
		password: userDetails.password,
		mobile_number: userDetails.mobile_number,
		address: userDetails.address,
		gender: userDetails.gender,
		created_by_admin: userDetails.created_by_admin,
		status: 1,
		created_on: date,
		modified_on: ''
	}

	if(profileImage != undefined && profileImage != null && profileImage != "") {
		userData["profile_image"]	=	profileImage;
	}

	if(userDetails["id"] != undefined && userDetails["id"] != null && userDetails["id"] != '') {
		const user = await Users.findOneAndUpdate({_id: userDetails["id"]}, userData);
		res.status(201).json({
			status: 'success',
			message: 'User updated.',
			user: user
		});
	} else {
		
		const user = await Users.create(userData);
		if(user) {
			res.status(201).json({
				status: 'success',
				message: 'User created.',
				user: user
			});
		} else {
			res.status(404);
			throw new Error('Something went wrong');
		}
	}
});