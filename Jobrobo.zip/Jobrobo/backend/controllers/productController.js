import asyncHandler from 'express-async-handler'
import { generateToken, getUserId } from '../middleware/authMiddleware.js';
import { jsonResponse } from '../utils/CommonFunction.js';


export const getProduct = asyncHandler(async(req, res, next) => {
	const product = [];

	res.status(201).json({
		status: 'success',
		message: 'Product List successfully.',
		product: product
	});
});
