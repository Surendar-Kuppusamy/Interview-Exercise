import mongoose from 'mongoose';

var Schema = mongoose.Schema;

const UserSchema = new Schema({
    type: {        //type (1 - Admin, 2 - User)
        type: Number,
        required: [true, 'Type required.'],
        enum: {
            values: [1, 2],
            message: '{VALUE} is invalid status.'
        }
    },
    name:  {
        type: String,
        trim: true,
        required: [true, 'Name required.'],
        minLength: [3, 'Name must have minimum 3 characters.'],
        maxLength: [50, 'Maximum character for name should be 50 characters.']
    },
    dob:  {
        type: Date,
        trim: true,
        required: [true, 'Date of birth required.']
    },
    email:  {
        type: String,
        trim: true,
        unique: true,
        required: [true, 'Email required.'],
        validate: {
            validator: function(value) {
                return new Promise((resolve, reject) => {
                    const email_pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    resolve(email_pattern.test(value));
                });
            },
            message: props => `${props.value} is not a valid emial!`
        }
    },
    password:  {
        type: String,
        trim: true,
        required: [true, 'Password required.']
    },
    gender:  {
        type: String,
        trim: true,
        required: [true, 'Gender required.']
    },
    mobile_number:  {
        type: Number,
        trim: true,
       /*  required: [true, 'Mobile number required.'],
        validate: {
            validator: function(value) {
                return new Promise((resolve, reject) => {
                    if(value.toString().length != 10) {
                        resolve(false);
                    } else {
                        resolve(true);
                    }
                });
            },
            message: 'Mobile number must be 10 digits.'
        } */
    },
    address: {
        type: String,
        trim: true,
        required: [true, 'Address is required.']
    },
	profile_image: {
        type: String,
        trim: true
    },
    status: {        //status (1 - active, 2 - disabled, 3 - Deleted)
        type: Number,
        required: [true, 'Status required.'],
        enum: {
            values: [1, 2],
            message: '{VALUE} is invalid status.'
        }
    },
    created_on: {
        type: Date,
    },
    modified_on: {
        type: Date,
        default: Date.now
    }
})

const Users = mongoose.model("Users", UserSchema);
export default Users;