import mongoose from 'mongoose';

var Schema = mongoose.Schema;

const ProductSchema = new Schema({
    name:  {
        type: String,
        trim: true,
        required: [true, 'Name required...'],
        minLength: [2, 'Name must have minimum 3 characters.'],
        maxLength: [500, 'Maximum character for name should be 50 characters.']
    },
    description: {
        type: String,
        required: [true, "Please enter product description"]
    },
    price: {
        type: Number,
        required: [true, "Please enter product price"]
    },
    image: {
        type: String,
        trim: true
    },
    discount_id: {
        type: 'ObjectId',
        ref: 'discounts'
    },
    attribute_id: {
        type: 'ObjectId',
        ref: 'attributes'
    },
    attribute_value: {
        type: Number,
        required: [true, "Please enter attribute values"]
    },
    product_category: {
        type: 'ObjectId',
        ref: 'productcategories'
    },
    status: {        //status (1 - active, 2 - disabled, 3 - Deleted)
        type: Number,
        required: [true, 'Status required.'],
        enum: {
            values: [1, 2, 3],
            message: '{VALUE} is invalid status.'
        }
    },
    created_by: {
        type: 'ObjectId',
        ref: 'Users'
    },
    modified_by: {
        type: 'ObjectId',
        ref: 'Users'
    },
    created_on: {
        type: Date,
    },
    modified_on: {
        type: Date,
        default: Date.now
    }
})

const Products = mongoose.model("Products", ProductSchema);
export default Products;