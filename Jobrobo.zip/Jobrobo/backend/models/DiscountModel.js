import mongoose from 'mongoose';

var Schema = mongoose.Schema;

const DiscountSchema = new Schema({
    name:  {
        type: String,
        trim: true,
        required: [true, 'Name required...'],
        minLength: [3, 'Name must have minimum 3 characters.'],
        maxLength: [50, 'Maximum character for name should be 50 characters.']
    },
    description: {
        type: String,
        trim: true
    },
    percentage: {
        type: Number,
        required: [true, 'Discount Percentage required.']
    },
    status: {        //status (1 - active, 2 - disabled, 3 - Deleted)
        type: Number,
        required: [true, 'Status required.'],
        enum: {
            values: [1, 2, 3],
            message: '{VALUE} is invalid status.'
        }
    },
    created_by: {
        type: 'ObjectId',
        ref: 'Users'
    },
    modified_by: {
        type: 'ObjectId',
        ref: 'Users'
    },
    created_on: {
        type: Date,
    },
    modified_on: {
        type: Date,
        default: Date.now
    }
})

const Discounts = mongoose.model("Discounts", DiscountSchema);
export default Discounts;