import mongoose from 'mongoose';

var Schema = mongoose.Schema;

const AttributeSchema = new Schema({
    name:  {
        type: String,
        trim: true,
        required: [true, 'Name required...'],
        minLength: [1, 'Name must have minimum 3 characters.'],
        maxLength: [50, 'Maximum character for name should be 50 characters.']
    },
    label:  {
        type: String,
        trim: true,
        required: [true, 'Label required...'],
        minLength: [1, 'Label must have minimum 3 characters.'],
        maxLength: [50, 'Maximum character for label should be 50 characters.']
    },
    description: {
        type: String,
        trim: true
    },
    status: {        //status (1 - active, 2 - disabled, 3 - Deleted)
        type: Number,
        required: [true, 'Status required.'],
        enum: {
            values: [1, 2, 3],
            message: '{VALUE} is invalid status.'
        }
    },
    created_by: {
        type: 'ObjectId',
        ref: 'Users'
    },
    modified_by: {
        type: 'ObjectId',
        ref: 'Users'
    },
    created_on: {
        type: Date,
    },
    modified_on: {
        type: Date,
        default: Date.now
    }
})

const Attributes = mongoose.model("Attributes", AttributeSchema);
export default Attributes;