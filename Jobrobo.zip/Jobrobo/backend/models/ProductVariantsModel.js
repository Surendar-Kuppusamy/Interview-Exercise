import mongoose from 'mongoose';

var Schema = mongoose.Schema;

const ProductVariantsSchema = new Schema({
    product_id: {
        type: 'ObjectId',
        ref: 'products'
    },
    attribute_id: {
        type: 'ObjectId',
        ref: 'attributes'
    },
    attribute_value: {
        type: Number,
        required: [true, "Please enter attribute values"]
    },
    discount_id: {
        type: 'ObjectId',
        ref: 'discounts'
    },
    price: {
        type: Number,
        required: [true, "Please enter product price"]
    },
    image: {
        type: String,
        trim: true
    },
    status: {        //status (1 - active, 2 - disabled, 3 - Deleted)
        type: Number,
        required: [true, 'Status required.'],
        enum: {
            values: [1, 2, 3],
            message: '{VALUE} is invalid status.'
        }
    },
    created_by: {
        type: 'ObjectId',
        ref: 'Users'
    },
    modified_by: {
        type: 'ObjectId',
        ref: 'Users'
    },
    created_on: {
        type: Date,
    },
    modified_on: {
        type: Date,
        default: Date.now
    }
})

const ProductVariants = mongoose.model("ProductVariants", ProductVariantsSchema);
export default ProductVariants;