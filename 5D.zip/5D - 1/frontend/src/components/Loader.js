import React from 'react';

function Loader() {
    return (
        <div id="cover-spin"></div>
    );
}

export default Loader;