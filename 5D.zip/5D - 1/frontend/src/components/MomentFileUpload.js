import React, { useCallback, useEffect, useState, forwardRef, useImperativeHandle } from 'react';
import { useDropzone } from 'react-dropzone';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEye, faEyeSlash, faFilePdf, faImage, faFileText } from '@fortawesome/free-solid-svg-icons';
import { toast } from 'react-toastify';
import { ArrowIcon } from '../components/Icons';


function MomentFileUpload(props, ref) {

	const [files, setFiles] = useState([]);
	const [uploadProgress, setUploadProgress] = useState(0);

	const onDrop = useCallback((acceptedFiles) => {
		props.cancelAllTokens();
		// Clear any previous files
		setFiles(acceptedFiles);
		props.setUploadedFiles(acceptedFiles);
		//console.log(acceptedFiles);
	}, []);

	useEffect(() => {
		props.uploadFilesToServer();
	},[files]);

	const onDropRejected = useCallback((fileRejections) => {
		//console.log("fileRejections", fileRejections);
		props.setRejectedFiles(fileRejections);
	}, []);

	const { acceptedFiles, fileRejections, getRootProps, getInputProps } = useDropzone({ onDrop, onDropRejected, noDrag: props.isDragable, multiple: props.isMultipleFileUpload, maxSize: props.maxFileSize, maxFiles: props.maxFiles, accept: props.fileTypes, disabled: props.dropzoneStatus });

	return (
		<section className={props.dropzoneStatus ? " m-5 p-5 bg-secondary container " : "container"}>
			<div {...getRootProps({ className: 'dropzone border border-dark text-center m-5 p-5' })} style={{ borderStyle: "dashed" }}>
				<input {...getInputProps()} />
				<ArrowIcon />
				<h5>Drag and drop files</h5>
				<h2 className="bold">OR</h2>
				<button type="button" className="btn btn-md btn-dark btn-radius" id="button" name="button">Browse</button>
			</div>
		</section>
	);
}
export default forwardRef(MomentFileUpload);
