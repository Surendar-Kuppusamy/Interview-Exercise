import axios from 'axios';
import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { isEmpty, findIndex } from 'lodash';
import { USER_MOMENT, USER_SIGNUP } from '../utils/Apiconstants';

axios.interceptors.request.use(function (config) {
    config.headers['Authorization'] = `Bearer ${(localStorage.getItem("token")? localStorage.getItem("token") : '')}`;
    config.headers['Content-Type'] = 'application/json';
    return config;
}, null, { synchronous: true });


function clearLocalStorage() {
    localStorage.removeItem('user_detail');
    localStorage.removeItem('token');
}

const resetValues     =   {
    'site_loader'                   :   false,
    'page_loader'                   :   false,
    'manual_site_loader'            :   false,
    'token'                         :   '',
    'user_detail'                   :   {}
}


const initialState = {
    'site_loader'                   :   false,
    'page_loader'                   :   false,
    'first_load'                    :   true,
    'manual_site_loader'            :   false,
    'pending_actions'               :   [],
    'token'                         :   localStorage.getItem('token')
                                            ? localStorage.getItem('token')
                                            : '',
    'user_detail'                   :   localStorage.getItem('user_detail')
                                            ? JSON.parse(localStorage.getItem('user_detail'))
                                            : {}
}

export const signupUser = createAsyncThunk(
    "user/signup",
    async (formData, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {
            
            const { data } = await axios.post(USER_SIGNUP, formData);

            //console.log("data", data);

            resolve(data);
        });        
    }
);

export const newMoment = createAsyncThunk(
    "new/moment",
    async (formData, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {
            
            const { data } = await axios.post(USER_MOMENT, formData);
            //console.log("data", data);

            resolve(data);
        });        
    }
);


/* export const userAddEditApi = createAsyncThunk(
    "user/add/edit/api",
    async (userData, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {

            let USER_API  =   ALL_API["MANAGER_USER"];

            let day = new Date(userData["dob"]).getDate();
            let month = new Date(userData["dob"]).getMonth();
            let year = new Date(userData["dob"]).getFullYear();

            month   =   month + 1;
            month   =   (month > 9) ? month : '0'+month;
            day     =   (day > 9) ? day : '0'+day;
            userData["dob"] =   year+'-'+month+'-'+day;

            console.log(userData["dob"], " ---Tet");

            var formData = new FormData();
            for (const [key, value] of Object.entries(userData)) {
                
                if(key == "profile_image_file" && value != null && value.length > 0) {
                    formData.append("profile_image_file", value[0], value[0]["name"]);
                } else if(key == "id" && value != null && value != '') {
                    formData.append(key, value);
                } else if(key != "profile_image_file" && key != "id") {
                    formData.append(key, value);
                }
            }
            
            const { data } = await axios.post(USER_API, formData, {
                headers: {
                    'Content-Type': `multipart/form-data; boundary=${formData._boundary}`,
                }
            });

            console.log("data", data);

            resolve(data);
        });        
    }
); */


export const logoutUser = createAsyncThunk(
    "user/logout",
    async(data, { getState, rejectWithValue }) => {
        return new Promise(async(resolve, reject) => {
            resolve(data);
        });
    }
);



const globalSlice = createSlice({
    name: "global",
    initialState,
    reducers: {
        siteLoader: (state, action) => {
            state['site_loader'] = action.payload;
        },
        setUserDetails: (state, action) => {
            state["user_detail"]    =   action.payload;
        },
        resetState: (state, action) => {

            clearLocalStorage();

            state['token']          =   '';
            state['user_detail']    =   {};
        },
        pageLoader: (state, action) => {
            state['page_loader'] = action.payload;
        },
        setManualSiteLoader: (state, action) => {
            state['manual_site_loader'] =   action.payload;
        }
    },
    extraReducers: (builder) => {
        builder
            .addCase(signupUser.fulfilled, (state, action) => {

                //console.log('User signup response', action.payload);

                if(action.payload.status == 'success') {

                    state['token']  =   action.payload.token;
                    localStorage.setItem('token', action.payload.token);

                    state['user_detail']    =   action.payload.user;
                    localStorage.setItem('user_detail', JSON.stringify(action.payload.user));
                    
                }
                
            })
            .addCase(logoutUser.fulfilled, (state, action) => {

                //console.log("logut Global slice");

                clearLocalStorage();

                state['token']                          =   '';
                state['user_detail']                    =   {};
        
            })
            .addMatcher(
                (action) => action.type.endsWith('/pending'),
                (state, action) => {

                    state['pending_actions'].push(action.type)

                    if(!state['site_loader']) {
                        state['site_loader'] = true;
                    }
                }
            )
            .addMatcher(
                (action) => action.type.endsWith('/rejected'),
                (state, action) => {
                    var actionType  =   action.type;
                    actionType = actionType.replace("rejected", "pending")

                    var index = state['pending_actions'].indexOf(actionType);
                    if(index !== -1) {
                        state['pending_actions'].splice(index, 1);

                        if(state['site_loader'] && state['pending_actions'].length === 0) {
                            state['site_loader']    =   false;
                        }
                    } else {
                        if(state['site_loader'] && state['pending_actions'].length === 0) {
                            state['site_loader'] = false;
                        }
                    }

                }
            )
            .addMatcher(
                (action) => action.type.endsWith('/fulfilled'),
                (state, action) => {
                    var actionType  =   action.type;
                    actionType = actionType.replace("fulfilled", "pending");

                    var index = state['pending_actions'].indexOf(actionType);
                    if(index !== -1) {
                        state['pending_actions'].splice(index, 1);

                        if(state['site_loader'] && state['pending_actions'].length === 0) {
                            state['site_loader']    =   false;
                        }
                    } else {
                        if(state['site_loader'] && state['pending_actions'].length === 0) {
                            state['site_loader'] = false;
                        }
                    }

                    if(actionType   ===  'user/auto/logout/pending') {
                        const tempActions   =   state['pending_actions'];
                        for(var i = 0; i < tempActions.length; i++) {
                            if(state['pending_actions'][i] === 'user/auto/logout/pending') {
                                state['pending_actions'].splice(i, 1);
                            }
                        }
                    }
                }
            )
    }
});


// Action creators are generated for each case reducer function
export const { siteLoader,  resetState, setUserDetails, pageLoader, setManualSiteLoader } = globalSlice.actions;

const { reducer } = globalSlice;
export default reducer;