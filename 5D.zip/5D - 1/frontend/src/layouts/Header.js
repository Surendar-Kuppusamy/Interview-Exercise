import React, { useEffect, useState, useMemo, useRef } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Outlet, Link, useLocation, useNavigate } from "react-router-dom";
import Select, { components } from "react-select";
import { useCookies } from 'react-cookie';
import { USER_START_ROUTE_PATH, ADMIN_START_ROUTE_PATH, COOKIE_NAME } from '../utils/GlobalConstants.js';
import { getAllOptions, getProductAll, setAllProductCategories, setAllProducts } from '../slices/globalSlice.js';

const Icons        =   React.lazy(() => import('../components/Icons'));

function Header(props) {

    const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

    const dispatch          =   useDispatch();
    const navigate          =   useNavigate();
    const globalState       =   useSelector(app => app.global);
    const location          =   useLocation();

    const [cookies, setCookie, removeCookie]    =   useCookies([COOKIE_NAME]);
    const [activeNav, setActiveNav]             =   useState('/');
    const [collapse, setCollapse]               =   useState(false);

    useEffect(() => {
        setActiveNav(location.pathname);
    },[location]);

    const headerMenuClass   =   (menuPath) => {
        if(location.pathname.endsWith(menuPath)) {
            return 'nav-link active pointer';
        } else {
            return 'nav-link pointer';
        }
    }

    const headerNavMenuClass   =   (menuPath) => {
        if(location.pathname.endsWith(menuPath)) {
            return 'nav-item active pointer';
        } else {
            return 'nav-item pointer';
        }
    }


    if(location.pathname.startsWith("/signup")) {
        return (
            <nav className="navbar navbar-expand-sm navbar-dark bg-dark">
                <div className="container-fluid">
                    {/* <a className="navbar-brand   justify-content-center" href="/signup">
                        <img src="/logod5.png" />
                    </a> */}
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse justify-content-center p-3" id="mynavbar">
                        <ul className="navbar-nav ">
                            <li className={headerNavMenuClass("/signup")}>
                                <a className="navbar-brand  justify-content-center" href="/signup">
                                    <img src="/logod5.png" />
                                </a>
                            </li>
                        </ul>

                    </div>
                </div>
            </nav>
        )
    } else {
        return (
            <nav className="navbar navbar-expand-sm navbar-dark bg-light">
                <div className="container-fluid">
                    <a className="navbar-brand px-5 py-2" href="/signup">
                        <Icons />
                    </a>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="mynavbar">
                        <ul className="navbar-nav ml-auto">
                            <li className={headerNavMenuClass("/signup")}>
                                <a className={headerMenuClass("/signup")} href="/signup">Create Discount</a>
                            </li>
                        </ul>
                        <form className="d-flex ml-2">
                            <a className="btn btn-primary mr-3" href={'/logout'}>Logout</a>
                            <div className="dropdown">
                                <button className="btn btn-light dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false" onClick={e => setCollapse(!collapse)}>
                                    <img src={"/user.png"} width={25} className="rounded mx-auto" />
                                </button>
                                <ul className={collapse ? "dropdown-menu show"  : "dropdown-menu"} aria-labelledby="dropdownMenuButton1">
                                    <li>
                                        <a className="dropdown-item btn btn-primary mr-3" href={'/logout'}>Logout</a>
                                    </li>
                                </ul>
                            </div>
                        </form>
                    </div>
                </div>
            </nav>
        )
    }
}

export default Header;