import React, { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Outlet, Link, useLocation, useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { toast } from 'react-toastify';
import { faFileAlt } from '@fortawesome/free-solid-svg-icons';
import { RightArrow } from '../components/Icons';

function Sidebar(props) {

    const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

    const dispatch      =   useDispatch();
    const navigate      =   useNavigate();
    const location      =   useLocation();
    const globalState   =   useSelector(app => app.global);

    const [collapse, setCollapse]   =   useState("show");
    

    const activeMenuClass   =   (startPath, endPath, condType, defaultClass, expClass)  => {
        if(condType === 'both' && location.pathname.startsWith(startPath) && location.pathname.endsWith(endPath)) {
            return defaultClass+' '+expClass;
        } else if(condType === 'start' && location.pathname.startsWith(startPath)) {
            return defaultClass+' '+expClass;
        } else if(condType === 'end' && location.pathname.endsWith(endPath)) {
            return defaultClass+' '+expClass;
        } else if(condType === 'or' && (location.pathname.startsWith(startPath) || location.pathname.endsWith(endPath))) {
            return defaultClass+' '+expClass;
        } else {
            return defaultClass;
        }
    }

    const navigationPath    =   (path)  => {
        return path;
    }

    if(location.pathname.startsWith("/signup")) {
        return (
            <div className="container-fluid">
                <div className="col py-3">
                    {
                        props.children
                    }
                </div>
            </div>
        );
    } else {
    
        return (
            <div className="container-fluid">
                <div className="row flex-nowrap">
                    <div className="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-light">
                        <div className="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                            <a href="/" className="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-white text-decoration-none">
                                <span className="fs-5 d-none d-sm-inline">Menu</span>
                            </a>
                            <ul className="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start" id="menu">
                                <li className="nav-item fs-1 fw-bold fsc-1">
                                    <a href="" className="nav-link align-middle px-0 pl-2">
                                        <span className="ms-1 d-none d-sm-inline">Profile</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="" data-bs-toggle="collapse" className="nav-link px-0 align-middle bg-dark text-white pl-2" onClick={e => { e.preventDefault(); setCollapse((collapse=="show") ? "hide" : "show")} }>
                                        <span className="ms-1 d-none d-sm-inline fsc-1">Moments</span>
                                        <span className="ml-2 pr-2">
                                            <RightArrow />
                                        </span>
                                    </a>

                                    <ul className={collapse == "hide" ? "collapse nav flex-column ms-1" : "collapse show nav flex-column ms-1"} id="submenu2" data-bs-parent="#menu">
                                        <li className="w-100 ml-3">
                                            <a href="/moment" className="nav-link px-0 fs-bold text-dark"> <span className="d-none d-sm-inline">Moment List</span></a>
                                        </li>
                                        <li className="w-100 ml-3 active">
                                            <a href="/moment" className="nav-link px-0 fs-bold text-dark"> <span className="d-none d-sm-inline">Add New Moment</span></a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div className="col py-3">
                        {
                            props.children
                        }
                    </div>
                </div>
            </div>
        );

    }
    
}

export default Sidebar;