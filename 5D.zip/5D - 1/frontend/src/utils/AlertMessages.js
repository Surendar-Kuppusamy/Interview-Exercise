export const ALERT_MESSAGES = {
    'first_name_required'       :   'First Name Required.',
    'last_name_required'        :   'Last Required.',
    'email_required'            :   'Email Required.',
    'invalid_email'             :   'Invalid Email.',
    'password_required'         :   'Password Required.',
    'mobile_required'           :   'Mobile Required',
    'mobile_number_is_invalid'  :   'Mobile Number is invalid',
    'country_required'          :   'Country Required',
    'mobile_length'             :   'Mobile number should be 10 numbers only',
    'tag_required'              :   'Tag is required.',
    'title_required'            :   'Title required.',
    'comment_required'          :   'Comment required.'
}