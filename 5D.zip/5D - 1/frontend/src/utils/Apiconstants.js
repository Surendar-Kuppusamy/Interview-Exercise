export const HOST = 'http://localhost:3001/';
export const USER_SIGNUP = HOST+'api/user/signup';
export const USER_MOMENT =  HOST+'api/user/add/moment';
export const UPLOAD_MOMENT =  HOST+'api/user/upload/moments';