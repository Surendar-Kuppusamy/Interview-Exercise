export const MAXIMUM_FILE_SIZE          =   9000000;
export const DEFAULT_PER_PAGE           =   20;
export const COOKIE_NAME                =   "D5";
const FILE_TYPES                        =   ["image/png", "image/jpeg", "image/jpg", "application/pdf", "text/plain"];
export const VALID_FILE_TYPES           =   FILE_TYPES.join(",");
export const ALL_VALID_IMAGE_TYPES      =   { 'image/*': ['.jpeg', '.jpg', '.png', '.heic'] };

export const APP_VERSION = '1.0.0';
export const PAGINATION_DEFAULT_OBJECT = { pageRange: 5, total: 0, allFetchedData: [], filteredData: [] };
export const PAGINATION_VALUES  =   { limit: 2, offset: 0 };

