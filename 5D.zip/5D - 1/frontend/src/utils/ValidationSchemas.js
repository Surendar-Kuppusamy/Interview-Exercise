import * as yup from "yup";
import { isValidPhoneNumber } from 'react-phone-number-input';
import { ALERT_MESSAGES } from './AlertMessages';
import moment from "moment";

export const EmailReg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w\w+)+$/;
export const PasswordReg = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[\^$*.\[\]{}\(\)?\-\"!@#%&\/,><\':;|_~`])\S{8,99}$/;
export const UpperCaseReg = /(?=.*[A-Z])/;
export const SpaceCaseReg = /\s/;
export const LowerCaseReg = /(?=.*[a-z])/;
export const NumberCaseReg = /(?=.*[0-9])/;
export const SpecialCaseReg = /(?=.*[\^$*.\[\]{}\(\)?\-"!@#%&\/,><\’:;|_~`])(?=.*[\^$*.\[\]{}\(\)?\-"!@#%&\/,><\’:;|_~`])/;
export const specialChars = /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
export const usernameReg = /^[a-zA-Z][a-zA-Z0-9]+[0-9]*$/;
export const NoSpace = /^[^-\s]{8,30}$/;
export const userFullReg = /^[a-zA-Z][a-zA-Z\s]*$/;


export const UserSchema   =    yup.object().shape({
    first_name      :   yup.string().trim()
                            .required(ALERT_MESSAGES['first_name_required']),
    last_name       :   yup.string().trim()
                            .required(ALERT_MESSAGES['last_name_required']),
    email           :   yup.string().trim()
                            .required(ALERT_MESSAGES['email_required'])
                            .email(ALERT_MESSAGES['invalid_email']),
    password        :   yup.string().trim()
                            .required(ALERT_MESSAGES['password_required']),
    country         :   yup.string().trim()
                            .required(ALERT_MESSAGES['country_required']),
    mobile_number   :   yup.string().trim()
                            .required(ALERT_MESSAGES['mobile_required'])
                            .test('validPhoneNumber', ALERT_MESSAGES['mobile_number_is_invalid'], 
                            function(value) {
                                if(value === undefined || value === null) {
                                    return false;
                                }
                                return isValidPhoneNumber(value);
                            }
                        )
});

export const MomentSchema   =    yup.object().shape({
    title           :   yup.string().trim()
                            .required(ALERT_MESSAGES['title_required']),
    comment         :   yup.string().trim()
                            .required(ALERT_MESSAGES['comment_required'])
                            .max(100, 'Comment should be less than or equal to 100 characters'),
    tags            :   yup.array().of(yup.string().required(ALERT_MESSAGES['tag_required']).trim())
                            .test('validTag', ALERT_MESSAGES['tag_required'], 
                                function(value) {
                                    if(value.length > 0) {
                                        return true;
                                    }
                                    return false;
                                }
                            )
});