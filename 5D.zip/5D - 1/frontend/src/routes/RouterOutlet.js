import React, { Suspense } from 'react';
import { BrowserRouter as Router, HashRouter } from "react-router-dom";
import Loader from '../components/Loader';

const Header        =   React.lazy(() => import('../layouts/Header'));
const Footer        =   React.lazy(() => import('../layouts/Footer'));
const AllRoutes     =   React.lazy(() => import('../routes/AllRoutes'));
const Sidebar       =   React.lazy(() => import('../layouts/Sidebar'));


function RouterOutlet() {
    return (
        <Suspense fallback={<Loader />}>
            <Router>
                {
                    <>
                        <Header />
                        <main className="layout">
                            <AllRoutes />
                        </main>
                        <Footer />
                    </>
                }
            </Router>
        </Suspense>
    );
}

export default RouterOutlet;