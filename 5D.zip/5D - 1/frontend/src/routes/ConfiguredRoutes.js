import React, { Suspense, lazy, useEffect, useCallback, useMemo } from 'react';
import { Navigate } from "react-router-dom";


//Ladning Pages
const Container     =   React.lazy(() => import('../components/Container'));
const LogoutUser    =   React.lazy(() => import('../pages/auth/LogoutUser'));
const User          =   React.lazy(() => import('../pages/user/User'));
const Moment        =   React.lazy(() => import('../pages/user/Moment'));


const ConfiguredRoutes = (token) => {

    return [
        {
            path: '/logout',
            element: <LogoutUser />
        },
        {
            path: '/signup',
            element: (!token) ? <User /> : <Navigate to={'/moment'} />
        },
        {
            path: '/moment',
            element: (token) ? <Moment /> : <Navigate to={'/signup'} />
        },
        {
            path: '/',
            element: <Navigate to={'/signup'} />
        },
        {
            path: '*',
            element: <Navigate to={'/signup'} />
        },
    ];
};

export default ConfiguredRoutes;