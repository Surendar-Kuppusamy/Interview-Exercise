import React, { Suspense, lazy, useEffect, useCallback, useMemo } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { BrowserRouter as Router, Navigate, useLocation, useNavigate, Routes, Route, useRoutes } from "react-router-dom";
import ConfiguredRoutes from './ConfiguredRoutes';


function stringToBoolean(value){
    return (String(value).toLowerCase() === 'true');
}

const Container =   React.lazy(() => import('../components/Container'));
const Sidebar =   React.lazy(() => import('../layouts/Sidebar'));

function AllRoutes(props) {

    const token     =   localStorage.getItem('token')
                            ? localStorage.getItem('token')
                            : '';

    const allRouting = useRoutes(ConfiguredRoutes(token));

    return (
        <Container>
            <Sidebar>
                {allRouting}
            </Sidebar>
        </Container>
    );
}


export default AllRoutes;
