import React, { Suspense, useCallback, useRef, useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Controller, useForm } from "react-hook-form";
import { useParams, useLocation, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEye, faEyeSlash, faFilePdf, faImage, faFileText, faFileAlt } from '@fortawesome/free-solid-svg-icons';
import axios from 'axios';
import Tags from '@yaireo/tagify/dist/react.tagify';
import "@yaireo/tagify/dist/tagify.css";
import { yupResolver } from "@hookform/resolvers/yup";
import Loader from '../../components/Loader';
import { MomentSchema, UserSchema } from '../../utils/ValidationSchemas';
import { newMoment, signupUser } from '../../slices/globalSlice';
import { UPLOAD_MOMENT, USER_MOMENT } from '../../utils/Apiconstants';
import { ArrowIcon, Cross } from '../../components/Icons';


const MomentFileUpload  =   React.lazy(() => import('../../components/MomentFileUpload'));

function bytesToSize(bytes) {
    //console.log("bytes", bytes);

    if(!bytes) {
        return '0 KB';
    }

    const kilobyte = 1024;
    const megabyte = kilobyte * 1024;
  
    if(bytes < kilobyte) {
      return Math.floor(bytes) + ' B';
    } else if (bytes < megabyte) {
      //return (bytes / kilobyte).toFixed(2) + ' KB';
      return Math.floor(bytes / kilobyte) + ' KB';
    } else {
      //return (bytes / megabyte).toFixed(2) + ' MB';
      return Math.floor(bytes / kilobyte) + ' KB';
    }
}


function getFileIcon(fileType) {
    const FILE_ICONS 	=	{
		"image/png": faImage,
		"image/jpeg": faImage,
		"image/jpg": faImage,
		"application/pdf": faFilePdf,
		"text/plain": faFileText
	}

    if(FILE_ICONS[fileType] != undefined) {
        return FILE_ICONS[fileType];
    } else {
        return faFileAlt;
    }
}


function AcceptedFileList({ index, uploadedFiles, fileUploadProgress, cancelUpload, uploadedFileSize }) {

    //console.log('fileUploadProgress', uploadedFileSize);

    const handleCancel = (event) => {
        event.preventDefault();
        //console.log(index);
        cancelUpload(index);
    }

    return(
        <div id="AcceptedFiles" className="my-2">
            {
                uploadedFiles.map((file, i) => {

                    var fileStatus  =   true;

                    return(
                        <React.Fragment key={i}>
                            <div className="row">
                                <div className="col-2">
                                    <FontAwesomeIcon
                                        icon={getFileIcon(file.type)}
                                        size="3x"
                                    />
                                </div>
                                <div className="col-9">
                                    <div className="row">
                                        <div className="col-12">
                                            <div className="row">
                                                <div className="col-11 fs-bold">
                                                    {file.path}
                                                </div>
                                                <div className="col-1 fs-bold">
                                                    <a href="" id={index} onClick={handleCancel}>
                                                        <Cross />
                                                    </a>        
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-12">
                                            {
                                                (
                                                    fileUploadProgress
                                                    &&
                                                    fileUploadProgress > 0
                                                    /* &&
                                                    fileUploadProgress < 100 */
                                                )
                                                ?
                                                <div className="progress">
                                                    <div className="progress-bar" role="progressbar" style={{ width: fileUploadProgress+"%" }} aria-valuenow={fileUploadProgress} aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                                :
                                                <div className="progress">
                                                    <div className="progress-bar" role="progressbar" style={{ width: "0%" }} aria-valuenow={0} aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                            }
                                        </div>
                                        <div className="col-12">
                                            <div className="row">
                                                <div className="col-6 text-left fs-bold">
                                                    {
                                                        "Done: "+fileUploadProgress+"%"
                                                    }
                                                </div>
                                                <div className="col-6 text-right fs-bold">
                                                    {
                                                        (
                                                            uploadedFileSize
                                                            &&
                                                            uploadedFileSize > file.size
                                                        )
                                                        ? bytesToSize(file.size)
                                                        : bytesToSize(uploadedFileSize)
                                                    }
                                                    /
                                                    {
                                                        bytesToSize(file.size)
                                                    }
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </React.Fragment>
                    )
                })
            }
        </div>
    )
}

function RejectedFileList({ index, resetRejectedFiles, cancelUpload, rejectedFiles }) {

    const handleCancel = (event) => {
        event.preventDefault();
        resetRejectedFiles(event.target.id);
    }

    return(
        <div id="RejectedFiles" className="my-2">
            {
                rejectedFiles.map((resObj, i) => {
                    return(
                        <React.Fragment key={i}>
                            <div className="row">
                                <div className="col-2">
                                    <FontAwesomeIcon
                                        icon={getFileIcon(resObj["file"].type)}
                                        size="3x"
                                    />
                                </div>
                                <div className="col-10 text-danger">
                                    {
                                        resObj["file"]["path"]
                                        +
                                        '--'
                                        +
                                        resObj["errors"][0]["message"]
                                    }
                                </div>
                            </div>
                        </React.Fragment>
                    )
                })
            }
        </div>
    )
}


function Moment(props) {

    const dispatch      =   useDispatch();
    const navigate      =   useNavigate();
    const location      =   useLocation();
    const { user_id }   =   useParams();

    const tagifyRef     =   useRef();
    const filesRef      =   useRef();

    const progress      =   useRef([]);
    const fileSize      =   useRef([]);
    const reqTokens     =   useRef([]);
    const resFileNames  =   useRef([]);
    const selectedFiles =   useRef([]);

    const [uploadedFiles, setUploadedFiles]             =   useState([]);
    const [rejectedFiles, setRejectedFiles]             =   useState([]);
    const [uploadedFileNames, setUploadedFileNames]     =   useState([]);
    const [fileUploadProgress, setFileUploadProgress]   =   useState([]);
    const [cancelTokens, setCancelTokens]               =   useState([]);
    const [uploadFileStatus, setUploadFileStatus]       =   useState([]);
    const [uploadedFileSize, setUploadedFileSize]       =   useState([]);

    const [dropzoneStatus, setDropzoneStatus]           =   useState(false);

    const globalState   =   useSelector(state => state.global);

    const [tagifyProps, setTagifyProps] =   useState({});
    

    /* useEffect(() => {

        uploadFilesToServer();

    }, [uploadedFiles]); */

    const baseTagifySettings = {
        blacklist: ["xxx", "yyy", "zzz"],
        maxTags: 15,
        //backspace: "edit",
        placeholder: "Enter Tags",
        dropdown: {
            enabled: 0 // always show suggestions dropdown
        },
        trim: true
    }
    const settings = {
        ...baseTagifySettings
    }

    var defaultValues =   {
        title: "",
        comment: "",
        tags: [],
        status: 1
    }

    const { register, handleSubmit, watch, getValues, control, setValue, reset, formState: { errors } } = useForm({ defaultValues: defaultValues, resolver: yupResolver(MomentSchema) });

    function updateFileUploadStatus(i, msg) {
        const tempUploadFileStatus  =   [...uploadFileStatus];
        tempUploadFileStatus[i]     =   msg;
        setUploadFileStatus(tempUploadFileStatus);

        selectedFiles.current[i]   =   null;
        setUploadedFiles([...selectedFiles.current]);
        /* const tempUploadedFiles =   [...uploadedFiles];
        tempUploadedFiles[i]    =   null;
        setUploadedFiles(tempUploadedFiles); */
    }

    function updateCancelToken(i, msg) {
        const tempCancelTokens  =   [...cancelTokens];
        tempCancelTokens[i]     =   msg;
        setCancelTokens(tempCancelTokens);
    }

    function updateProgress(i, msg) {
        const tempFileUploadProgress  =   [...fileUploadProgress];
        tempFileUploadProgress[i]     =   msg;
        setUploadFileStatus(tempFileUploadProgress);
    }

    const uploadFilesToServer   =   async() => {

        setDropzoneStatus(true);
        setUploadedFileNames([]);
        setFileUploadProgress([]);
        setCancelTokens([]);
        setUploadFileStatus([]);

        selectedFiles.current   =   [...uploadedFiles];

        progress.current    =   new Array(uploadedFiles.length).fill(0);
        setFileUploadProgress([...progress.current]);
        fileSize.current    =   new Array(uploadedFiles.length).fill(1);
        setUploadedFileSize([...fileSize.current]);
        reqTokens.current   =   new Array(uploadedFiles.length).fill('');
        resFileNames.current    =   new Array(uploadedFiles.length).fill('');;

        const tempUploadFileStatus      =   [];
        const actualFileNames           =   [];

        let fileRes = await Promise.all(uploadedFiles.map((processFile, i) => {

            return new Promise(async function(resolve, reject) {

                const formData  =   new FormData();
                formData.append('moments_file', processFile);
                const source    =   axios.CancelToken.source();
                reqTokens.current[i]        =   source;
                //updateProgress(i, 1);
                setCancelTokens([...reqTokens.current]);
                actualFileNames[i]  =   processFile["path"];

                try {
                
                    const { data }  =   await axios.post(UPLOAD_MOMENT, formData, {
                        headers: {
                            'Content-Type': `multipart/form-data; boundary=${formData._boundary}`,
                            'Authorization': `Bearer ${(localStorage.getItem("token")? localStorage.getItem("token") : '')}`
                        },
                        onUploadProgress: (progressEvent) => {
                            //console.log("fileUploadProgressfileUploadProgress", progressEvent);
                            const loadedBytes       =   progressEvent.loaded;
                            const progressPercentage = Math.ceil((progressEvent.loaded / progressEvent.total) * 100);
                            progress.current[i]     =   progressPercentage;
                            setFileUploadProgress([...progress.current]);
                            //console.log("loadedBytes", loadedBytes);
                            fileSize.current[i]         =   loadedBytes;
                            setUploadedFileSize([...fileSize.current]);
                            /* updateProgress(i, progress);
                            console.log("fileUploadProgressfileUploadProgress", tempUpdatedProgress, fileUploadProgress); */
                        },
                        cancelToken: source.token,
                    });

                    if(data.status != "success") {
                        tempUploadFileStatus[i]         =   data.message;
                        updateFileUploadStatus(i, data.message);
                        toast.error(data.message, {theme: "colored"});
                        resolve(true);
                    } else if(data.filename) {
                        console.log(data)
                        resFileNames.current[i]         =   data.filename;
                        setUploadedFileNames([...resFileNames.current]);
                        resolve(true);
                    }

                } catch (error) {
                    if(axios.isCancel(error)) {
                        //console.log(`File ${actualFileNames[i]} upload canceled`);
                        tempUploadFileStatus[i]         =   `File ${actualFileNames[i]} upload canceled`;
                        updateFileUploadStatus(i, `File ${actualFileNames[i]} upload canceled`);
                        resolve(true);
                    } else {
                        //console.log(`File ${actualFileNames[i]} upload error`, error);
                        tempUploadFileStatus[i]         =   `File ${actualFileNames[i]} upload canceled`;
                        updateFileUploadStatus(i, `File ${actualFileNames[i]} upload canceled`);
                        resolve(true);
                    }
                }
            });
        }));

        console.log("All Completed", resFileNames.current);
        setUploadedFileNames([...resFileNames.current]);
        setUploadFileStatus(tempUploadFileStatus);
        setDropzoneStatus(false);
    }

    const cancelUpload = (index) => {
        if(cancelTokens[index]) {
            const msg = (uploadedFiles[index] != undefined && uploadedFiles[index] != null && uploadedFiles[index]["path"] != undefined) ? uploadedFiles[index]["path"] : ''
            cancelTokens[index].cancel(`File ${msg} upload canceled by user`);
        }

        //console.log("index", index, uploadedFiles);
        
        /* const tempUploadedFiles     =   [...selectedFiles.current];
        tempUploadedFiles[index]    =   null; */
        selectedFiles.current[index]    =   null;
        setUploadedFiles([...selectedFiles.current]);
    };

    const cancelAllTokens   =   () => {

        /* setUploadedFileNames([]);
        setFileUploadProgress([]);
        setCancelTokens([]);
        setUploadFileStatus([]); */

        if(cancelTokens) {
            cancelTokens.map((tok, i) => {
                console.log("Cancel all Tokens");
                tok.cancel(`User Cancelled`);
            });
        }
    }

    const resetRejectedFiles = (event) => {
        event.preventDefault();
        setRejectedFiles([]);
    }

    const onSubmit = (formData) => {

        let serverFileNames =   [];        

        for(var k = 0; k < uploadedFiles.length; k++) {

            if(uploadedFiles[k] != null && uploadedFileNames[k] != undefined && uploadedFileNames[k] != '') {
                serverFileNames.push(uploadedFileNames[k]);
            }

        }

        console.log("uploadedFiles", uploadedFileNames, serverFileNames)

        if(serverFileNames.length == 0) {
            toast.error("Please upload file.", {theme: "colored"});
            return false;
        }

        const momentData  =   { ...formData, filenames: serverFileNames};

        dispatch(newMoment(momentData))
            .unwrap()
            .then(response => {

                //console.log("login", response);

                if(response?.status != "success") {
                    toast.error(response?.message, {theme: "colored"});
                    return false;
                }
                toast.success(response?.message, {theme: "colored"});

                reset({
                    ...defaultValues
                });

                tagifyRef.current.removeAllTags();

                setUploadedFileNames([]);
                setFileUploadProgress([]);
                setCancelTokens([]);
                setUploadFileStatus([]);
                setFileUploadProgress([]);

                selectedFiles.current   =   [];
                setUploadedFiles([]);
                setRejectedFiles([]);

                progress.current    =   [];
                fileSize.current    =   [];

            })
            .catch(e => {
                //console.log('Login error find', e.message);
                toast.error(e.message, {theme: "colored"});
            });
    }

    const tagOnChange = useCallback(e => {
        setValue("tags", e.detail.tagify.getCleanValue().map(t => t.value))
    }, [])

    return (
        <Suspense fallback={<Loader />}>
            <section id="login" className="login p-4">

                <h1 className="text-dark fw-bold">
                    Add New Moment
                </h1>

                <form onSubmit={handleSubmit(onSubmit)} className="was-validated">

                    <div className="mb-3 mt-3">
                        <label htmlFor="title" className="form-label">Title</label>
                        <input className="form-control" type="text" name="title" placeholder="Enter Title" id="title" {...register("title")} />
                        <div className="text-danger">{errors.title?.message}</div>
                    </div>

                    <div className="mb-3 mt-3">
                        <label htmlFor="comment">Comment</label>
                        <textarea className="form-control" name="comment" id="comment" maxLength={100} {...register("comment", { required: true, maxLength: 100 })}></textarea>
                        <div className="text-danger">{errors?.comment?.message}</div>
                    </div>

                    <div className="row">
                        <div className="col-12 col-lg-6">
                            <div className="row">
                                <div className="col-12">
                                    <div className="my-2">
                                        <p>
                                            Tags
                                        </p>
                                        <Controller
                                            control={control}
                                            name="mobile_number"
                                            id="mobile_number"
                                            render={({ field: { onChange, onBlur, value, ref } }) => (
                                                <React.Fragment>
                                                    <Tags
                                                        className='tag-max-width'
                                                        tagifyRef={tagifyRef} // optional Ref object for the Tagify instance itself, to get access to  inner-methods
                                                        settings={settings}  // tagify settings object
                                                        defaultValue={value}
                                                        {...tagifyProps}   // dynamic props such as "loading", "showDropdown:'abc'", "value"
                                                        onChange={tagOnChange}
                                                    />                
                                                    <div className="text-danger">{errors.tags?.message}</div>
                                                </React.Fragment>
                                            )}
                                        />
                                    </div>
                                </div>
                            </div>
                            <div className="row mt-2">
                                <div className="col-12 border" style={{ minHeight: 'calc(1.5em + 0.75rem + 250px)' }}>
                                    <p className="fs-bold">
                                        Uploading
                                    </p>
                                    {
                                        uploadedFiles.length > 0
                                        &&
                                        <React.Fragment>
                                            {
                                                uploadedFiles.map((files, i) => {
                                                    //console.log("One upload", fileUploadProgress);
                                                    if(uploadFileStatus.length == 0 && uploadFileStatus[i] != undefined && uploadFileStatus[i] != '') {

                                                    } else if(files != null) {
                                                        //console.log("Two upload", fileUploadProgress);
                                                        return(
                                                            <AcceptedFileList key={i} index={i} uploadedFiles={[files]} cancelUpload={cancelUpload} cancelTokens={cancelTokens} fileUploadProgress={fileUploadProgress[i]} uploadedFileSize={uploadedFileSize[i]} />
                                                        )
                                                    }
                                                })
                                            }
                                        </React.Fragment>
                                    }
                                </div>
                                <div className="col-12 mt-3">
                                    {
                                        rejectedFiles.length > 0
                                        &&
                                        <React.Fragment>
                                            <p className="fs-bold fs-1">
                                                Rejected Files
                                            </p>
                                            <div className="row">
                                                <div className="col-12 text-right">
                                                    <a href="" className="btn btn-sm btn-info" onClick={resetRejectedFiles}>
                                                        Clear Errors
                                                    </a>
                                                </div>
                                            </div>
                                            {
                                                rejectedFiles.map((rejObj,i) => {
                                                    return(
                                                        <React.Fragment key={i}>
                                                            <RejectedFileList resetRejectedFiles={resetRejectedFiles} index={i} rejectedFiles={[rejObj]} cancelUpload={cancelUpload} />
                                                        </React.Fragment>
                                                    )
                                                })
                                                
                                            }
                                        </React.Fragment>
                                        
                                    }
                                </div>
                            </div>
                        </div>
                        <div className="col-12 col-lg-6">
                            <div className="p-5">
                                <MomentFileUpload
                                    ref={filesRef}
                                    setUploadedFiles={setUploadedFiles}
                                    setRejectedFiles={setRejectedFiles}
                                    uploadFilesToServer={uploadFilesToServer}
                                    cancelAllTokens={cancelAllTokens}
                                    isDragable={false}
                                    isMultipleFileUpload={true}
                                    maxFileSize={10 * 1024 * 1024}
                                    maxFiles={3}
                                    fileTypes={{
                                        'image/jpg': [],
                                        'image/jpeg': [],
                                        'image/png': []
                                    }}
                                    dropzoneStatus={dropzoneStatus}
                                />
                            </div>
                        </div>
                    </div>

                    <div className="text-center mt-4">
                        <button type="submit" className="btn btn-md btn-dark btn-radius fw-bold" id="submit" name="submit">Submit</button>
                    </div>
                </form>
            </section>
        </Suspense>
    );
}

export default Moment;