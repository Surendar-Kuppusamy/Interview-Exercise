import React, { Suspense, useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Controller, useForm } from "react-hook-form";
import { useParams, useLocation, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEye, faEyeSlash } from '@fortawesome/free-solid-svg-icons';
import 'react-phone-number-input/style.css'
import PhoneInput, { isValidPhoneNumber } from 'react-phone-number-input'
import { yupResolver } from "@hookform/resolvers/yup";
import Loader from '../../components/Loader';
import { UserSchema } from '../../utils/ValidationSchemas';
import { signupUser } from '../../slices/globalSlice';

function User(props) {

    const dispatch      =   useDispatch();
    const navigate      =   useNavigate();
    const location      =   useLocation();
    const { user_id }   =   useParams();

    const globalState   =   useSelector(state => state.global);

    const [passwordType, setPasswordType]   =   useState("password");

    var defaultValues =   {
        first_name: "",
        last_name: "",
        email: "",
        password: "",
        mobile_number: "",
        country: "",
        profile: "",
        status: 1
    }

    const { register, handleSubmit, watch, trigger, control, setValue, reset, formState: { errors } } = useForm({ defaultValues: defaultValues, resolver: yupResolver(UserSchema) });

    const onSubmit = (userInfo) => {

        dispatch(signupUser(userInfo))
            .unwrap()
            .then(response => {

                console.log("login", response);

                if(response?.status != "success") {
                    toast.error(response?.message, {theme: "colored"});
                    return false;
                }

                if(!user_id) {
                    reset({
                        ...defaultValues
                    });
                }

                toast.success(response?.message, {theme: "colored"});

                navigate("/moment");

            })
            .catch(e => {
                console.log('Login error find', e.message);
                toast.error(e.message, {theme: "colored"});
            });
    }

    function handlePasswordType(event) {
        setPasswordType((passwordType == 'password') ? 'text' : 'password');
    }

    return (
        <Suspense fallback={<Loader />}>
            <section id="login" className="login p-4">

                <h1 className="text-dark text-center fw-bold">
                    Sign Up
                </h1>

                <form onSubmit={handleSubmit(onSubmit)} className="was-validated">

                    <div className="row">

                        <div className='col-12 col-lg-6'>
                            <div className="mb-3 mt-3">
                                <label htmlFor="first_name" className="form-label">Last Name</label>
                                <input className="form-control" type="text" name="first_name" placeholder="Enter First Name" id="first_name" {...register("first_name")} />
                                <div className="text-danger">{errors.first_name?.message}</div>
                            </div>
                        </div>

                        <div className='col-12 col-lg-6'>
                            <div className="mb-3 mt-3">
                                <label htmlFor="last_name" className="form-label">Last Name</label>
                                <input className="form-control" type="text" name="last_name" placeholder="Enter Last Name" id="last_name" {...register("last_name")} />
                                <div className="text-danger">{errors.last_name?.message}</div>
                            </div>
                        </div>

                    </div>

                    <div className="row">

                        <div className='col-12 col-lg-6'>
                            <div className="mb-3 mt-2">
                                <p>
                                    Mobile Number
                                </p>
                                <Controller
                                    control={control}
                                    name="mobile_number"
                                    id="mobile_number"
                                    render={({ field: { onChange, onBlur, value, ref } }) => (
                                        <React.Fragment>
                                            <PhoneInput
                                                className="phone-number"
                                                style={{ minHeight: 'calc(1.5em + 0.75rem + 0px)' }}
                                                defaultCountry="IN"
                                                placeholder="Enter phone number"
                                                value={value}
                                                onChange={onChange}
                                                international={true}
                                                limitMaxLength={true}
                                                error={value ? (isValidPhoneNumber(value) ? undefined : 'Invalid phone number') : 'Phone number required'}
                                                
                                            />
                                            <div className="text-danger">{errors.mobile_number?.message}</div>
                                        </React.Fragment>
                                    )}
                                />
                            </div>
                        </div>

                        <div className='col-12 col-lg-6'>
                            <div className="mb-3 mt-3">
                                <label htmlFor="email" className="form-label">Email</label>
                                <input className="form-control" type="text" name="email" id="email" placeholder="Enter Email" {...register("email")} />
                                <div className="text-danger">{errors.email?.message}</div>
                            </div>
                        </div>

                    </div>

                    <div className="row">

                        <div className='col-12 col-lg-6'>
                            <div className="mb-3 mt-3">
                                <label htmlFor="country" className="form-label">Country</label>
                                <input className="form-control" type="text" name="country" placeholder="Enter Country" id="country" {...register("country")} />
                                <div className="text-danger">{errors.country?.message}</div>
                            </div>
                        </div>

                        <div className='col-12 col-lg-6'>
                            <label htmlFor="password" className="form-label">Password</label>
                            <div className="input-group mb-3 mt-3">
                                <input className="form-control" type={passwordType} name="password" id="password" placeholder="Enter Password" {...register("password")} aria-label="Password" aria-describedby="password-type" />
                                <span className="input-group-text pointer" id="password-type" onClick={handlePasswordType}>
                                    {
                                        passwordType == 'text'
                                        ?
                                        <FontAwesomeIcon icon={faEyeSlash} />
                                        :
                                        <FontAwesomeIcon icon={faEye} />
                                    }
                                </span>
                            </div>
                            <div className="text-danger">{errors.password?.message}</div>
                        </div>

                    </div>

                    <div className="text-center mt-4">
                        <button type="submit" className="btn btn-md btn-dark btn-radius fw-bold" id="submit" name="submit">Submit</button>
                    </div>
                </form>
            </section>
        </Suspense>
    );
}

export default User;