import React, { Suspense, useEffect, useState } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import Loader from '../../components/Loader';
import { logoutUser } from '../../slices/globalSlice';

function LogoutUser(props) {

    const navigate      =   useNavigate();
    const globalState   =   useSelector(state => state.global);
    const dispatch      =   useDispatch();

    //navigate(globalState.root_path+'/login');

    useEffect(() => {
        dispatch(logoutUser(globalState))
        .unwrap()
        .then(response => {
            navigate('/');
        })
        .catch(e => {
            navigate('/');
        });
    }, [0]);

    

    return (
        <Suspense fallback={<Loader />}>
            <section id="logout" className="logout">
                Logout
            </section>
        </Suspense>
    );
}

export default LogoutUser;