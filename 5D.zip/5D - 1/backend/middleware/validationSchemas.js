import mongoose from 'mongoose';
import validator from 'express-validator';
import Users from '../models/UserModel.js';
import Moments from '../models/MomentModel.js';


const { validationResult, checkSchema } = validator;

export const customValidationResult = validationResult.withDefaults({
    formatter: error => {
        return {
            status: 'error',
            message: error.msg,
            params:error.param
        };
    },
});

export const userValidationSchema = {
    first_name: {
        trim: true,
        notEmpty: {
            errorMessage: "First Name is required."
        },
        isLength: {
            options: {
                min: 3,
                max: 60
            },
            errorMessage: "First name characters must be greater or equal to 3 and less or equal to 60"
        }
    },
    last_name: {
        trim: true,
        notEmpty: {
            errorMessage: "Last Name is required."
        },
        isLength: {
            options: {
                min: 3,
                max: 60
            },
            errorMessage: "Last name characters must be greater or equal to 3 and less or equal to 60"
        }
    },
    email: {
        trim: true,
        notEmpty: {
            errorMessage: "Email is required."
        },
        isEmail: {
            errorMessage: "Invalid email address."
        },
        custom: {
            options: (value, { req, location, path }) => {

                return Users.find({
                    email: value
                }).then(user => {
                    if (user.length > 0) {
                        return Promise.reject('Email address already taken')
                    } else {
                        return Promise.resolve(true);
                    }
                });

            }
        }
    },
    password: {
        trim: true,
        notEmpty: {
            errorMessage: "Password is required."
        },
        isLength: {
            options: {
                min: 6,
                max: 50
            },
            errorMessage: "Password characters must be greater then 6 and less then 50"
        }
    },
    mobile_number: {
        trim: true,
        //toInt: true,
        /* customSanitizer: {
            options: (value, { req, location, path }) => {
                let sanitizedValue;
                sanitizedValue = parseInt(value);
                return sanitizedValue;
            }
        }, */
        /* isNumeric: {
            errorMessage: "Mobile number should be numeric."
        }, */
        /* isLength: {
            options: {
                min: 10
            },
            errorMessage: "Mobile number should be 10 digits."
        },
        isLength: {
            options: {
                max: 10
            },
            errorMessage: "Mobile number should be 10 digits."
        } */
    },
    country: {
        trim: true,
        notEmpty: {
            errorMessage: "Country is required."
        },
        isLength: {
            options: { min: 0, max: 200 },
            errorMessage: 'Country should be at least 200 characters.'
        }
    }
}

export const userupdateValidationSchema = {
    ...userValidationSchema,
    id: {
        notEmpty: {
            errorMessage: "ID required."
        },
        custom: {
            options: (value, { req, location, path }) => {

                return Users.findById(value).then(user => {
                    if(user._id != undefined && user._id != null && user._id != '') {
                        return Promise.resolve(true);
                    } else {
                        return Promise.reject('Invalid user ID.');
                    }
                });
                
            }
        }
    },
    email: {
        trim: true,
        notEmpty: {
            errorMessage: "Email is required."
        },
        isEmail: {
            errorMessage: "Invalid email address."
        },
        custom: {
            options: (value, { req, location, path }) => {

                return Users.find({
                    email: value,
                    _id: { $ne: req.body.id }
                }).then(user => {
                    if (user.length > 0) {
                        return Promise.reject('Email address already taken')
                    } else {
                        return Promise.resolve(true);
                    }
                });

            }
        }
    }
}


export const momentValidationSchema = {
    title: {
        trim: true,
        notEmpty: {
            errorMessage: "Title is required."
        },
        isLength: {
            options: {
                min: 3,
                max: 100
            },
            errorMessage: "Title characters must be greater or equal to 3 and less or equal to 100"
        }
    },
    comment: {
        trim: true,
        isLength: {
            options: {
                max: 100
            },
            errorMessage: "Comment characters must be less than or equal to 100"
        }
    },
    tags: {
        custom: {
            options: (value, { req, location, path }) => {

                if(value.length > 0) {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Minimum one tag is required.')
                }
            }
        }
    },
    filenames: {
        custom: {
            options: (value, { req, location, path }) => {

                if(value.length > 0) {
                    return Promise.resolve(true);
                } else {
                    return Promise.reject('Minimum one file is need to upload.')
                }
            }
        }
    }
}