import asyncHandler from 'express-async-handler';
import validator from 'express-validator';
import Users from '../models/UserModel.js';
import Moments from '../models/MomentModel.js';
import { generateToken, getUserId } from '../middleware/authMiddleware.js';
import { customValidationResult, userValidationSchema, momentValidationSchema } from '../middleware/validationSchemas.js';
import { jsonResponse, checkFileError, deleteFile } from '../utils/CommonFunction.js';

export const signup = asyncHandler(async(req, res, next) => {

	const userDetails	=	req.body;

	const user = await Users.create(userDetails);
	if(user) {
		res.status(201).json({
			status: 'success',
			message: 'User created.',
			user: user,
			token: generateToken(user._id)
		});
	} else {
		res.status(500);
		throw new Error('Something went wrong.');
	}
});

export const addMoments = asyncHandler(async function (req, res) {

	const userID 		=	await getUserId(req);
	const momentDetails	=	{ ...req.body, user_id: userID };

	const moment = await Moments.create(momentDetails);

	if(moment) {
		res.status(201).json({
			status: 'success',
			message: 'Moment created.',
			moment: moment
		});
	} else {
		res.status(500);
		throw new Error('Something went wrong.');
	}
});

export const momentUnlinks = asyncHandler(async function (req, res) {

	const filenames	=	req.body.filenames;
	const userID	=	await getUserId(req);

	console.log(req.body);

	var fileRes = await Promise.all(filenames.map((file, index) => {
		return new Promise(async function(resolve, reject) {
			const deleteStatus	=	await deleteFile(process.env.MOMENT_PATH+'/'+userID+'/'+file);
		})
	}));

	return res.status(201).json({
		status: 'success',
		message: 'Deleted successfully.',
		status: fileRes
	});

});


export const processMoments = asyncHandler(async function (req, res, err, next) {

	const { checkSchema } 	=	validator;
	let momentDetails 		=	{ ...req.body };
	const date 				= 	new Date();
	const userID 			=	await getUserId(req);

	const result 				=	await checkSchema(momentValidationSchema, ["body"]).run(req);
	const validationResultError	=	customValidationResult(req).array();

	if(validationResultError.length > 0) {
        console.log('Validation-Error===>'+JSON.stringify(validationResultError));
		return res.status(200).json(validationResultError[0]);
    }

	const resFiles	=	(req.files != undefined && req.files != null && Object.keys(req.files).length != 0
	) ? req.files : { "moments_file": [] };

    const errorStatus   =   await checkFileError(err);

    if(errorStatus['status']) {
        return jsonResponse(res, 200, 'error', errorStatus['message']);
    }

	var fileRes = await Promise.all(resFiles['moments_file'].map((file, index) => {
		return new Promise(async function(resolve, reject) {
			const filePath			=	process.env.MOMENT_PATH+'/'+userID+'/';
			const getName 			=	await getFileName();
			const fileName			=	`${getName}${path.extname(file.originalname)}`;
			const fileUploadStatus 	=   await generalFileUpload(file, filePath, fileName);
			if(fileUploadStatus && fileName) {
				return fileName;
			}
		})
	}));

	if(fileRes.length != resFiles['moments_file'].length) {
		return jsonResponse(res, 200, 'success', 'File upload failed.');
	}

	momentDetails["files"]	=	fileRes;
	momentDetails["tags"]	=	momentDetails["tags"].map((tag, i) => { if(tag) return tag.trim() });
	momentDetails["status"]	=	1;

	const moment = await Users.create(momentDetails);
	if(moment) {
		res.status(201).json({
			status: 'success',
			message: 'Moment created.',
			user: user
		});
	} else {
		res.status(500);
		throw new Error('Something went wrong');
	}
});