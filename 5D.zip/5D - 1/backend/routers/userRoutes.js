import express from "express";
import validator from 'express-validator';
import multer from 'multer';
import path from 'path';
import { signup, processMoments, addMoments, momentUnlinks } from '../controllers/userController.js';
import { userValidationSchema, momentValidationSchema } from '../middleware/validationSchemas.js';
import { checkValidation, getUserId, verifyToken } from '../middleware/authMiddleware.js';
import { checkFileError, createFileDirectory, jsonResponse } from "../utils/CommonFunction.js";

const { checkSchema } = validator;

const router = express.Router();

const storage = multer.diskStorage({
    destination: async(req, file, cb) => {

		const user_id 		= 	await getUserId(req);
		const filepath 		=	process.env.MOMENT_PATH+'/'+user_id+'/';
		const dirStatus 	=	await createFileDirectory(filepath);
		console.log("filepath", filepath, dirStatus);

		if(dirStatus == true) {
			cb(null, filepath);
		} else {
			cb(dirStatus, filepath);
		}
    },
    filename: (req, file, cb) => {
		let mediaName       =   Date.now();
        let randomNumber    =   Math.floor(Math.random() * 899999 + 100000);
        randomNumber        =   randomNumber.toString().substring(0, 2);
        randomNumber        =   parseInt(randomNumber);
        mediaName           =   randomNumber+'_'+mediaName;
		const fileName 		=	`${mediaName}${path.extname(file.originalname)}`;
        cb(null, fileName);
    }
});

//const momentsUpload	=	multer({ dest: process.env.MOMENT_PATH });

const uploadMoment = multer({
	//storage: multer.memoryStorage(),
	storage: storage,
	limits: {
        fileSize: 1024 * 1024 * 10	//10 MB
    },
	fileFilter: function (req, file, cb) {
		const supportingFiles 	=	["image/png", "image/jpeg", "image/jpg"];
		if(supportingFiles.includes(file.mimetype)) {
            cb(null, true);
        } else {
            return cb(new Error('File not supported.'));
        }
	}
});

router.route('/signup').post(checkSchema(userValidationSchema, ['body', 'query']), checkValidation, signup);
router.route('/add/moment').post(verifyToken, checkSchema(momentValidationSchema, ['body', 'query']), checkValidation, addMoments);
router.route('/moment/unlink').post(verifyToken, checkValidation, momentUnlinks);

router.route('/upload/moments').post(verifyToken, uploadMoment.single('moments_file'), async(req, res, err) => {
    res.status(201).json({
		status: 'success',
		message: 'File uploaded.',
		filename: req.file.filename
	});
});


export default router;