import expressAsyncHandler from 'express-async-handler';
import fs from 'fs';
import path from 'path';
import multer from 'multer';


export const createFileDirectory = (path) => {
    return new Promise(async(resolve, reject) => {
        try {
            //console.log("Start Path", path);
            fs.access(path, (error) => { 
                //console.log("Errror Object", error);
                if(error) { 
                    fs.mkdir(path, { recursive: true }, (error) => { 
                        if(error) {
                            console.log("Can't create directory..");
                            resolve(false);
                        } else { 
                            console.log("New Directory created successfully !!"); 
                            resolve(true);
                        }
                    }); 
                } else {
                    console.log("Given Directory already exists !!");
                    resolve(true);
                } 
            });
        } catch (error) {
            console.log("Error Object!!", error);
            resolve(false);
        }
    });
};

export const deleteFile = expressAsyncHandler(async(filePath) => {
    return new Promise(async(resolve, reject) => {
        try {
            await fs.unlink(filePath, error => {
                console.log(error);
                reject(error);
            });
            console.log(`File "${filePath}" has been deleted.`);
            resolve(true)
        } catch (error) {
            console.error(`Error deleting "${filePath}": ${error}`);
            resolve(`Error deleting "${filePath}": ${error}`);
        }
    });
});

export const generalFileUpload = expressAsyncHandler(async(file, filePath, fileName) => {
    return new Promise(async function(resolve, reject) {
        try {
            const createPath    =   await createFileDirectory(filePath);
            fs.writeFile(filePath+fileName, file.buffer);
            resolve(true);
            console.log("Success");
        } catch(e) {
            console.log('Catch error in common function generalFileUpload()', e);
            resolve(false);
            //throw new Error(`Error writing to "${filePath}": ${e}`);
        }
    });
});

export const getFileName = expressAsyncHandler(async(next) => {
    return new Promise((resolve, reject) => {
        let mediaName       =   Date.now();
        let randomNumber    =   Math.floor(Math.random() * 899999 + 100000);
        randomNumber        =   randomNumber.toString().substring(0, 2);
        randomNumber        =   parseInt(randomNumber);
        mediaName           =   randomNumber+'_'+mediaName;
        resolve(mediaName);
    });
});


export const jsonResponse = expressAsyncHandler(async(res, statusCode, status, message, data) => {
    try {
        if(data) {
            res.status(statusCode).json({
                status: status,
                message: message,
                data: data
            });
        } else {
            res.status(statusCode).json({
                status: status,
                message: message
            });
        }
    } catch(e) {
        console.log('Catch error in common function jsonResponse()', e);
        throw new Error(e.message);
    }
});

export const checkFileError = (err) => {
    return new Promise((resolve, reject) => {
        if(err instanceof multer.MulterError) {
            if(err.code == "LIMIT_UNEXPECTED_FILE") {
                return resolve({ status: true, message: 'Invalid field name.' });
            } else if(err.code == "LIMIT_FILE_COUNT") {
                return resolve({ status: true, message: 'Too many files uploaded.' });
            } else {
                return resolve({ status: true, message: err.message });
            }
        } else if (err) {
            return resolve({ status: true, message: err.message });
        } else {
            return resolve({ status: false, message: '' });
        }
    });
};