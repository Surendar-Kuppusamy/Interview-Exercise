import express from 'express';
import bodyParser from 'body-parser';
import multer from 'multer';
import fileupload from 'express-fileupload';
import path from 'path';
import dotenv from 'dotenv';
import cors from 'cors';
import connectDB from './config/db.js';
import { notFound, errorHandler } from './middleware/errorMiddleware.js';
import userRoutes from './routers/userRoutes.js';

dotenv.config({path: './.env'});

const app = express();

app.use(cors());

const __dirname = path.resolve();
app.use('/public', express.static(path.join(__dirname, '/public')));

connectDB();

var forms = multer();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
//app.use(forms.array());
/* app.use(fileupload());
app.use(express.urlencoded({ extended: true })); */


app.get('/',(req,res) => {
	res.send('D5 Demo app ...');
});

app.use('/api/user', userRoutes);

app.use(notFound);
app.use(errorHandler);

app.listen(process.env.PORT,() => {
	console.log(`Running on PORT ${process.env.PORT}`);
});


