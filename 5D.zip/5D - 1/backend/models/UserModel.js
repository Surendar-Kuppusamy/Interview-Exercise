import mongoose from 'mongoose';

var Schema = mongoose.Schema;

const UserSchema = new Schema({
    first_name:  {
        type: String,
        trim: true,
        required: [true, 'First Name required.'],
        minLength: [3, 'First Name must have minimum 3 characters.'],
        maxLength: [60, 'Maximum character for first name should be 60 characters.']
    },
    last_name:  {
        type: String,
        trim: true,
        required: [true, 'Last Name required.'],
        minLength: [3, 'Last Name must have minimum 3 characters.'],
        maxLength: [60, 'Maximum character for last name should be 60 characters.']
    },
    email:  {
        type: String,
        trim: true,
        unique: true,
        required: [true, 'Email required.'],
        validate: {
            validator: function(value) {
                return new Promise((resolve, reject) => {
                    const email_pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    resolve(email_pattern.test(value));
                });
            },
            message: props => `${props.value} is not a valid emial!`
        }
    },
    password:  {
        type: String,
        trim: true,
        required: [true, 'Password required.']
    },
    mobile_number:  {
        type: Number,
        trim: true
    },
    country: {
        type: String,
        trim: true,
        required: [true, 'Country is required.']
    },
	profile: {
        type: String,
        trim: true
    },
    status: {        //status (1 - active, 2 - disabled, 3 - Deleted)
        type: Number,
        required: [true, 'Status required.'],
        enum: {
            values: [1, 2],
            message: '{VALUE} is invalid status.'
        }
    }
},
{
    timestamps: true, // Enable timestamps
})

const Users = mongoose.model("Users", UserSchema);
export default Users;