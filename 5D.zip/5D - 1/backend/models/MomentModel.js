import mongoose from 'mongoose';

var Schema = mongoose.Schema;

const MomentSchema = new Schema({
    user_id: {
        type: 'ObjectId',
        ref: 'Users'
    },
    title:  {
        type: String,
        trim: true,
        required: [true, 'Title required...'],
        minLength: [3, 'Title must have minimum 3 characters.'],
        maxLength: [100, 'Maximum character for title should be 100 characters.']
    },
    comment:  {
        type: String,
        trim: true,
        /* required: [true, 'Comment required...'],
        minLength: [3, 'Comment must have minimum 3 characters.'], */
        maxLength: [100, 'Maximum character for Comment should be 100 characters.']
    },
    tags:  {
        type: [String],
        /* validate: {
            validator: function (value) {
              return value.length > 0;
            },
            message: 'Minimum one tag is required.',
        } */
    },
    filenames:  {
        type: [String],
        /* validate: {
            validator: function (value) {
              return value.length > 0;
            },
            message: 'Minimum one file is required.',
        } */
    },
    status: {        //status (1 - active, 2 - disabled, 3 - Deleted)
        type: Number,
        required: [true, 'Status required.'],
        enum: {
            values: [1, 2, 3],
            message: '{VALUE} is invalid status.'
        }
    }
},
{
    timestamps: true, // Enable timestamps
})

const Moments = mongoose.model("Moments", MomentSchema);
export default Moments;