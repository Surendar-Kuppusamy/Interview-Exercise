import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { useLocation } from "react-router-dom";
import Loader from '../components/Loader';
import PageLoader from '../components/PageLoader';

function Container(props) {

    const globalState   =   useSelector(state => state.global);

    return (
        <div className={'layout-content ' + ' '}>
            <div className={"container-fluid"}>
                {
                    (
                        (globalState.page_loader)
                        &&
                        (!globalState.site_loader)
                    )
                    ? <PageLoader />
                    : props.children
                }
                {
                    (
                        globalState?.site_loader
                        ||
                        globalState?.manual_site_loader
                    )
                    &&
                    <Loader />
                }
            </div>
        </div>
    );
}

export default Container;