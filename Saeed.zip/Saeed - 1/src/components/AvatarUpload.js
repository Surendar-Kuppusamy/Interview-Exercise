import React, { useCallback, useEffect, useState, forwardRef, useImperativeHandle } from 'react';
import { useSelector, useDispatch, connect }  from 'react-redux';
import {useDropzone} from 'react-dropzone';
import { toast } from 'react-toastify';

const thumbsContainer = {
    display: 'flex',
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 16
};

const thumb = {
	display: 'inline-flex',
	borderRadius: 2,
	border: '1px solid #eaeaea',
	marginBottom: 8,
	marginRight: 8,
	width: 100,
	height: 100,
	padding: 4,
	boxSizing: 'border-box'
};

const thumbInner = {
	display: 'flex',
	minWidth: 0,
	overflow: 'hidden'
};

const img = {
	display: 'block',
	width: 'auto',
	height: '100%'
};

const title = {
	paddingRight: '20px'
}


function AvatarUpload(props, ref) {

	const userState = useSelector((state) => state.userState);

  	let intialFiles = [];
	
  	const [files, setFiles] = useState(intialFiles);
	const [fileState, setStateFile] = useState(props.fileState);

  	const onDrop = useCallback(async(acceptedFiles) => {
		let tempfile = [];
		//props.clearErrMsg("");
		acceptedFiles.forEach((file) => {
			setFiles(acceptedFiles.map(file => Object.assign(file, { preview: URL.createObjectURL(file) })));
			/* let extension = file["name"].substring(file["name"].lastIndexOf('.') + 1);
			console.log('File', extension); */
			tempfile.push(file);
			setStateFile(tempfile);
			props.setValue(tempfile);
		});
	}, []);

	useImperativeHandle(ref, () => ({
		removeAllFromParent () {
			setFiles([]);
			setStateFile(null);
			props.setValue(null);
		}
	}), []);

	const removeAll = (e) => {
		setFiles([]);
		setStateFile(null);
		props.setValue(null);
	}

	const removeFile = (index) => {
		const newFiles = [...files];
		newFiles.splice(index, 1);

		if(fileState != null) {
			const newFileData = [...fileState];
			newFileData.splice(index, 1);
			props.setValue(newFileData);
		}
		setFiles(newFiles);
	}

  	const {getRootProps, getInputProps, acceptedFiles, fileRejections} = useDropzone({noDrag: props.isDragable, multiple: props.isMultipleFileUpload, maxSize: props.maxFileSize, onDrop, maxFiles:props.maxFiles, accept:props.fileTypes });
	  
  	/* const acceptedFileItems = files.map((file, index) => (
		<div key={file.name}>
			<span className="del-icon" onClick={(e) => removeFile(index)}><i><FontAwesomeIcon icon={faTrashAlt}/></i></span>
			<div style={thumb}>
				<div style={thumbInner}>
					<img
					src={file.preview}
					style={img}
					/>
				</div>
			</div>
		</div>
  	)); */

	useEffect(() => {
		console.log("fileRejections", fileRejections);
		if(fileRejections.length > 0 && fileRejections[0]['errors'] !== undefined && fileRejections[0]['errors'].length > 0 && fileRejections[0]['errors'][0]['message'] !== undefined) {
			toast.error(fileRejections[0]['errors'][0]['message'], { theme: "colored" });
		}
	},[fileRejections]);

  	/* const fileRejectionItems = fileRejections.map(({ file, errors }) => (
		<li key={file.path} className="text-danger">
			{file.path} - {file.size} bytes
			<ul>
				{errors.map(e => (
					<li key={e.code}>{e.message}</li>
				))}
			</ul>
			{console.log(file)}
		</li>
  	)); */

  return (
    <div className="upload-sec mb-3">
		<div>
			<div className="clt-logo prof-icon business-logo close-icon">
				{
					fileRejections.length === 0
					&&
					files.length > 0
					?
					<>
						<span className="btn btn-sm btn-danger" onClick={removeAll}>
							Clear
						</span>
						<img src={files[0].preview} className="round" width={100} height={100} alt="User Logo" />
					</>
					:
					<>
						<div {...getRootProps({className: 'dropzone'})}>
							<span className="btn btn-sm btn-primary">Add Porduct Photo</span>
							<input {...getInputProps()} />
						</div>
					</>
				}
			</div>
		</div>
		{/* <aside>
			{acceptedFileItems.length > 0 && <h6>Accepted Files</h6>}
			<ul>{acceptedFileItems}</ul>
			{fileRejectionItems.length > 0 && <h6>Rejected Files</h6>}
			<ul>{fileRejectionItems}</ul>
			{acceptedFileItems.length > 0 && <button type="button" className="btn btn-sm btn-primary" onClick={removeAll} title="Remove">Remove {props.isMultipleFileUpload && 'All'}</button>}
		</aside> */}
    </div>
  );
}
export default forwardRef(AvatarUpload);
