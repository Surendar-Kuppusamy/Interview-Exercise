import React, { Suspense, useEffect, useState } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { useForm } from "react-hook-form";
import { toast } from 'react-toastify';
import { yupResolver } from "@hookform/resolvers/yup";
import Loader from '../../components/Loader';
import PageLoader from '../../components/PageLoader';
import { UserLoginSchema } from '../../utils/ValidationSchemas';
import { loginUser } from '../../slices/globalSlice';
import { ADMIN_START_ROUTE_PATH, COOKIE_NAME } from '../../utils/GlobalConstants.js';


function Login(props) {

    const dispatch      =   useDispatch();
    const navigate      =   useNavigate();
    const location      =   useLocation();
    const globalState   =   useSelector(state => state.global);

    var type = 2;

    if(location.pathname.startsWith(ADMIN_START_ROUTE_PATH)) {
        type    =   1;
    }

    const defaultValues = {
        email: "",
        password: "",
        type: type
    };

    const { register, handleSubmit, watch, formState: { errors } } = useForm({ defaultValues: defaultValues, resolver: yupResolver(UserLoginSchema) });

    const onSubmit = (formData) => {
        console.log(formData);
        dispatch(loginUser(formData))
            .unwrap()
            .then(response => {

                console.log("login", response);

                if(response?.api?.status != "success") {
                    toast.error(response?.api?.message, {theme: "colored"});
                    return false;
                }

                toast.success("Logged in successfully.", {theme: "colored"});
                navigate(globalState.root_path);
            })
            .catch(e => {
                console.log('Login error find', e.message);
                toast.error(e.message, {theme: "colored"});
            });
    };

    return (
        <Suspense fallback={<Loader />}>
            <section id="login" className="login mx-auto" style={{ width: 400, marginTop: 50 }}>
                <form onSubmit={handleSubmit(onSubmit)} className="was-validated">


                    <div className="mb-3 mt-3">
                        <label htmlFor="email" className="form-label">Email</label>
                        <input className="form-control" type="text" name="email" id="email" placeholder="Enter Email" {...register("email")} />
                        <div className="invalid-feedback">{errors.email?.message}</div>
                    </div>

                    <div className="mb-3 mt-3">
                        <label htmlFor="password" className="form-label">Password</label>
                        <input className="form-control" type="password" name="password" id="password" placeholder="Enter Password" {...register("password")} />
                        <div className="invalid-feedback">{errors.password?.message}</div>
                    </div>

                    <div className="text-center">
                        <button type="submit" className="btn btn-info" id="submit" name="submit">Login</button>
                    </div>
                    <div className="mt-2">
                        <h5>If you not have account first</h5>
                        <div className="mt-2">
                            {
                                !(location.pathname.startsWith(ADMIN_START_ROUTE_PATH))
                                &&
                                <a className="btn btn-md btn-danger" href="/signup">Signup</a>
                            }
                            {
                                (location.pathname.startsWith(ADMIN_START_ROUTE_PATH))
                                &&
                                <a className="btn btn-md btn-danger" href="/admin/create-admin">Signup</a>
                            }
                        </div>
                    </div>
                    {
                        !(location.pathname.startsWith(ADMIN_START_ROUTE_PATH))
                        &&
                        <div className="mt-2">
                            Go to Admin 
                            <a className="btn btn-md btn-success" href="/admin/login">Admin Login</a>
                        </div>
                    }

                    <div className="mt-2">
                        Go to product list 
                        <a className="btn btn-md btn-secondary" href="/">Product List</a>
                    </div>
                    
                </form>
            </section>
        </Suspense>
    );
}

export default Login;