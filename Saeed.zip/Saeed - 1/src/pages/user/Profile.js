import React, { Suspense, useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useForm } from "react-hook-form";
import Loader from '../../components/Loader';
import PageLoader from '../../components/PageLoader';
import { getUserInfo } from '../../slices/globalSlice';
import { useLocation, useParams } from 'react-router-dom';
import { DEFAULT_PER_PAGE, USER_PROFILE, DOCUMENT_PATH, ADMIN_START_ROUTE_PATH } from '../../utils/GlobalConstants';
import { keys } from 'lodash';
import { toast } from 'react-toastify';

function Profile(props) {

    const dispatch      =   useDispatch();
    const location      =   useLocation();
    const { id }        =   useParams();
    const globalState   =   useSelector(state => state.global);

    var temp_type = 2;
    
    if(location.pathname.startsWith(ADMIN_START_ROUTE_PATH)) {
        temp_type = 1;
    }

    const [type, setType] =   useState(temp_type);
    const [userDetails, setUserDetails] =   useState(globalState.user_detail);

    useEffect(() => {
        if(id != undefined && id != null && id != '') {
            getUserDetails(id);
        } else if(globalState.user_detail.id != undefined && globalState.user_detail.id != null) {
            getUserDetails(globalState.user_detail.id);
        }

    }, [id])

    const getUserDetails    =   (userID) => {
        dispatch(getUserInfo({ type: type, id: userID}))
            .unwrap()
            .then(response => {
                console.log("Response", response);

                if(response.status == "success") {
                    setUserDetails(response.user[0]);
                }

            })
            .catch(e => {
                console.log('Login error find', e.message);
                toast.error(e.message, {theme: "colored"});
            });
    }

    return (
        <Suspense fallback={<Loader />}>
            <section id="profile" className="profile">
                {
                    (
                        userDetails != undefined
                        &&
                        userDetails != null
                        &&
                        Object.keys(userDetails).length > 0
                    )
                    &&
                    <>
                        <div className="card mt-2" style={{ width: "50" }}>
                            {
                                <div className="text-center">
                                    {
                                        userDetails.profile_image != ''
                                        ?
                                        <img
                                            className="card-img-top"
                                            style={{ width: "20%" }}
                                            src={USER_PROFILE+userDetails._id+'/'+userDetails.profile_image}
                                        />
                                        :
                                        <img
                                            className="card-img-top"
                                            style={{ width: "20%" }}
                                            src={`${process.env.PUBLIC_URL}/user_logo.jpg`}
                                        />
                                    }
                                </div>
                            }
                            <div className="card-body">
                                <h4 className="card-title text-center">
                                    {
                                        userDetails.name
                                    }
                                </h4>


                                <table className="table table-borderless">
                                    <tbody>
                                        <tr>
                                            <td width={200}>Name</td>
                                            <td width={4}>:</td>
                                            <td>{userDetails.name}</td>
                                        </tr>
                                        <tr>
                                            <td width={200}>Email</td>
                                            <td width={4}>:</td>
                                            <td>{userDetails.email}</td>
                                        </tr>
                                        <tr>
                                            <td width={200}>Gender</td>
                                            <td width={4}>:</td>
                                            <td>{userDetails.gender}</td>
                                        </tr>
                                        <tr>
                                            <td width={200}>DOB</td>
                                            <td width={4}>:</td>
                                            <td>{new Date(userDetails.dob).toLocaleDateString()}</td>
                                        </tr>
                                        <tr>
                                            <td width={200}>Mobile Number</td>
                                            <td width={4}>:</td>
                                            <td>{userDetails.mobile_number}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </>
                }
            
            </section>
        </Suspense>
    );
}

export default Profile;