import React, { Suspense, useEffect, useState, useMemo, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useForm } from "react-hook-form";
import Loader from '../../components/Loader';
import PageLoader from '../../components/PageLoader';
import { useLocation, useParams } from 'react-router-dom';
import ReactPaginate from 'react-paginate';
import { Scrollbars } from 'react-custom-scrollbars-2';

function AnimationList(props) {

    const dispatch      =   useDispatch();
    const location      =   useLocation();
    const { id }        =   useParams();

    const [media, setMedia]         =   useState([]);
    const [pageCount, setPageCount] =   useState(0);
    const [pageSize, setPageSize]   =   useState(10);
    const [perPage, setPerPage]     =   useState(10);
    const [pageIndex, setPageIndex] =   useState(0);
    const [searchText, setSearchText] =   useState("");

    const searchRef     =   useRef(null);
    

    function getData(page) {
        var query = `
                    query ($id: Int, $page: Int, $perPage: Int, $search: String, $sort: [MediaSort]) {
                        Page (page: $page, perPage: $perPage) {
                            pageInfo {
                                total
                                currentPage
                                lastPage
                                hasNextPage
                                perPage
                            }
                            media (id: $id, search: $search, sort: $sort) {
                                id
                                title {
                                    romaji
                                }
                                isAdult
                                source
                                season
                                seasonYear
                                episodes
                                type
                                format
                                status
                                episodes
                                duration
                                volumes
                                averageScore
                                popularity
                                tags {
                                    name
                                    description
                                }
                            }
                        }
                    }
        `;

        var variables = {
            //id: 55191,
            //search: "MANGA",
            page: page + 1,
            perPage: pageSize,
            sort: ['TITLE_ROMAJI']
        };

        if(searchText !== "") {
            variables["search"] =   searchText;
        }

        console.log(variables);

        var url = 'https://graphql.anilist.co';
        var options = {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                },
                body: JSON.stringify({
                    query: query,
                    variables: variables
                })
            };

        try {
            fetch(url, options)
                .then((res) => res.json())
                .then((json) => {
                    
                    console.log("Page Total", json?.data?.Page);
                    if(json?.data?.Page?.pageInfo?.hasNextPage) {
                        setMedia(json?.data?.Page?.media);
                        setPageCount(Math.ceil(json?.data?.Page?.pageInfo?.total));
                    } else {
                        //getData(0);
                        setMedia([]);
                        setPageCount(0);
                        setPageIndex(0);
                    }
                    
                })
                .catch((error) => {
                    console.log(error);
                })
        } catch(error) {
            console.log(error);
        }
    }

    function gotoNextPage(clickedPage) {
        setPageIndex(clickedPage);
        getData(clickedPage);
    }

    const getNextPage = (data) => {
        var temp = data.selected;
        gotoNextPage(temp);
    }

    useEffect(() => {

        if(searchRef.current) {
            clearTimeout(searchRef.current);
        }

        searchRef.current   =   setTimeout(() => {
            getData(pageIndex);
        }, 500);
    }, [searchText]);

    
    

    return (
        <Suspense fallback={<Loader />}>
            <section id="animationlist" className="animationlist">
                <h4 className="text-center">
                    Media List
                </h4>

                <div className="input-group mb-3">
                    <input type="text" onChange={(e) => setSearchText(e.target.value)} value={searchText} className="form-control" placeholder="Search by title" aria-label="Recipient's username" aria-describedby="button-addon2" />
                    <button className="btn btn-outline-secondary" type="button" id="button-addon2">Search</button>
                </div>

                <Scrollbars  autoHeight autoHeightMax={800} >
                    <div className="row">
                        <div className="col-4 text-center font-weight-bold">
                            TITLE
                        </div>
                        <div className="col-2 text-center font-weight-bold">
                            STATUS
                        </div>
                        <div className="col-2 text-center font-weight-bold">
                            TYPE
                        </div>
                        <div className="col-2 text-center font-weight-bold">
                            IS ADULT
                        </div>
                        <div className="col-1 text-center font-weight-bold">
                            POPULARITY
                        </div>
                        <div className="col-1 text-center font-weight-bold">
                            ACTION
                        </div>
                    </div>
                    {
                        (
                            media
                            &&
                            Array.isArray(media)
                            &&
                            media.length > 0
                        )
                        ?
                        <React.Fragment>
                            {
                                media.map((me,i) => {
                                    return(
                                        <div className="row mt-2" key={i}>
                                            <div className="col-4">
                                                {
                                                    me.title.romaji
                                                }
                                            </div>
                                            <div className="col-2 text-center">
                                                {
                                                    me.status
                                                }
                                            </div>
                                            <div className="col-2 text-center">
                                                {
                                                    me.type
                                                }
                                            </div>
                                            <div className="col-2 text-center">
                                                {
                                                    me.isAdult ? "YES" : "NO"
                                                }
                                            </div>
                                            <div className="col-1 text-center">
                                                {
                                                    (parseInt(me.popularity) != 0) ? me.popularity : 0
                                                }
                                            </div>
                                            <div className="col-1 text-center">
                                                <a href={"/media/"+me.id} className="btn btn-sm btn-primary">View</a>
                                            </div>
                                        </div>
                                    )
                                })
                            }
                        </React.Fragment>
                        :
                        <React.Fragment>
                            <div className="row">
                                <div className="col-md-12 text-center font-weight-bold bg-primary">
                                    No Data
                                </div>
                            </div>
                        </React.Fragment>
                    }
                </Scrollbars>

            <div className="react-table-pagination row"> 
                <div className="col-md-9">
                    <div className="pagination justify-content-start my-4">
                        {
                            pageCount > 0
                            &&
                            !(
                                pageCount === 1
                            )
                            &&
                            <ReactPaginate
                                renderOnZeroPageCount={null}
                                previousLabel={'previous'}
                                nextLabel={'next'}
                                breakLabel={'...'}
                                breakClassName={'break-me'}
                                pageCount={pageCount}
                                marginPagesDisplayed={2}
                                pageRangeDisplayed={pageSize}
                                onPageChange={(data) => getNextPage(data)}
                                forcePage={pageIndex}
                                initialPage={pageIndex}
                                containerClassName={'pagination justify-content-start mb-0'}
                                activeClassName={'active'}
                                pageClassName={'page-item'}
                                pageLinkClassName={'page-link'}
                                previousClassName={' d-none page-item'}
                                nextClassName={'page-item'}
                                previousLinkClassName={' d-none page-link'}
                                nextLinkClassName={' d-none page-link'}
                            />
                        }
                    </div>
                </div>
            </div>

            </section>
        </Suspense>
    );
}

export default AnimationList;