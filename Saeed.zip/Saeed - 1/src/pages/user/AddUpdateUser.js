import React, { Suspense, useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Controller, useForm } from "react-hook-form";
import { useParams, useLocation, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import DatePicker from "react-datepicker";
import { yupResolver } from "@hookform/resolvers/yup";
import Loader from '../../components/Loader';
import { UserSchema } from '../../utils/ValidationSchemas';
import { ADMIN_START_ROUTE_PATH, COOKIE_NAME, USER_PROFILE } from '../../utils/GlobalConstants.js';
import { getUserInfo, userAddEditApi } from '../../slices/globalSlice';

var TIMER;

const AvatarUpload   =   React.lazy(() => import('../../components/AvatarUpload'));


function AddUpdateUser(props) {

    const dispatch      =   useDispatch();
    const navigate      =   useNavigate();
    const location      =   useLocation();
    const { user_id }   =   useParams();

    const globalState   =   useSelector(state => state.global);

    const [uploadImage, setUploadImage] =   useState(null);

    useEffect(() => {
        if(uploadImage != null && uploadImage.length > 0) {
            setValue("profile_image_file", uploadImage);
        } else {
            setValue("profile_image_file", []);
        }
        
    }, [uploadImage])

    var type    =   2;

    if(location.pathname.startsWith(ADMIN_START_ROUTE_PATH)) {
        type    =   1;
    }

    var defaultValues =   {
        id: (user_id != undefined && user_id != null && user_id != '') ? user_id : '',
        type: type,
        name: "",
        email: "",
        password: "",
        gender: "male",
        dob: "",
        mobile_number: "",
        address: "",
        profile_image: "",
        profile_image_file: [],
        location: location.pathname
    }

    const onlyNumber = (event) => {
        //console.log("event", event.target.value);
        if(TIMER) {
            clearTimeout(TIMER);
        }
        TIMER   =   setTimeout(() => {
            setValue("mobile_number", event.target.value.replace(/[^0-9]/g, ''));
        }, 500);
    }

    useEffect(() => {
        if(user_id != undefined && user_id != null && user_id != '') {
            getUserDetails(user_id);
        }
    }, [user_id]);

    const getUserDetails = (user_id) => {

        var type    =   2;

        if(location.pathname.startsWith(ADMIN_START_ROUTE_PATH)) {
            type    =   1;
        }

        dispatch(getUserInfo({ type: type, id: user_id }))
            .unwrap()
            .then(response => {

                console.log("login", response);

                if(response?.status != "success") {
                    toast.error(response?.message, {theme: "colored"});
                    return false;
                }

                if(response.user.length > 0) {
                    var temp_user = response.user[0];
                    var gender = temp_user["gender"];
                    gender  =   (gender != undefined && gender != null && gender != '') ? gender.toLowerCase() : "";
                    console.log("temp_user", temp_user);

                    setValue("address", temp_user["address"]);
                    setValue("dob", new Date(temp_user["dob"]));
                    setValue("email", temp_user["email"]);
                    setValue("gender", gender);
                    setValue("mobile_number", temp_user["mobile_number"]);
                    setValue("name", temp_user["name"]);
                    setValue("password", temp_user["password"]);
                    setValue("type", type);
                    setValue("profile_image", temp_user["profile_image"]);

                    if(temp_user["created_by_admin"] != null && temp_user["created_by_admin"] != "null") {
                        setValue("created_by_admin", temp_user["created_by_admin"]);
                    }

                    if(temp_user["created_by_manager"] != null && temp_user["created_by_manager"] != "null") {
                        setValue("created_by_manager", temp_user["created_by_manager"]);
                    }
                    
                }

            })
            .catch(e => {
                console.log('Login error find', e.message);
                toast.error(e.message, {theme: "colored"});
            });
    }

    const { register, handleSubmit, watch, control, setValue, reset, formState: { errors } } = useForm({ defaultValues: defaultValues, resolver: yupResolver(UserSchema) });

    const onSubmit = (userInfo) => {

        const formData  =   new FormData();

        /* for (const [key, value] of Object.entries(userInfo)) {
            if(key == "profile_image_file") {
                formData.append("profile_image_file", value[0]);
            } else {
                formData.append(key, value);
            }
        }
        userInfo["formData"] = formData; */

        dispatch(userAddEditApi(userInfo))
            .unwrap()
            .then(response => {

                console.log("login", response);

                if(response?.status != "success") {
                    toast.error(response?.message, {theme: "colored"});
                    return false;
                }

                if(user_id == undefined) {
                    reset({
                        ...defaultValues
                    });
                }

                toast.success(response?.message, {theme: "colored"});

                if(type == 1) {
                    navigate("/admin/login");
                } else {
                    navigate("/login");
                }

            })
            .catch(e => {
                console.log('Login error find', e.message);
                toast.error(e.message, {theme: "colored"});
            });
    }

    return (
        <Suspense fallback={<Loader />}>
            <section id="login" className="login p-4">
                <form onSubmit={handleSubmit(onSubmit)} className="was-validated">

                    <div className="mb-3 mt-3">
                        <label htmlFor="name" className="form-label">Name</label>
                        <input className="form-control" type="text" name="name" placeholder="Enter Name" id="name" {...register("name")} />
                        <div className="text-danger">{errors.name?.message}</div>
                    </div>

                    <div className="mb-3 mt-3">
                        <label htmlFor="email" className="form-label">Email</label>
                        <input className="form-control" type="text" name="email" id="email" placeholder="Enter Email" {...register("email")} />
                        <div className="text-danger">{errors.email?.message}</div>
                    </div>

                    {
                        (user_id == undefined)
                        &&
                        <>
                            <div className="mb-3 mt-3">
                                <label htmlFor="password" className="form-label">Password</label>
                                <input className="form-control" type="text" name="password" id="password" placeholder="Enter Password" {...register("password")} />
                                <div className="text-danger">{errors.password?.message}</div>
                            </div>
                        </>
                    }
                    
                    <div>
                        Gender
                    </div>

                    <div className="form-check">
                        <label className="form-check-label" htmlFor="male">
                            <input className="form-check-input" name="gender" id="male" {...register("gender")} type="radio" value="male" />
                            Male
                        </label>
                    </div>
                    <div className="form-check">
                        <label className="form-check-label" htmlFor="female">
                            <input className="form-check-input" name="gender" id="female" {...register("gender")} type="radio" value="female" />
                            Female
                        </label>
                    </div>
                    <div className="form-check">
                        <label className="form-check-label">
                            <input className="form-check-input" name="gender" id="transgender" {...register("gender")} type="radio" value="transgender" />
                            Transgender
                        </label>
                    </div>
                    <div className="text-danger">{errors.gender?.message}</div>


                    <div className="mb-3 mt-3">
                        <label htmlFor="mobile_number" className="form-label">Mobile Number</label>
                        <input className="form-control" type="text" name="mobile_number" id="mobile_number" onChangeCapture={onlyNumber} placeholder="Enter Mobile Number" {...register("mobile_number")} />
                        <div className="text-danger">{errors?.mobile_number?.message}</div>
                    </div>

                    <div className="mb-3 mt-3">
                        <label htmlFor="comment">Address</label>
                        <textarea className="form-control" name="address" id="address" {...register("address")}></textarea>
                        <div className="text-danger">{errors?.address?.message}</div>
                    </div>

                    <div>
                        DOB
                    </div>
                    <Controller
                        control={control}
                        name="dob"
                        id="dob"
                        render={({ field }) => (
                            <>
                                <DatePicker
                                    placeholderText='Select date'
                                    onChange={(date) => field.onChange(date)}
                                    selected={field.value}
                                    dateFormat="yyyy-MM-dd"
                                />
                                <div className="text-danger">{errors.dob?.message}</div>
                            </>
                        )}
                    />
                    {
                        (
                            user_id != undefined
                            &&
                            user_id != null
                            &&
                            user_id != ''
                            &&
                            watch("profile_image")
                        )
                        &&
                        <div>
                            <img src={USER_PROFILE+user_id+'/'+watch("profile_image")} className="round" width={100} height={100} alt="User Logo" />
                            <button type="button" className="btn btn-sm btn-danger" onClick={() => setValue("profile_image", "")}>
                                Clear
                            </button>
                        </div>
                    }
                    {
                        (
                            !watch("profile_image")
                            &&
                            user_id != undefined
                            &&
                            user_id != null
                            &&
                            user_id != ''
                        )
                        &&
                        <AvatarUpload
                            fileState={uploadImage}
                            setValue={setUploadImage}
                            isDragable={false}
                            isMultipleFileUpload={false}
                            maxFileSize={5 * 1024 * 1024}
                            maxFiles={1}
                            fileTypes={{
                                'image/jpg': [],
                                'image/jpeg': [],
                                'image/png': []
                            }}
                        />
                    }

                    {
                        (
                            user_id != undefined
                            &&
                            user_id != null
                            &&
                            user_id != ''
                        )
                        ?
                            <button type="submit" className="btn btn-md btn-info" id="submit" name="submit">Update</button>
                        :
                            <button type="submit" className="btn btn-md btn-info" id="submit" name="submit">Create</button>
                    }
                </form>
            </section>
        </Suspense>
    );
}

export default AddUpdateUser;