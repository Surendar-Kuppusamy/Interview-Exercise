import React, { Suspense, useEffect, useState, useMemo, useRef } from 'react';
import { useLocation, useParams } from 'react-router-dom';
import Loader from '../../components/Loader';
import PageLoader from '../../components/PageLoader';

function MediaView(props) {

    const [media, setMedia]         =   useState([]);
    const { id }                    =   useParams();

    useEffect(() => {
        getData(id)
    }, []);

    function getData(id) {

        var query = `
                    query ($id: Int, $page: Int, $perPage: Int, $search: String, $sort: [MediaSort]) {
                        Page (page: $page, perPage: $perPage) {
                            pageInfo {
                                total
                                currentPage
                                lastPage
                                hasNextPage
                                perPage
                            }
                            media (id: $id, search: $search, sort: $sort) {
                                id
                                title {
                                    romaji
                                }
                                isAdult
                                source
                                season
                                seasonYear
                                episodes
                                type
                                format
                                status
                                episodes
                                duration
                                volumes
                                averageScore
                                popularity
                                tags {
                                    name
                                    description
                                }
                            }
                        }
                    }
        `;

        var variables = {
            id: id,
            //search: "MANGA",
            //page: page + 1,
            //perPage: pageSize,
            //sort: ['TITLE_ROMAJI']
        };

        console.log(variables);

        var url = 'https://graphql.anilist.co';
        var options = {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                },
                body: JSON.stringify({
                    query: query,
                    variables: variables
                })
            };

        try {
            fetch(url, options)
                .then((res) => res.json())
                .then((json) => {

                    setMedia(json?.data?.Page?.media);
                    
                })
                .catch((error) => {
                    console.log(error);
                })
        } catch(error) {
            console.log(error);
        }
    }

    return(
        <section>
            <h1>
                Media View
            </h1>

            <div className="text-left">
                <a href="/" className="btn btn-sm btn-primary">
                    Back
                </a>
            </div>
            
            {
                media.length > 0
                ?
                <React.Fragment>
                    <div className="row">
                        <div className="col-12 col-md-4 font-weight-bold">
                            TITLE
                        </div>
                        <div className="col-12 col-md-8">
                            {
                                (
                                    media
                                    &&
                                    Array.isArray(media)
                                    &&
                                    media.length > 0
                                )
                                &&
                                media[0]["title"]["romaji"]
                            }
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12 col-md-4 font-weight-bold">
                            STATUS
                        </div>
                        <div className="col-12 col-md-8">
                            {
                                (
                                    media
                                    &&
                                    Array.isArray(media)
                                    &&
                                    media.length > 0
                                )
                                &&
                                media[0]["status"]
                            }
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12 col-md-4 font-weight-bold">
                            TYPE
                        </div>
                        <div className="col-12 col-md-8">
                            {
                                (
                                    media
                                    &&
                                    Array.isArray(media)
                                    &&
                                    media.length > 0
                                )
                                &&
                                media[0]["type"]
                            }
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12 col-md-4 font-weight-bold">
                            IS ADULT
                        </div>
                        <div className="col-12 col-md-8">
                            {
                                (
                                    media
                                    &&
                                    Array.isArray(media)
                                    &&
                                    media.length > 0
                                )
                                &&
                                media[0]["isAdult"] ? "Yes" : "No"
                            }
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12 col-md-4 font-weight-bold">
                            POPULARITY
                        </div>
                        <div className="col-12 col-md-8">
                            {
                                (
                                    media
                                    &&
                                    Array.isArray(media)
                                    &&
                                    media.length > 0
                                )
                                &&
                                media[0]["popularity"]
                            }
                        </div>
                    </div>
                </React.Fragment>
                :
                <PageLoader />
            }

        </section>
    )
}

export default MediaView;