import React, { Suspense, lazy, useEffect, useCallback, useMemo } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { BrowserRouter as Router, Navigate, useLocation, useNavigate, useRoutes } from "react-router-dom";
import ConfiguredRoutes from './ConfiguredRoutes';


const Container                 =   React.lazy(() => import('../components/Container'));

function AllRoutes(props) {

    const dispatch              =   useDispatch();
    const navigate              =   useNavigate();
    const location              =   useLocation();
    const globalState           =   props.globalState;

    const allRouting = useRoutes(ConfiguredRoutes());

    return (
        <Container>
            {allRouting}
        </Container>
    );
}


export default AllRoutes;
