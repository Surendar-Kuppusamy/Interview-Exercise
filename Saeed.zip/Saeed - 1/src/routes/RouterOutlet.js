import React, { Suspense, lazy, useEffect, useCallback } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { BrowserRouter as Router, HashRouter } from "react-router-dom";
import { siteLoader, getCurrentUser } from '../slices/globalSlice';
import Loader from '../components/Loader';
import LogoutUser from '../pages/auth/LogoutUser';

const Header        =   React.lazy(() => import('../layouts/Header'));
const Footer        =   React.lazy(() => import('../layouts/Footer'));
const AllRoutes     =   React.lazy(() => import('../routes/AllRoutes'));


function RouterOutlet() {

    const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

    const dispatch      =   useDispatch();
    const globalState   =   useSelector(state => state.global);

    return (
        <Suspense fallback={<Loader />}>
            <Router>
                {
                    <>
                        <Header />
                        <main className="layout">
                            <AllRoutes globalState={globalState} />
                        </main>
                        <Footer />
                    </>
                }
            </Router>
        </Suspense>
    );
}

export default RouterOutlet;