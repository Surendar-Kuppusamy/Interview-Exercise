import React, { Suspense, lazy, useEffect, useCallback, useMemo } from 'react';

const AnimationList     =   React.lazy(() => import('../pages/user/AnimationList'));
const MediaView         =   React.lazy(() => import('../pages/user/MediaView'));


function stringToBoolean(value){
    return (String(value).toLowerCase() === 'true');
}


const ConfiguredRoutes = () => {

    return [
        {
            path: '/',
            element: <AnimationList />
        },
        {
            path: '/media/:id',
            element: <MediaView />
        },
    ]
};

export default ConfiguredRoutes;