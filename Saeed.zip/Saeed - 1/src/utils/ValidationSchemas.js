import * as yup from "yup";
import { ALERT_MESSAGES } from './AlertMessages';
import moment from "moment";

export const EmailReg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w\w+)+$/;
export const PasswordReg = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[\^$*.\[\]{}\(\)?\-\"!@#%&\/,><\':;|_~`])\S{8,99}$/;
export const UpperCaseReg = /(?=.*[A-Z])/;
export const SpaceCaseReg = /\s/;
export const LowerCaseReg = /(?=.*[a-z])/;
export const NumberCaseReg = /(?=.*[0-9])/;
export const SpecialCaseReg = /(?=.*[\^$*.\[\]{}\(\)?\-"!@#%&\/,><\’:;|_~`])(?=.*[\^$*.\[\]{}\(\)?\-"!@#%&\/,><\’:;|_~`])/;
export const specialChars = /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
export const usernameReg = /^[a-zA-Z][a-zA-Z0-9]+[0-9]*$/;
export const NoSpace = /^[^-\s]{8,30}$/;
export const userFullReg = /^[a-zA-Z][a-zA-Z\s]*$/;

export const UserLoginSchema   =    yup.object().shape({
    email       :   yup.string().trim()
                        .required(ALERT_MESSAGES['email_required'])
                        .email(ALERT_MESSAGES['invalid_email']),
    password    :   yup.string().trim()
                        .required(ALERT_MESSAGES['password_required'])
});

export const UserSchema   =    yup.object().shape({
    type            :   yup.string().trim()
                            .required(ALERT_MESSAGES['type_required']),
    email           :   yup.string().trim()
                            .required(ALERT_MESSAGES['email_required'])
                            .email(ALERT_MESSAGES['invalid_email']),
    password        :   yup.string().trim()
                            .required(ALERT_MESSAGES['password_required']),
    name            :   yup.string().trim()
                            .required(ALERT_MESSAGES['name_required']),
    gender          :   yup.string().trim()
                            .required(ALERT_MESSAGES['gender_required']),
    address         :   yup.string().trim()
                            .required(ALERT_MESSAGES['address_required']),
    dob             :   yup.string().trim()
                            .required(ALERT_MESSAGES['dob_required']),
    mobile_number   :   yup.string().trim()
                            .required(ALERT_MESSAGES['mobile_required'])
                        
});


export const ProductCategorySchema   =    yup.object().shape({
    name            :   yup.string().trim()
                            .required(ALERT_MESSAGES['name_required']),
    description     :   yup.string().trim()
                            .required(ALERT_MESSAGES['description_required']),
    status          :   yup.string().trim()
                            .required(ALERT_MESSAGES['status_required'])
});

export const AttributeSchema   =    yup.object().shape({
    name            :   yup.string().trim()
                            .required(ALERT_MESSAGES['name_required']),
    label           :   yup.string().trim()
                            .required(ALERT_MESSAGES['label_required']),
    description     :   yup.string().trim()
                            .required(ALERT_MESSAGES['description_required']),
    status          :   yup.string().trim()
                            .required(ALERT_MESSAGES['status_required'])
});

export const DiscountSchema   =    yup.object().shape({
    name            :   yup.string().trim()
                            .required(ALERT_MESSAGES['name_required']),
    description     :   yup.string().trim()
                            .required(ALERT_MESSAGES['description_required']),
    status          :   yup.string().trim()
                            .required(ALERT_MESSAGES['status_required']),
    percentage      :   yup.number().typeError(ALERT_MESSAGES['number_type_error'])
                            .required(ALERT_MESSAGES['percentage_required'])
                            .test('validSpecialCharacters', ALERT_MESSAGES['invalid_percentage'], 
                                (value) => (parseFloat(value) > 0 && parseFloat(value) <= 100)
                            ),
});

export const ProductSchema   =    yup.object().shape({
    name                :   yup.string().trim()
                                .required(ALERT_MESSAGES['name_required']),
    description         :   yup.string().trim()
                                .required(ALERT_MESSAGES['description_required']),
    product_category    :   yup.string().trim()
                                .required(ALERT_MESSAGES['product_category_required']),
    attribute_id        :   yup.string().trim()
                                .required(ALERT_MESSAGES['attribute_id_required']),
    attribute_value     :   yup.number().typeError(ALERT_MESSAGES['number_type_error'])
                                .required(ALERT_MESSAGES['attribute_value_required'])
                                .test('validSpecialCharacters', ALERT_MESSAGES['invalid_attribute_value'], 
                                    (value) => (parseFloat(value) > 0 && parseFloat(value) <= 5000000000)
                                ),
    price               :   yup.number().typeError(ALERT_MESSAGES['number_type_error'])
                                .required(ALERT_MESSAGES['price_required'])
                                .test('validSpecialCharacters', ALERT_MESSAGES['invalid_price'], 
                                    (value) => (parseFloat(value) > 0 && parseFloat(value) <= 5000000000)
                                ),
    status              :   yup.string().trim()
                                .required(ALERT_MESSAGES['status_required'])
});

export const ProductVariantSchema   =    yup.object().shape({
    product_id          :   yup.string().trim()
                                .required(ALERT_MESSAGES['product_id_required']),
    attribute_id        :   yup.string().trim()
                                .required(ALERT_MESSAGES['attribute_id_required']),
    attribute_value     :   yup.number().typeError(ALERT_MESSAGES['number_type_error'])
                                .required(ALERT_MESSAGES['attribute_value_required'])
                                .test('validSpecialCharacters', ALERT_MESSAGES['invalid_attribute_value'], 
                                    (value) => (parseFloat(value) > 0 && parseFloat(value) <= 5000000000)
                                ),
    price               :   yup.number().typeError(ALERT_MESSAGES['number_type_error'])
                                .required(ALERT_MESSAGES['price_required'])
                                .test('validSpecialCharacters', ALERT_MESSAGES['invalid_price'], 
                                    (value) => (parseFloat(value) > 0 && parseFloat(value) <= 5000000000)
                                ),
    status              :   yup.string().trim()
                                .required(ALERT_MESSAGES['status_required'])
});