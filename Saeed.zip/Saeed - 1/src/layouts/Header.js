import React, { useEffect, useState, useMemo, useRef } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Outlet, Link, useLocation, useNavigate } from "react-router-dom";
import Select, { components } from "react-select";
import { useCookies } from 'react-cookie';
import { USER_START_ROUTE_PATH, ADMIN_START_ROUTE_PATH, COOKIE_NAME } from '../utils/GlobalConstants.js';
import { getAllOptions, getProductAll, setAllProductCategories, setAllProducts } from '../slices/globalSlice.js';


function Header(props) {

    const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

    const dispatch          =   useDispatch();
    const navigate          =   useNavigate();
    const globalState       =   useSelector(app => app.global);
    const location          =   useLocation();

    const [cookies, setCookie, removeCookie]    =   useCookies([COOKIE_NAME]);
    const [activeNav, setActiveNav]             =   useState(USER_START_ROUTE_PATH);

    const searchRef                             =   useRef();

    const [selectedOptions, setSelectedOptions] =   useState([]);
    const [searchProduct, setSearchProduct]     =   useState("");

    useEffect(() => {

        if(searchRef.current) {
            clearTimeout(searchRef.current);
        }

        searchRef.current   =   setTimeout(() => {
            //getAllProducts({"product_category": selectedOptions});
        }, 500);
        
    }, [searchProduct]);

    useEffect(() => {
        setActiveNav(location.pathname);
    },[location, activeNav]);

    const headerMenuClass   =   (menuPath) => {
        if(location.pathname.endsWith(menuPath)) {
            return 'nav-link active pointer';
        } else {
            return 'nav-link pointer';
        }
    }

    const headerNavMenuClass   =   (menuPath) => {
        if(location.pathname.endsWith(menuPath)) {
            return 'nav-item active pointer';
        } else {
            return 'nav-item pointer';
        }
    }

    const customStyles = {
        control: (defaultStyles) => ({
          ...defaultStyles,
        }),
        singleValue: (defaultStyles) => ({ ...defaultStyles, color: "#fff" }),
    };

    return (
        <nav className="navbar navbar-expand-sm navbar-dark bg-info">
            <div className="container-fluid">
                <a className="navbar-brand" href="/login">
                    Medias
                </a>
            </div>
        </nav>
    )    
}

export default Header;